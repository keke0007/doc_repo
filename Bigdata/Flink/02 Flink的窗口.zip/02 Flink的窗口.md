# 1.什么是窗口

流式计算是一种被设计用于处理无限数据集的数据计算引擎，所谓无限数据集是指一种源源不断的数据流抽象成的集合。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">而Window就是一种将无限数据集按照一定的规则（按照时间或条数）切分成多个有限数据集并对每一个有限数据集分别进行处理的手段。</span>Window本质上是将数据流按照一定的规则，逻辑地切分成很多个有限大小的“bucket”桶，这样就可以对每一个在“桶里面”的有限的数据依次地进行计算了。

流式计算引擎的特点是每输入一条数据就立即处理，延迟低。然而在一些场景下偏偏希望将数据先攒成一个个小批次，然后对每一个小批次再进行运算。例如用FlinkDataStream API将数据进行实时的聚合后，再将结果实时的写入到数据库，每输入一条数据都会输出一个聚合后的结果，如果数据量非常大，那么对外部的数据库的写入压力就比较大。而划分成Window，即将每一个Window中的有限的数据先聚合成一条或几条，再写入到数据库中，虽然延迟变高了，但是对数据库的写入压力变小了。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Window操作可以认为是微批次准实时的计算</span>，这样Flink DataStream API 既可以实现高效的实时运算，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">又可以实现微批次的准实时运算，让Flink在实时计算领域更加强大和灵活</span>。



# **2.时间类型**

Flink实时计算划分窗口时，如果使用时间作为划分窗口的依据，时间有不同的类型，分为<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Event Time、Ingestion Time、Processing Time</span>。Flink默认使用的是Processing Time，程序运行如果使用不同的时间类型，计算的结果完全不同，可以根据实际需求选择使用具体哪一种时间类型。

&#x20;

![](<images/02 Flink的窗口-image-10.png>)

&#x20;

### 1. **Event Time 事件时间**

在大数据领域，日志服务器生成的一条数据也可以称为一个事件。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Event Time是指在数据产生时该设备上对应的时间</span>，这个时间在进入Flink之前已经存在于数据记录中了。以后数据被Flink处理数据，如果使用Event Time作为时间标准，那么数据并不是按照Event Time的先后顺序被处理的，由于数据可能产生在多个不同的日志服务器，然后通常是再将数据写入到分布性消息中间件，然后被被Flink拉取进行处理时，处理的实际时间相对于数据产生的实际肯定有一定的延迟，并且Event Time可能也是乱序的。那么为什么还要使用Event Time呢？是因为使用Event Time时，Flink程序可以处理乱序事件和延迟数据。并且最重要的功能就是可以统计在数据产生时，对应时间的数据指标。



### 2. **Ingestion Time 进入时间**

Ingestion Time指的是事件数据进入到Flink的时间，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">即每条数据的Ingestion Time就是进入到Source Operator时所在机器的系统时间。</span>比如Flink从Kafka消息中间件消费数据，每一条数据的Ingestion Time就是FlinkKafkaConsumer拉取数据进入到TaskManager对应的时间。Ingestion Time介于Event Time和Processing Time之间，与 Event Time 相比，Ingestion Time程序无法处理任何无序事件或延迟数据，并且程序不必指定如何生成水，Flink会自动分配时间戳和自动生成水位线。



### 3. **Processing Time 处理时间**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Processing Time是指事件数据被Operator处理时所在机器的系统时间</span>，它提供了最好的性能和最低的延迟。但是，Flink是一个在分布式的计算框架，数据从产生到被处理会有一定的延迟（例如从消息队列拉取数据到Source，Source再到处理的Operator会有一定的延迟），所以Processing Time无法精准的体现出数据在产生的那个时刻的变化情况。



# 3.窗口的类型



![](<images/02 Flink的窗口-image-9.png>)



## **3.1 Non-Keyed和Keyed Windows**

在划分Window之前，首先要确定该DataStream是否调用了key算子将数据按照key进行分组了。如果没有调用keyBy算子，可以调用windowAll方法的返回一个AllWindowedStream，这种window叫做Non-Keyed Windows（未分组的Widnows）；如果事先已经调用了keyBy算子，即对KeyedStream可以调用window方法返回一个WindowedStream，这种window叫做Keyed Windows（分组的Widnows）。由于调用windowAll/window算子后会生成会生成新WindowedStream/WindowedStream，所以窗口算也是属于Transformation。

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">NonKeyedWindow的window和window Operator所在的DataStream并行度只能是1。</span>

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">KeyedWindow的window和window Operator所在的DataStream是</span> <span style="color: inherit; background-color: rgba(78,131,253,0.55)">多并行的(通常生产环境使用该类型)</span> <span style="color: inherit; background-color: rgba(255,246,122,0.8)">。</span>

&#x20;

### **3.1.1 Non-Keyed Windows**

未分组的窗口处理的数据是全局所有数据，即DataSteam直接调用windowAll算子得到的Windows，Non-Keyed Windows的特点是，在某一个具体的窗口，所有的数据都会被窗口算子路由到一个subtask中进行运算。

下面是Non-Keyed Windows的方法调用顺序和方法说明：

```java
stream
.windowAll(...)                             //<-  必选方法: 指定相应的窗口分配器
       [.trigger(...)]                      //<-  可选方法: 指定触发器，如果不指定有默认的触发器
       [.evictor(...)]                      //<-  可选方法: 指定剔除器，如果不指定有默认的剔除器
       [.allowedLateness(...)]              //<-  可选方法: 指定延迟触发时间，如果不指定，默认为0
       [.sideOutputLateData(...)]           //<-  可选方法: 指定延迟数据的侧流输出的Tag
        .sum/reduce/aggregate/apply()       //<-  必选方法: 指定窗口函数
       [.getSideOutput(...)]                //<-  可选方法: 指定侧流数据的Tag
```

&#x20;

**<span style="color: inherit; background-color: rgba(255,246,122,0.8)">windowAll()</span>**：划分Non-Keyed Windows，参数为指定的Window Assinger。

**trigger()：**&#x6307;定触发器，如果不指定有默认的触发器。

**evictor()：**&#x6307;定剔除器，如果不指定有默认的剔除器。

**allowedLateness()：**&#x6307;定延迟触发时间，如果不指定，默认为0。

**sideOutputLateData()：**&#x6307;定延迟数据的侧流输出的tag，用来筛选出打上指定tag的迟到数据

**<span style="color: inherit; background-color: rgba(255,246,122,0.8)">sum/reduce/aggregate/apply()</span>：**&#x6307;定窗口函数，窗口触发时会应该改函数对窗口中的数据进行计算。

**getSideOutput()：**&#x6307;定侧流数据的tag，筛选出指定tag类型的数据。



### **3.1.2 Keyed Windows**

分组的Widonws，即KeyedStream直接调用window算子得到的Windows。Keyed Windows

的特点是：窗口中的数据会根据key进行分组，key相同的数据一定会被分到同一个组内，并被路由到同一个subtask中，一个key对应一个组，一个subtask中可以有零到多个组。窗口触发会对每个组进行计算，每个组都会得到一个结果。

下面是Keyed Windows的方法调用顺序和方法说明：

```java
 stream
.keyKey(...)                                 //<-  先对DataStream调用keyBy得到keyedStream
.window(...)                                 //<-  必选方法: 指定相应的窗口分配器
       [.trigger(...)]                       //<-  可选方法: 指定触发器，如果不指定有默认的触发器
       [.evictor(...)]                       //<-  可选方法: 指定剔除器，如果不指定有默认的剔除器
       [.allowedLateness(...)]               //<-  可选方法: 指定延迟触发时间，如果不指定，默认为0
       [.sideOutputLateData(...)]            //<-  可选方法: 指定延迟数据的测流输出的Tag
        .sum/reduce/aggregate/apply()        //<-  必选方法: 指定窗口函数
       [.getSideOutput(...)]                 //<-  可选方法: 指定测流数据的Tag
```

&#x20;

**keyBy()**：按照key进行分组，参数为一或多个分组字段

**windw()**：划分keyed Windows，参数为指定的Window Assinger

&#x20;

## **3.2 Window Assinger**

当调用window或windowAll方法时，所传入的参数就是Window Assigner（窗口分配器），<span style="color: inherit; background-color: rgba(255,246,122,0.8)">其作用是决定划分什么样类型的窗口，即以何种条件划分窗口，输入的数据以何种方式分配到窗口内，窗口如何触发等等</span>。Flink提供了Tumbling windows（滚动窗口）、Sliding windows（滑动窗口）, Session windows（会话窗口）和Global windows（全局窗口，另外CountWindow属于Global windows）。这些自带的Window Assigner可以满足大多数的场景，如果有特殊需要可以继承WindowAssigner这个抽象类实现自己的Window Assigner。在以上四种内置Window Assigner中，除了Global windows，其他三种都属于时间类型的窗口，它们既可以按照ProcessingTime划分窗口，也可以按照EventTime划分窗口。

时间类型的窗口，都有窗口的起始时间和结束时间，时间的类型是timestamp格式（timestamp的值是指从1970年1月1日0时0分0秒到现在的long类型毫秒数）。窗口的起始时间、结束时间是前闭后开的，即包括起始时间，不包括结束时间，并且窗口的起始时间和结束时间必须是窗口长度的整数倍。例如一个滚动窗口的长度为10秒，起始时间是2020-01-01 00:00:00，那么对应的timestamp格式就是\[1577808000000, 1577808010000)。窗口的start就是1577808000000，窗口的end就是1577808010000，窗口的maxTimestamp就是窗口的end减1即1577808009999。

### **3.2.1 Global Windows 全局窗口**

全局窗口将key相同的数据都分配到一个单独的窗口中，每一种key对应一个全局窗口，多个全局窗口之间是相互独立的。如果是Non-Keyed Windows，就仅有一个全局窗口。全局窗口没有结束的边界，使用的Trigger（触发器）是NeverTrigger。如果不对全局窗口指定一个触发器，窗口是不会触发计算的，

下面的代码是全局窗口的基本使用：

```java
 wordAndOne
        .keyBy(0) //指定key selector 分组字段
        .window(GlobalWindows.create())  //调用window方法传入GlobalWindows，该窗口永远不会触发。
        .sum(1); 
```



* CountWindow



Count Windows属于Global Windows并指定了CountTrigger，下面是countWindowAll和countWindow方法的源代码：

```java
//countWindowAll方法源代码，调用windowAll方法，传入GlobalWindows，并指定CountTrigger
public AllWindowedStream<T, GlobalWindow> countWindowAll(long size) {
   return windowAll(GlobalWindows.create()).trigger(PurgingTrigger.of(CountTrigger.of(size)));
}

//countWindow方法源代码，调用window方法，传入GlobalWindows，并指定CountTrigger
public WindowedStream<T, KEY, GlobalWindow> countWindow(long size) {
   return window(GlobalWindows.create()).trigger(PurgingTrigger.of(CountTrigger.of(size)));
}
```

&#x20;

* **Non-Keyed Count** **Windows**

**&#x20;**

是按照窗口中接收到数据的条数划分窗口的，跟时间无关。如果没有达到指定的条数，窗口不会被触发执行。

&#x20;

下面的例子是不分组调用countWindowAll划分窗口，具体逻辑是将输入的数字转成int，然后按照输入数据的条数划分窗口，当数据达到3条，就会形成一个完整的窗口，触发窗口并窗口内的3条数据集进行sum运算。

```java
//使用nc -lk 8888命令输入数字
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);
//将字符转成int
DataStream<Integer> numbers = lines.map(Integer::parseInt); 
//不分组，使用countWindowAll划分窗口,窗口中数量达到3条，触发窗口执行
AllWindowedStream<Integer, GlobalWindow> windowed = numbers.countWindowAll(5);
DataStream<Integer> summed = windowed.sum(0); //将窗口中的数字相加
summed.print(); //使用print sink打印输出结果
```

&#x20;

先使用nc -lk 8888启动netcat服务，然后启动上面的countWindowAll的例子，在命令行中输入数据。如果输入的数据小于5条，不会触发窗口，当数据输入为3条时，窗口触发并使用对应的sink输出结果。然后再重新计数。

&#x20;

* **Keyed Count** **Windows**

&#x20;

下面的例子是先调用keyBy分组后再调用countWindow划分窗口，具体逻辑是将输入的单词和1，组合放入到Tuple2中，然后调用keyBy按照单词分组，一个组对应一个窗口。当一个组内的数据达到3条，就会触发这个组对应的窗口并对组内的数据进行sum运算。

&#x20;

```java
DataStreamSource<String> words = env.socketTextStream("localhost", 8888);
DataStream<Tuple2<String, Integer>> wordAndOne = words
        .map(w -> Tuple2.of(w, 1)) //将单词和1组合放入一个Tuple2
        .returns(Types.TUPLE(Types.STRING, Types.INT)); //使用了Lambda表达式，要明确指定返回类型
WindowedStream<Tuple2<String, Integer>, Tuple, GlobalWindow> windowed = wordAndOne
        .keyBy(0) //先分组后再划分Count窗口
        .countWindow(5); //一个组内达数据达到3条，该组的数据触发执行
DataStream<Tuple2<String, Integer>> summed = windowed.sum(1);  //对窗口的数据进行sum
summed.print(); //使用print sink打印输出结果
```

&#x20;

同样使用nc -lk 8888启动netcat服务，然后启动上面的countWindow的例子，在命令行中输入数据。如果相同的单词输入的小于5条，即同一个组内的数据没有达到5条，窗口不会触发，当同一组内的数据达到3条时，这个组对应的窗口就会触发并使用相应的sink输出结果。然后这个组再重新计数。

&#x20;

### **3.2.2 Tumbling Windows滚动窗口**

滚动窗口是按照时间划分的窗口，其Assinger会将输入的每一条数据按照时间分配到固定长度的窗口内，并且<span style="color: inherit; background-color: rgba(255,246,122,0.8)">按照这个固定的时间进行滚动，窗口和窗口之间没有数据重叠</span>。

![](<images/02 Flink的窗口-QQ20221118-130558@2x.png>)

&#x20;

* **Non-Keyed Tumbling Windows**

&#x20;

下面的代码是滚动窗口的基本使用：

```java
//ProcessingTime类型滚动窗口
DataStream<Integer> numbers = ...
numbers.windowAll(TumblingProcessingTimeWindows.of(Time.seconds(5)));

//EventTime类型滚动窗口  需要抽取事件中的时间  并分配水位线
DataStream<Integer> numbers = ...
numbers.windowAll(TumblingEventTimeWindows.of(Time.seconds(5)));
```

&#x20;

```java
public AllWindowedStream<T, TimeWindow> timeWindowAll(Time size) {
   if (environment.getStreamTimeCharacteristic() == TimeCharacteristic.ProcessingTime) {
      return windowAll(TumblingProcessingTimeWindows.of(size));
   } else {
      return windowAll(TumblingEventTimeWindows.of(size));
   }
}
```



* **&#x20;Keyed Tumbling Windows**

```java
DataStream<Tuple2<String, Integer>> wordAndOne = ...;
//ProcessingTime滚动窗口
wordAndOne
        .keyBy(0) //指定key selector 分组字段
        .window(TumblingProcessingTimeWindows.of(Time.seconds(5))) //窗口长度为5秒
        .sum(1); //触发窗口对窗口内的数据进行sum运算


//EventTime滚动窗口
wordAndOne
        .keyBy(0) //指定key selector 分组字段
        .window(TumblingEventTimeWindows.of(Time.seconds(5)))  //窗口长度为5秒
        .sum(1); //触发窗口对窗口内的数据进行sum运算

wordAndOne
        .keyBy(0) //指定key selector 分组字段
        .window(TumblingEventTimeWindows.of(Time.days(1), Time.hours(-8))) //窗口长度为1天，同时将数据转换成对应的时区的时间
        .sum(1); //触发窗口对窗口内的数据进行sum运算
```

&#x20;

除了上面几种创建滚动窗口的方方法，Flink还提供了一个更简单的方发创建滚动窗口，

```java
 public WindowedStream<T, KEY, TimeWindow> timeWindow(Time size) {
   if (environment.getStreamTimeCharacteristic() == TimeCharacteristic.ProcessingTime) {
      return window(TumblingProcessingTimeWindows.of(size));
   } else {
      return window(TumblingEventTimeWindows.of(size));
   }
}
```

&#x20;

窗口的时间间隔也可以指定其他类型，例如：Time.milliseconds(x)、Time.seconds(x)、Time.minutes(x)、Time.hours(x)、Time.days(x)。除此之外还可以调用Time的of方法，传入数字和时间单位TimeUnit，例如Time.of(1, TimeUnit.HOURS)。

TumblingWindows的of方法如果指定一个参数，就会按照指定的时间周期性的滚动形成新的窗口，例如TumblingProcessingTimeWindows.of(Time.days(1))，那么窗口的起始时间是以当前系统的ProcessingTime的整点开始以小时为单位对齐。例如\[1:00:00.000, 1:59:59.999]对应一个窗口，\[2:00:00.000, 2:59:59.999]会对应下一个窗口，并且会不断的生成窗口。（为了方便描述，才使用1:00:00.000这种格式，窗口的时间其实是timestamp格式）。

TumblingWindows的of方法还可以传入2个参数，第二个参数的作用是将时间调整成指定时区的时间。在UTC-0以外的时区，就需要指定一个偏移量进行调整。例如，在中国就必须指定Time.hours（-8）的偏移量。



### **3.2.3 Sliding Windows 滑动窗口**

滑动窗口是按照时间划分的窗口，其Assinger会将输入的每一条数据按照时间分配到固定长度的窗口内，并且还可以指定一个额外的滑动参数用来指定窗口滑动的频率（也叫滑动步长），<span style="color: inherit; background-color: rgba(255,246,122,0.8)">因此当滑动步长小于窗口的长度时，窗口和窗口之间有数据重叠</span>。

![](<images/02 Flink的窗口-QQ20221118-131705@2x.png>)

**&#x20;**

* **Non-Keyed Sliding Windows**

&#x20;

下面的代码是滑动窗口的基本使用：

```java
//ProcessingTime类型滑动窗口
DataStream<Integer> numbers = ...
numbers.windowAll(SlidingProcessingTimeWindows.of(Time.seconds(10), Time.seconds(5)));

//EventTime类型滑动窗口 
DataStream<Integer> numbers = ...
numbers.windowAll(SlidingEventTimeWindows.of(Time.seconds(10), Time.seconds(5)))); 
```

* **Keyed Sliding Windows**

```java
//ProcessingTime滑动窗口
wordAndOne
        .keyBy(0) //指定key selector 分组字段
        .window(SlidingProcessingTimeWindows.of(Time.seconds(10), Time.seconds(5))) //窗口长度为10秒，5秒钟滑动一次
        .sum(1);

//EventTime滑动窗口
wordAndOne
        .keyBy(0) //指定key selector 分组字段
        .window(SlidingEventTimeWindows.of(Time.seconds(10), Time.seconds(5))) //窗口长度为10秒，5秒钟滑动一次
        .sum(1); //触发窗口对窗口内的数据进行sum运算
        
wordAndOne
        .keyBy(0) //指定key selector 分组字段
        //窗口长度为12小时，1小时滑动一次，同时将数据转换成对应的时区的时间
        .window(SlidingProcessingTimeWindows.of(Time.hours(12), Time.hours(1), Time.hours(-8)))
        .sum(1); //触发窗口对窗口内的数据进行sum运算
```

SlidingWindows的of方法如果指定两个参数，第一个参数为窗口的长度，第二个为滑动的频率（或加滑动步长）。例如SlidingEventTimeWindows.of(Time.seconds(10), Time.seconds(5))，那么窗口的起始时间是以数据对应的EventTime并且是滑动步长的整数倍为单位对齐。例如\[1:00:00.000, 1:00:09.999]对应一个窗口，\[1:00:05.000, 1:00:14.999]会对应下一个窗口，两窗口有数据重叠，并且会不断的生成窗口。

### **3.2.4 Session Windows 会话窗口**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">会话窗口是按照时间间隔划分窗口的，当超过指定的时间间隔，就会划分一个新的窗口</span>。会话窗口没有固定的起始时间和结束时间，窗口中的数据也不会重叠。会话窗口可以指定一个固定的时间间隔，也可以根据数据中的信息传入一个函数计算出一个动态变化的时间间隔。

![](<images/02 Flink的窗口-QQ20221118-180301@2x.png>)

下面的代码是会话窗口的基本使用：

```java
//ProcessingTime会话窗口
wordAndOne
        .keyBy(0) //指定key selector 分组字段
        .window(ProcessingTimeSessionWindows.withGap(Time.minutes(10)))
        .sum(1); //触发窗口对窗口内的数据进行sum运算
        
wordAndOne
        .keyBy(0) //指定key selector 分组字段
        .window(ProcessingTimeSessionWindows.withDynamicGap((element) -> {
            return element.f1 * 1000; //指定一个动态的时间间隔，根据数据的f1字段乘以1000得到，返回的是long类型
        }))
        .sum(1); //触发窗口对窗口内的数据进行sum运算
        
//EventTime会话窗口
wordAndOne
        .keyBy(0) //指定key selector 分组字段
        .window(EventTimeSessionWindows.withGap(Time.minutes(10))) //指定固定的时间间隔为10分钟
        .sum(1); //触发窗口对窗口内的数据进行sum运算

wordAndOne
        .keyBy(0) //指定key selector 分组字段
        .window(EventTimeSessionWindows.withDynamicGap((element) -> {
            return element.f1 * 1000; //指定一个动态的时间间隔，根据数据的f1字段乘以1000得到，返回的是long类型
        }))
        .sum(1); //触发窗口对窗口内的数据进行sum运算
```

&#x20;

## **3.3 ProcessingTime类型窗口**

### **3.3.1 TumblingProcessingTimeWindows**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">在使用Processing Time作为时间标准时，是按照window operator算子所在机器的系统的时间，周期性的滚动</span>。没有数据延迟的概念&#x20;

* &#x20;**Non-Keyed TumblingProcessingTimeWindows**

下面的例子是不分组调用timeWindowAll划分窗口，具体逻辑是将输入的数字转成int，然后按照Processing Time 5秒钟划分一个窗口，即按照系统时间5秒钟形成一个窗口，如果窗口中有数据就进行sum运算。

```java
DataStream<Integer> numbers = ...
//滚动窗口，5秒钟滚动一次
AllWindowedStream<Integer, TimeWindow> window = numbers
        .windowAll(TumblingProcessingTimeWindows.of(Time.seconds(5)));
//对窗口中的数字进行sum
DataStream<Integer> summed = window.sum(0);
```

&#x20;

先使用nc -lk 8888启动netcat服务，然后启动上面的timeWindowAll的例子，在一个窗口形成的5秒钟内输入1、2、3等窗口触发后得到的结果为6。在下一个窗口形成的5秒钟内输入4、5再触发得到的结果为9。





* **Keyed TumblingProcessingTimeWindows**

下面的例子是先调用keyBy分组后再调用timeWindow划分窗口，由于默认使用的是Processing Time，所以调用timeWindow方法传入滚动窗口的时间，等价于调用window方法再传入TumblingProcessingTimeWindows并制定窗口的时间。具体逻辑是将输入的单词和1，组合放入到Tuple2中，再调用keyBy按照单词分组，然后按照Processing Time 5秒钟划分一个窗口，即按照系统时间5秒钟形成一个窗口，一个窗口内可以有多个组，窗口触发就会对该窗口中的每一个组的数据进行sum运算。

```java
DataStream<Tuple2<String, Integer>> wordAndOne = ...
KeyedStream<Tuple2<String, Integer>, Tuple> keyed = wordAndOne.keyBy(0);
//按照ProcessingTime划分滚动窗口，窗口长度为5秒
WindowedStream<Tuple2<String, Integer>, Tuple, TimeWindow> window1 = keyed
    .window(TumblingEventTimeWindows.of(Time.seconds(5)))
//也可以调用timeWindow方法，传入具体时间作为口长度，所以window1和window2是一样的
//WindowedStream<Tuple2<String, Integer>, Tuple, TimeWindow> window2 = keyed.timeWindow(Time.seconds(5));
//对窗口每一个组进行聚合
DataStream<Tuple2<String, Integer>> summed = window1.sum(1);
```

同样使用nc -lk 8888启动netcat服务，然后启动上面的timeWindow的例子，然后输入数据

### **3.3.2 SlidingProcessingTimeWindows**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">在使用Processing Time作为时间标准时，是按照window operator算子所在机器的系统的时间，周期性的滑动，并且窗口的长度大于滑动步长</span>。

* **Non-Keyed SlidingProcessingTimeWindows**

下面的例子是不分组调用timeWindowAll，窗口长度为10秒，5秒钟滑动一次，具体逻辑是将输入的数字转成int，然后按照Processing Time 5秒钟滑动一次形成一个窗口，如果窗口中有数据就进行sum运算。需要注意的是，下一次滑动时，新的窗口内新输入的数据还要和该窗口其余的历史数据进行累加。

```java
//ProcessingTime类型滑动窗口
DataStream<Integer> numbers = ...
AllWindowedStream<Integer, TimeWindow> window = numbers
    .windowAll(SlidingProcessingTimeWindows.of(Time.seconds(10), Time.seconds(5)));
```

先使用nc -lk 8888启动netcat服务，然后启动上面的程序，并输入数据。





* **Keyed SlidingProcessingTimeWindows**

&#x20;

下面的例子是先调用keyBy分组后再调用timeWindow划分窗口，指定窗口长度为10秒，每5秒钟滑动一次，具体逻辑是将输入的单词和1，组合放入到Tuple2中，再调用keyBy按照单词分组，然后按照Processing Time 5秒钟滑动一次，即按照系统时间5秒钟滑动一次就形成一个新的窗口，一个窗口内可以有多个组，窗口触发就会对该窗口中的每一个组的数据进行sum运算。需要注意的是，下一次滑动时，新的窗口内新输入的数据分组后还要和该窗口其余的历史数据key相同的组进行累加。

&#x20;

```java
DataStream<Tuple2<String, Integer>> wordAndOne = ...
KeyedStream<Tuple2<String, Integer>, Tuple> keyed = wordAndOne.keyBy(0);
//按照ProcessingTime划分滚动窗口，窗口长度为5秒
WindowedStream<Tuple2<String, Integer>, Tuple, TimeWindow> window1 = keyed
    .window(SlidingProcessingTimeWindows.of(Time.seconds(10), Time.seconds(5)))
//也可以调用timeWindow方法，传入具体时间作为口长度，所以window1和window2是一样的
//WindowedStream<Tuple2<String, Integer>, Tuple, TimeWindow> window2 = keyed.timeWindow(Time.seconds(10), Time.seconds(5));
//对窗口每一个组进行聚合
DataStream<Tuple2<String, Integer>> summed = window1.sum(1);
```





### **3.3.3 ProcessingTimeSessionWindows**

会话窗口是按照时间划分窗口的，在使用Processing Time作为时间标准时，window operator算子所在机器的系统的时间，减去上一条数据的Processing Time，如果大于指定的时间间隔就会形成一个新的窗口。

&#x20;

* **Non-Keyed ProcessingTimeSessionWindows**

**&#x20;**

下面的例子是不分组调用windowAll方法传入ProcessingTimeSessionWindows划分窗口，并指定时间间隔为5秒。具体逻辑是将输入的数字转成int，如果窗口中有数据就进行sum运算。

&#x20;

```java
DataStream<Integer> numbers = ...
//不分组，划分会话窗口，如果系统的时间减去上一条数据的Processing Time大于5秒就形成一个新的窗口并触发执行
AllWindowedStream<Integer, TimeWindow> windowed = numbers
        .windowAll(ProcessingTimeSessionWindows.withGap(Time.seconds(5)));
//对窗口内的数字进行sum
DataStream<Integer> summed = windowed.sum(0);
```

&#x20;

* **Keyed ProcessingTimeSessionWindows**

下面的例子是分组后调用window方法传入ProcessingTimeSessionWindows划分窗口，并指定时间间隔为5秒。一个窗口内可以有多个组，窗口触发就会对该窗口中的每一个组的数据进行sum运算。

```java
//先分组再划分会话窗口
KeyedStream<Tuple2<String, Integer>, Tuple> keyed = wordAndOne.keyBy(0);
WindowedStream<Tuple2<String, Integer>, Tuple, TimeWindow> windowed = keyed
        .window(ProcessingTimeSessionWindows.withGap(Time.seconds(5)));
//将窗口内每一个组的数字sum
DataStream<Tuple2<String, Integer>> summed = windowed.sum(0);
```

## **3.5 Watermark 水位线**

### **3.5.1 事件时间推进的困难**

由于在事件时间语义的世界观中，时间是由流入系统的数据（事件）而推进的；而事件时间，并不能像处理时间那样，由宇宙客观规律以恒定速度，不可停滞地推进；从而，在事件时间语义的世界观中，时间的推进，并不是一件显而易见的事情；可能出现数据的延迟到达  , 那么时间的推进就不是一个 ，有以下几个难点

* **场景1：**

![](<images/02 Flink的窗口-image-4.png>)

数据时间存在<span style="color: inherit; background-color: rgba(255,246,122,0.8)">乱序的可能性</span>，但时光不能倒流啊！

* **场景2：**

![](<images/02 Flink的窗口-image-6.png>)

下游分区接收上游<span style="color: inherit; background-color: rgba(255,246,122,0.8)">多个分区的数据，数据时间错落有致，那以谁为准</span>？！

### 3.5.2 什么是WaterMark

在流式计算中，从数据产生，到被Source接收，再到被Window Operator处理，中间是需要一些时间，也是存在微小的延迟的。虽然大部分情况下，数据都是按照事件产生时间的先后顺序被Operator处理的，但是也不排除由于网络延迟、背压阻塞等特殊原因，导致数据是乱序的，即Flink接收到数据在被Window Operator处理时先后顺序并不是严格按照事件的Event Time顺序排列的。



那么此时出现一个问题，一旦数据出现乱序，如果只根据Event Time决定Window何时形成并触发计算，那么就不能保证数据是否全部到齐，但是又不能无限期的等下去，此时必须要有一种机制来保证在一个特定的时间后，必须触发Window将对应的数据进行计算，这个特殊的机制，就是Watermark。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Watermark是一种衡量Event Time进展的机制</span>，就好比是水库的水位线一样，当水位达到了警戒线时，就要采取必要的措施了。Watermark机制与Window结合就可以让窗口延迟触发，从而实现正确的处理乱序事件，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Watermark也可以理解为分布式的窗口按照EventTime统一触发一种机制(信号)，并且允许数据乱序延迟，保证属于同一个EventTime类型窗口的数据被</span> <span style="color: inherit; background-color: rgb(247,105,100)">应算尽算</span> <span style="color: inherit; background-color: rgba(255,246,122,0.8)">（如果数据迟到的时间，大于允许的延迟时间，数据会被丢弃，后面可以使用侧流数据</span> <span style="color: inherit; background-color: rgba(255,246,122,0.8)">在</span> <span style="color: inherit; background-color: rgba(255,246,122,0.8)">捞回来）。</span>



<span style="color: inherit; background-color: rgb(98,210,86)">watermark解决了两个问题：</span>

<span style="color: inherit; background-color: rgb(98,210,86)">1.EventTime数据乱序延迟问题</span>

<span style="color: inherit; background-color: rgb(98,210,86)">2.分布式窗口统一触发标准</span>



![](<images/02 Flink的窗口-watermakr.png>)

### **3.5.3 生成Watermark**

通常，在接收到source的数据后，应该立刻生成watermark。但是也可以在source后，再调用map、filter等算子，然后生成watermark。由于事件数据的格式千变万化，其中哪一个是Event Time字段，时间格式又是什么样的，对于Flink来说，它都不知道。所以我们写程序时，就要设置Event Time作为时间标准，提取数据中的时间字段，并且将时间字段转换成timestamp格式，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">例如数据的时间字段格式为2020 -01-01 00:00:00，就需要使用SimpleDateFormat转换成1577808000000精确到毫秒的long类型</span>。在DataStream API中，调用<span style="color: inherit; background-color: rgba(183,237,177,0.8)">assignTimestampsAndWatermarks</span>方法，可以传入两种watermark生成器接口类型，分别是AssignerWithPeriodicWatermarks（周期性生成watermark）和~~AssignerWithPunctuatedWatermarks~~（间歇性生成watermark，已过时）。下面的代码是使用AssignerWithPeriodicWatermarks方式提取数据中的时间字段并转换成timestamp格式如下：

&#x20;

* 老版本API

```java

DataStreamSource<String> lines = env.socketTextStream("localhost", 8888); 
Time maxOutOfOrderness = Time.milliseconds(0); //乱序延迟时间为0毫秒
DataStream<String> linesWithWaterMark = lines.assignTimestampsAndWatermarks(
        new BoundedOutOfOrdernessTimestampExtractor<String>(maxOutOfOrderness ) { //指定乱序延迟时间
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //定义日期格式类
            @Override
            public long extractTimestamp(String line) {
                String[] fields = line.split(",");  //切分数据提取EventTime
                long timestamp = 0;
                try {
                    Date date = dateFormat.parse(fields[0]);
                    timestamp = date.getTime(); //转成timestamp格式
                } catch (ParseException e) {
                    timestamp = System.currentTimeMillis(); //如果出现异常，使用当前系统是作为timestamp
                }
                return timestamp;
            }
        }
);
```

&#x20;

* &#x20;新版本API

使用新版本的提取EventTime生成WaterMark的API，输入的数据格式为：事件时间,单词,次数

```java
//1000,spark,1
//2000,spark,2
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);
//使用新的API生成WaterMark
SingleOutputStreamOperator<String> linesWithWaterMark = lines.assignTimestampsAndWatermarks(
        WatermarkStrategy.<String>forBoundedOutOfOrderness(Duration.ofSeconds(0)).withTimestampAssigner(
                new SerializableTimestampAssigner<String>() {
                    @Override
                    public long extractTimestamp(String element, long recordTimestamp) {
                        String[] fields = element.split(",");
                        return Long.parseLong(fields[0]);
                    }
                }
        )
);
```

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> watermark产生源头示意图</span>**



* **<span style="color: rgb(216,57,49); background-color: inherit">初始状态</span>**

&#x20;

![](<images/02 Flink的窗口-image-3.png>)

&#x20;

* **<span style="color: rgb(216,57,49); background-color: inherit">收到一条新数据后</span>**

![](<images/02 Flink的窗口-image-1.png>)

&#x20;

&#x20;

简单说，就是在watermark产生的源头算子实例中，实例程序会用一个定时器，去<u>周期性地检查</u>截止到此刻所收到过的数据的<u>事件时间最大值</u>，如果超过了之前的最大值，则将这个最大值更新为最新的watermark，并向下游传递；

&#x20;&#x20;

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> watermark往下游推进的示意图</span>**

**<span style="color: rgb(216,57,49); background-color: inherit"> </span>**

* **<span style="color: rgb(216,57,49); background-color: inherit">初始状态</span>**

![](<images/02 Flink的窗口-image-2.png>)

&#x20;

&#x20;

* **<span style="color: rgb(216,57,49); background-color: inherit">新的上游watermark即将到达</span>**

&#x20;

![](<images/02 Flink的窗口-image-5.png>)

&#x20;

* **<span style="color: rgb(216,57,49); background-color: inherit">上游的新watermark最终产生的效果</span>**

![](<images/02 Flink的窗口-image.png>)

&#x20;



一个下游算子实例，如果消费着多个上游算子实例：

<u><span style="color: rgb(216,57,49); background-color: inherit">则选择  “Min(游各实例的最新watermark)” 作为自己当前的watermark</span></u> <span style="color: rgb(216,57,49); background-color: inherit">；</span>

并将自己最新的watermark往下游广播；

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> watermark推进事件时间与窗口计算的结合示例</span>**

从这里可以看出，<span style="color: rgb(216,57,49); background-color: inherit">如果某一个上游实例watermark一直停滞，则会导致下游实例的watermark也一直停滞，</span>从而迟滞窗口计算的触发，并造成大量数据的积压；



![](<images/02 Flink的窗口-image-7.png>)

&#x20;

对此，flink提供了一个机制：<span style="color: rgb(216,57,49); background-color: inherit">设置watermark的idle超时：</span> <u><span style="color: rgb(216,57,49); background-color: inherit">如果某个分区超过idle时长没有收到数据，则会自主往前推进时间</span></u>；从而不会导致下游的watermark一直停滞不前！

```java
WatermarkStrategy.withIdleness(Duration.ofMinutes(1));
```



### 3.5.4 WaterMark原理深入



上面的代码是一种最便捷生成watermark的方式，在调用assignTimestampsAndWatermarks方法时，传入new BoundedOutOfOrdernessTimestampExtractor匿名内部类的实现（或者定义一个类，继承该抽象类），并且传入允许最大乱序时间。只要重写extractTimestamp方法，提取数据中的时间字段，返回timestamp类型就可以了。通过这种方式生成watermark可以处理乱序数据流并可以指定一个固定的乱序延迟执行时间。下面是BoundedOutOfOrdernessTimestampExtractor类生成watermark的源代码：

&#x20;

```java
@Override
public final Watermark getCurrentWatermark() {
   // this guarantees that the watermark never goes backwards.
   long potentialWM = currentMaxTimestamp - maxOutOfOrderness; //事件数据中的最大timestamp减去延迟时间
   if (potentialWM >= lastEmittedWatermark) {
      lastEmittedWatermark = potentialWM; //如果相减后的时间大于以前生成的watermark时间，就使用这个最新的时间
   }
   return new Watermark(lastEmittedWatermark); //使用最新的时间生成watermark，该时间已经减去了延迟时间
}
 
@Override
public final long extractTimestamp(T element, long previousElementTimestamp) {
   long timestamp = extractTimestamp(element); //调用重写的extractTimestamp提前时间字段并转成timestamp格式
   if (timestamp > currentMaxTimestamp) { 
      currentMaxTimestamp = timestamp; //将timestamp和最大历史timestamp进行比较，如果当前timestamp大于历史值就使用当前的。
   }
   return timestamp;
}
```



![](<images/02 Flink的窗口-image-8.png>)



> **原理深入**：分析BoundedOutOfOrdernessTimestampExtractor的源代码后可以发现：如果有数据输入，就会先调用自带的两个参数的extractTimestamp方法，然后在该方法中再调用自己实现的extractTimestamp方法，将返回的timestamp和最大历史timestamp进行比较，如果当前timestamp大于历史值就使用当前的。由于BoundedOutOfOrdernessTimestampExtractor实现了AssignerWithPeriodicWatermarks接口，会周期性生成watermark，即不停地调用getCurrentWatermark方法，就是用事件数据中的最大timestamp减去指定的固定延迟时间，如果相减后的时间大于以前生成的watermark时间，就使用这个最新的时间，返回的Watermark实例其实就是用这个时间作为构造方法的参数进行赋值，里面持有这个已经减去延迟时长的timestamp。

&#x20;

新版本生成WaterMark的API使用的是BoundedOutOfOrdernessWatermarks这个类，该类中有两个方法，具体实现如下：

```java
@Override
public void onEvent(T event, long eventTimestamp, WatermarkOutput output) {
    maxTimestamp = Math.max(maxTimestamp, eventTimestamp);
}

@Override
public void onPeriodicEmit(WatermarkOutput output) {
    output.emitWatermark(new Watermark(maxTimestamp - outOfOrdernessMillis - 1));
}
```

**onEvent()&#x20;**&#x6BCF;来一条数据调用一次该方法，在该方法中，会将当前数据中的EventTime与以前的最大EventTime进行比较，使用Math.max返回大的

**onPeriodicEmit()&#x20;**&#x8BE5;方法会被周期性的调用，默认值是200毫秒，也可以根据实际的需求，通过调用StreamExecutionEnvironment的方法设置：env.getConfig().setAutoWatermarkInterval(100)；在该方法中，是用最大的EventTime - 延迟时间 - 1 毫秒，作为WaterMark，并且使用广播的方式发送给后面的算子。

###

## 3.6 EventTime类型窗口

EventTime类型的窗口指的是<span style="color: inherit; background-color: rgba(255,246,122,0.8)">按照数据中的时间生成和触发窗口，不再按照系统时间生成和触发窗口的，</span> <span style="color: inherit; background-color: rgba(186,206,253,0.7)">所以使用EventTime类型的窗口前，必须提取数据中的时间并且生成WaterMark。</span>

### 3.6.1 TumblingEventTimeWindows

EventTime滚动窗口是按照数据中的事件时间划分的窗口，其Assinger会将输入的每一条数据按照时间分配到固定长度的窗口内，并且按照指定的固定时间进行滚动，窗口和窗口之间没有数据重叠。



* **NonKeyed TumblingEventTimeWindows**

不keyBy，直接划分EventTime滚动窗口，代码如下：

```java
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);
//调用完该方法，不会该表原来数据的样子，仅是多了WaterMark
SingleOutputStreamOperator<String> linesWithWaterMark = lines.assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor<String>(Time.seconds(0)) { //数据乱序延迟触发的时间
    @Override
    public long extractTimestamp(String element) {
        String[] fields = element.split(",");
        return Long.parseLong(fields[0]);
    }
});
SingleOutputStreamOperator<Integer> numStream = linesWithWaterMark.map(new MapFunction<String, Integer>() {
    @Override
    public Integer map(String line) throws Exception {
        String[] fields = line.split(",");
        return Integer.parseInt(fields[1]);
    }
});
//不KeyBY，直接划分滚动窗口
AllWindowedStream<Integer, TimeWindow> windowedStream = numStream.windowAll(TumblingEventTimeWindows.of(Time.seconds(5)));
//对窗口中的数据进行sum
SingleOutputStreamOperator<Integer> res = windowedStream.sum(0);
//调用print sink
res.print();
```

下面是程序该程序的执行计划图：

![](<images/02 Flink的窗口-QQ20221125-123920@2x.png>)





* Keyed TumblingEventTimeWindows

先keyBy，然后再进行聚合

```java
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);
//调用完该方法，不会改变原来数据的样子，仅是提取EventTime生成了WaterMark
SingleOutputStreamOperator<String> linesWithWaterMark = lines.assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor<String>(Time.seconds(0)) { //数据乱序延迟触发的时间
    @Override
    public long extractTimestamp(String element) {
        String[] fields = element.split(",");
        return Long.parseLong(fields[0]);
    }
});
//将单词和次数提取处理封装到元组内
SingleOutputStreamOperator<Tuple2<String, Integer>> tpStream = linesWithWaterMark.map(new MapFunction<String, Tuple2<String, Integer>>() {
    @Override
    public Tuple2<String, Integer> map(String line) throws Exception {
        String[] fields = line.split(",");
        return Tuple2.of(fields[1], Integer.parseInt(fields[2]));
    }
});
//先keyBy
KeyedStream<Tuple2<String, Integer>, String> keyedStream = tpStream.keyBy(t -> t.f0);
//再按照EventTime划分滚动窗口
WindowedStream<Tuple2<String, Integer>, String, TimeWindow> windowedStream = keyedStream.window(TumblingEventTimeWindows.of(Time.seconds(5)));
//对窗口中的数据进行聚合（增量）
SingleOutputStreamOperator<Tuple2<String, Integer>> res = windowedStream.sum(1);
res.print();
env.execute();
```

下面是程序的执行计划图：

![](<images/02 Flink的窗口-image-11.png>)

### 3.6.2 TumblingEventTimeWindows



* **&#x20;NonKeyed SlidingEventTimeWindows**

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(new Configuration());
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);
//调用完该方法，不会该表原来数据的样子，仅是多了WaterMark
SingleOutputStreamOperator<String> linesWithWaterMark = lines.assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor<String>(Time.seconds(0)) { //数据乱序延迟触发的时间
    @Override
    public long extractTimestamp(String element) {
        String[] fields = element.split(",");
        return Long.parseLong(fields[0]);
    }
});
SingleOutputStreamOperator<Integer> numStream = linesWithWaterMark.map(new MapFunction<String, Integer>() {
    @Override
    public Integer map(String line) throws Exception {
        String[] fields = line.split(",");
        return Integer.parseInt(fields[1]);
    }
});
//不KeyBY，直接划分滑动窗口
AllWindowedStream<Integer, TimeWindow> windowedStream = numStream.windowAll(SlidingEventTimeWindows.of(Time.seconds(10), Time.seconds(5)));
//对窗口中的数据进行sum
SingleOutputStreamOperator<Integer> res = windowedStream.sum(0);
//调用print sink
res.print();
env.execute();
```



* **Keyed SlidingEventTimeWindows**



```java
//1000,spark,1
//2000,spark,2
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);
SingleOutputStreamOperator<String> linesWithWaterMark = lines.assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor<String>(Time.seconds(0)) {
    @Override
    public long extractTimestamp(String line) {
        String[] fields = line.split(",");
        return Long.parseLong(fields[0]);
    }
});
//对数据进行整理
SingleOutputStreamOperator<Tuple2<String, Integer>> tpStream = linesWithWaterMark.map(new MapFunction<String, Tuple2<String, Integer>>() {
    @Override
    public Tuple2<String, Integer> map(String value) throws Exception {
        String[] fields = value.split(",");
        return Tuple2.of(fields[1], Integer.parseInt(fields[2]));
    }
});
//先keyBy
KeyedStream<Tuple2<String, Integer>, String> keyedStream = tpStream.keyBy(t -> t.f0);
//再划分窗口
WindowedStream<Tuple2<String, Integer>, String, TimeWindow> windowedStream = keyedStream.window(SlidingEventTimeWindows.of(Time.seconds(10), Time.seconds(2)));
//调用windowOperator
SingleOutputStreamOperator<Tuple2<String, Integer>> res = windowedStream.sum(1);
res.print();
env.execute();
```

###

### 3.6.3 EventTimeSessionWindows



* **NonKeyed EventTimeSessionWindows**

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(new Configuration());
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);
SingleOutputStreamOperator<String> linesWithWaterMark = lines.assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor<String>(Time.seconds(0)) { //数据乱序延迟触发的时间
    @Override
    public long extractTimestamp(String element) {
        String[] fields = element.split(",");
        return Long.parseLong(fields[0]);
    }
});
SingleOutputStreamOperator<Integer> numStream = linesWithWaterMark.map(new MapFunction<String, Integer>() {
    @Override
    public Integer map(String line) throws Exception {
        String[] fields = line.split(",");
        return Integer.parseInt(fields[1]);
    }
});
//不KeyBY，直接划分会话窗口
AllWindowedStream<Integer, TimeWindow> windowedStream = numStream.windowAll(EventTimeSessionWindows.withGap(Time.seconds(5)));
//对窗口中的数据进行sum
SingleOutputStreamOperator<Integer> res = windowedStream.sum(0);
//调用print sink
res.print();
env.execute();
```



* **Keyed EventTimeSessionWindows**

```java

StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//1000,spark,1
//2000,spark,2
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);
SingleOutputStreamOperator<String> linesWithWaterMark = lines.assignTimestampsAndWatermarks(new BoundedOutOfOrdernessTimestampExtractor<String>(Time.seconds(0)) {
    @Override
    public long extractTimestamp(String line) {
        String[] fields = line.split(",");
        return Long.parseLong(fields[0]);
    }
});
//对数据进行整理
SingleOutputStreamOperator<Tuple2<String, Integer>> tpStream = linesWithWaterMark.map(new MapFunction<String, Tuple2<String, Integer>>() {
    @Override
    public Tuple2<String, Integer> map(String value) throws Exception {
        String[] fields = value.split(",");
        return Tuple2.of(fields[1], Integer.parseInt(fields[2]));
    }
});
//先keyBy
KeyedStream<Tuple2<String, Integer>, String> keyedStream = tpStream.keyBy(t -> t.f0);
//再划分窗口
WindowedStream<Tuple2<String, Integer>, String, TimeWindow> windowedStream = keyedStream.window(EventTimeSessionWindows.withGap(Time.seconds(5)));
//调用windowOperator
SingleOutputStreamOperator<Tuple2<String, Integer>> res = windowedStream.sum(1);
res.print();
env.execute();
```



# **4 Window Functions**

通过定义Window Assinger划分完具体类型的窗口后，就需要指定如何对每个窗口内的数据进行计算，即为每一个窗口在触发时指定具体的计算逻辑，就需要使用Window Function来实现具体的处理逻辑。窗口函数可以是ReduceFunction、AggregateFunction和ProcessWindowFunction其中任意一个。在执行聚合的相关运算时，前三种的执行效率更高，因为它们可以实现增量聚合，窗口每输入一条数据就可以和窗口的内历史数据（State）进行运算，不必将所有的数据都缓存起来。而ProcessWindowFunction是将窗口内输入的每一条数据先缓存起来（State），当窗口触发时，窗口内全部的数据可以通过Iterable都迭代出来，再进行运算。虽然也可以实现聚合类的运算，但是效率要比其他的效率低。如果想要在每一个窗口内进行排序或计算TopN，这样需要窗口内全量的数据才能计算出结果的运算，那么就必须用ProcessWindowFunction了。

下面先学习一下ReduceFunction，AggregateFunction，等学习完State和ProcessFunction后，再学习ProcessWindowFunction。

## **4.1 ReduceFunction**

ReduceFunction可以指定具体的计算逻辑将输入的两个相同类型数据经过计算后返回一个跟参数相同类型的输出数据。Flink可以使用ReduceFunction来实现窗口内数据的增量聚合。

用户在自定义ReduceFunction类时，需要实现ReduceFunction接口，并指定一个泛型：即输入的两个参数和返回的数据类型。并且还要实现reduce方法。下面就是ReduceFunction接口和reduce方法的介绍。



```java
public interface ReduceFunction<T> extends Function, Serializable {
   T reduce(T value1, T value2) throws Exception;
}
```

&#x20;

**reduce()：**&#x7B2C;一个参数为历史值，第二个参数为与历史值key相同新输入的数据。如果输入的数据对应的key第一次输入，只会将该数作为中间结果，不会调用reduce方法。当相同key的数据再次输入，才会调用reduce方法，并且在该方法中将历史值和输入的数据进行聚合运算，返回一个新的值，并将这个新的值作为历史值与下一个key相同的数据进行运算。

**&#x20;**

**案例：使用ReduceFunction在每一个窗口内进行聚合，实现类似WordCount的功能**

**&#x20;**

```java
DataStream<Tuple2<String, Integer>> wordAndOne = ...
DataStream<Tuple2<String, Integer>> result = wordAndOne
        .keyBy(0) //指定分组的key
        .window(TumblingEventTimeWindows.of(Time.seconds(5))) //划分EventTime滚动窗口，窗口长度为5秒
        .reduce(new ReduceFunction<Tuple2<String, Integer>>() { //在reduce方法中传入ReduceFunction的实现
            @Override
            public Tuple2<String, Integer> reduce(Tuple2<String, Integer> v1, Tuple2<String, Integer> v2)
                    throws Exception {
                String word = v1.f0; //获取输入的单词
                Integer count = v1.f1 + v2.f1; //将当前单词的历史次数和输入的次数相加
                return Tuple2.of(word, count); //返回单词和次数的Tuple2
            }
        });
result.print(); //调用print sink 打印结果
env.execute("ReduceFunctionDemo");
```

&#x20;

注意：对窗口调用的sum、min、minBy、max、maxBy都是在ReduceFunction的基础上进行封装的，它们最终都会调用WindowedStream的reduce方法的。min和minBy的区别在于，min返回的是该窗口内参与分组的字段和要比较字段的最小值，如果数据中还有其他字段，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">其他字段的值是总是第一次输入的数据的值</span>。而minBy返回的是该窗口内要比较的<span style="color: inherit; background-color: rgba(255,246,122,0.8)">最小值对应的全部数据</span>。另外该方法还可以传入一个Boolean值，默认是true，即如果要比较的值相等，true就是返回最先出现的最小值，false返回最后出现的最小值。这些方法都是对当前窗口进行计算，返回一个结果，这个值没有与以前窗口计算出的值进行聚合运算。



## **4.2 AggregateFunction**



AggregateFunction与ReduceFunction类似，也可以对进入窗户内的每一条数据进行增量聚合运算，但是AggregateFunction是一个更通用、更灵活的聚合函数。

用户在自定义AggregateFunction类时，需要实现AggregateFunction接口，并指定三个泛型：第一个泛型为输入数据的类型；第二个泛型是初始值或历史值（累加器）的类型；第三个泛型为输出数据的类型并且还要实现createAccumulator、add、getResult和merge这四个方法。下面就是AggregateFunction接口和这四个方法的介绍。

```java
public interface AggregateFunction<IN, ACC, OUT> extends Function, Serializable {
   ACC createAccumulator();
   ACC add(IN value, ACC accumulator);
   OUT getResult(ACC accumulator);
   ACC merge(ACC a, ACC b);
}
```

&#x20;

**createAccumulator()：**&#x8BE5;方法用来创建初始值（累加器）并作为返回值返回，每个key都会调用一次该方法创建对应key的初始值。

**add()：**&#x8BE5;方法输入两个参数，第一个参数为窗口内输入的一条数据；第二个参数为初始值或中间结果的值（累加器）。窗口内每输入一条数据就会调用一次该方&#x6CD5;**，**&#x5C06;输入的数据和累加器进行运算，并作为中间结果返回。

**getResult()：**&#x8BE5;方输入一个参数，这个参数就是前面计算的中间结果（历史值），当窗口触发时每一个key对应的数据都会调用一次该方法，根据传入的中间结果计算出对应key的结果并返&#x56DE;**。**

**merge()：**&#x8BE5;方法输入两个参数，在窗口内的数据可以合并的时候是会调用该方法，将窗口的数据进行合并。该方法仅针对MergingWindowAssigner类型的窗口有效，而只有会话窗口（SessionWindow）实现了该接口，所以该方法只有会话窗口将数据合并时才会调用。其他类型的窗口不会调用该方法，即使该方法返回null也是不影响结果的。

&#x20;

**案例一：使用AggregateFunction在每一个窗口内进行聚合，实现类似WordCount的功能**

**&#x20;**

下面的代码是自定义的MyWordCountAggregateFunction：

**&#x20;**

```java
public class MyWordCountAggregateFunction implements AggregateFunction<Tuple2<String, Integer>, Tuple2<String, Integer>, Tuple2<String, Integer>> {
    @Override
    public Tuple2<String, Integer> createAccumulator() {
        return Tuple2.of(null, 0); //创建初始值
    }
    @Override
    public Tuple2<String, Integer> add(Tuple2<String, Integer> input, Tuple2<String, Integer> accumulator) {
        Integer current = input.f1; //获取输入单词的次数
        Integer history = accumulator.f1; //获取单词的历史次数
        input.f1 = current + history; //将当前的次数和历史次数进行累加
        return input; //返回新的结果作为中间结果
    }
    @Override
    public Tuple2<String, Integer> getResult(Tuple2<String, Integer> accumulator) {
        return accumulator; //窗口触发时返回最终的计算结果
    }
    @Override
    public Tuple2<String, Integer> merge(Tuple2<String, Integer> a, Tuple2<String, Integer> b) {
        return null; //该案例使用的是滚动窗口，不会调用该方法，所以可以返回null
    }
}
```

&#x20;

下面代码是是主程序的部分代码：

&#x20;

```java
DataStream<Tuple2<String, Integer>> wordAndOne = ...
DataStream<Tuple2<String, Integer>> result = wordAndOne
        .keyBy(0) //指定分组的key
        .window(TumblingEventTimeWindows.of(Time.seconds(5))) //划分EventTime滚动窗口，窗口长度为5秒
        .aggregate(new MyWordCountAggregateFunction()); //调用aggregate方法并传入自定义的AggregateFunction
result.print(); //调用print sink 打印结果
env.execute("AggregateFunctionDemo");
```

&#x20;

**案例二：使用AggregateFunction实现在每一个窗口内求每个key平均数的功能**

**&#x20;**

下面的代码是自定义的MyAverageAggregateFunction：

&#x20;

```java
public class MyAverageAggregateFunction
        implements AggregateFunction<Tuple2<String, Long>, Tuple3<String, Long, Long>, Tuple2<String,Double>> {
    @Override
    public Tuple3<String, Long, Long> createAccumulator() {
        return Tuple3.of(null, 0L, 0L); //创建初始值
    }
    @Override
    public Tuple3<String, Long, Long> add(Tuple2<String, Long> value, Tuple3<String, Long, Long> accumulator) {
        String key = value.f0; //获取输入数据的key
        long total = accumulator.f1 + value.f1; //将输入的数字与中介结果相加
        long count = accumulator.f2 + 1; //个数+1
        return Tuple3.of(key,total, count); //返回Tuple3
    }
    @Override
    public Tuple2<String,Double> getResult(Tuple3<String, Long, Long> accumulator) {
        String key = accumulator.f0; //获取输入数据的key
        double avg = (double)accumulator.f1 / accumulator.f2;
        return Tuple2.of(key, avg); //总数除以个数计算出平均数
    }
    @Override
    public Tuple3<String, Long, Long> merge(Tuple3<String, Long, Long> a, Tuple3<String, Long, Long> b) {
        return Tuple3.of(a.f0, a.f1 + b.f1, a.f2 + b.f2); //session window合并是会调用该方法
    }
}
```

&#x20;

下面代码是是主程序的部分代码：



```java
DataStream<Tuple2<String, Long>> keyAndCount= ...
DataStream<Tuple2<String, Double>> result = keyAndCount.keyBy(0) //指定分组的key
        .window(TumblingEventTimeWindows.of(Time.seconds(5))) //划分滚动窗口
        .aggregate(new MyAverageAggregateFunction()); //调用aggregate传入自定义的AggregateFunction
result.print(); //调用print sink 打印结果
env.execute("AggregateFunctionDemo2");
```



## 4.3 ApplyFunction

Window的apply方法，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">是将进入到窗口中的数据先攒起来（保存到WindowState中），当窗口触发后，将缓存在窗口的数据取出来，进行全量的运算。</span>

* **NonKeyed Window**



没有keyBy，直接划分窗口，Window和WindowFunction所在的DataStream的并许度只能是1，即所有进入该窗口的数据都会被一个subtask实例先攒起来，窗口触发后，再调用apply方法进行处理。

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);
//将数据转成integer
SingleOutputStreamOperator<Integer> nums = lines.map(Integer::parseInt);
//没有keyBy,直接划分窗口
//countWindowAll没有keyBy，按照条数划分的窗口
AllWindowedStream<Integer, GlobalWindow> windowStream = nums.countWindowAll(5);
//apply是将窗口内的数据全部攒起来（WindowState）窗口触发前不会对数据进行计算
SingleOutputStreamOperator<Integer> resStream = windowStream.apply(new AllWindowFunction<Integer, Integer, GlobalWindow>() {
    /**
     * apply方法在窗口触发后，才会调用
     * @param window 窗口的类型
     * @param input 输出的数据，缓存在State中了，当窗口触发后，才会调用apply方法，
     * @param out
     * @throws Exception
     */
    @Override
    public void apply(GlobalWindow window, Iterable<Integer> input, Collector<Integer> out) throws Exception {

        int sum = 0;
        for (Integer i : input) { // 每次触发窗口会迭代数据
            sum += i;
        }
        //输出数据
        out.collect(sum);
    }
});
resStream.print();
env.execute();
```



* **Keyed Window**



先keyBy，再划分窗口，Window和WindowFunction所在的DataStream的是多并行的。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">数据先会按照key的hash分区方式进行分区，然后缓存起来，当窗口触发后，没有key都会调用一次apply方法，将缓存到该窗口中的同一个key的全部数据取出来进全量行处理</span>。

```java
//先keyBy再按照EventTime划分滚动窗口
KeyedStream<Tuple2<String, Integer>, String> keyedStream = tpStream.keyBy(t -> t.f0);
WindowedStream<Tuple2<String, Integer>, String, TimeWindow> windowedStream = keyedStream.window(TumblingEventTimeWindows.of(Time.seconds(10)));
SingleOutputStreamOperator<Tuple2<String, Integer>> res = windowedStream.apply(new WindowFunction<Tuple2<String, Integer>, Tuple2<String, Integer>, String, TimeWindow>() {
    @Override
    public void apply(String key, TimeWindow window, Iterable<Tuple2<String, Integer>> input, Collector<Tuple2<String, Integer>> out) throws Exception {
        //窗口触发后，会取出缓存在当前窗口中，同一个key的全部数据，然后按照次数排序
        ArrayList<Tuple2<String, Integer>> dataList = (ArrayList<Tuple2<String, Integer>>) input;
        dataList.sort((a, b) -> b.f1 - a.f1); //按照次数降序排序
        //输出当前窗口中，次数最大的top3, (由于缓存的同一个key的数据条件小于3，所以用Math.min取最小值，避免数组下标越界)
        for (int i = 0; i < Math.min(3, dataList.size()); i++) {
            out.collect(dataList.get(i));
        }
        
    }
});
res.print();
env.execute();
```

# **5 Trigger窗口触发器**

Trigger（窗口触发器）决定了窗口触发的时机并使用窗口函数处理窗口内的数据。每种WindowAssinger（窗口分配器）都带有一个默认的触发器，例如：ProcessingTime类型的Window使用的是ProcessingTimeTrigger，EventTime类型的Window使用的是EventTimeTrigger，CountWindow使用的是CountTrigger。如果默认触发器不能满足要求，可以调用trigger方法指定合适的触发器或者自定义的触发器，当传入了指定的触发器，默认的触发器就会被覆盖。

Flink中定义了Trigger抽象类，任何trigger都必须继承这个抽象类，并且需要实现其中的onElement、onProcessingTime、onEventTime、clear这4个抽象方法，以下是Trigger类的部分代码和方法的说明：



```java
/**
 * 窗口中每输入一条数据就会调用该方法
 * @param element 进入窗口的一条数据
 * @param timestamp 该数据对应的timestamp
 * @param window 该条数据所进入的窗口，
 * @param ctx 触发器上下文
 */
public abstract TriggerResult onElement(T element, long timestamp, W window, TriggerContext ctx) throws Exception;
/**
 * processing-time定时器执行时会调用该方法
 * @param time 定时器触发时所对应的timestamp
 * @param window 定时器触发时所对应的窗口
 * @param ctx 触发器上下文
 */
public abstract TriggerResult onProcessingTime(long time, W window, TriggerContext ctx) throws Exception;
//event-time定时器执行时会调用该方法
public abstract TriggerResult onEventTime(long time, W window, TriggerContext ctx) throws Exception;
//窗口清除的时候调用该方法
public abstract void clear(W window, TriggerContext ctx) throws Exception;
//当多个窗口被合并成一个窗口时该方法会被调用
public void onMerge(W window, OnMergeContext ctx) throws Exception {
   throw new UnsupportedOperationException("This trigger does not support merging.");
}
```

**onElement()**：窗口中每输入一条数据就会调用该方法，该方法的参数依次是：进入该窗口的对应的那条数据、该数据对应的timestamp、该数据所进入的窗口、触发器上下文。其中window参数可以取窗口的开始时间，结束时间，最大timestamp等, 可以将该数据对应timestamp和window中的时间进行比较和计算；TriggerContext参数可获取当前的ProcessingTime、当前的watermark、存储的状态信息、注册、删除ProcessingTime或EvenTime定时器。方法的返回值TriggerResult是枚举类，该枚举中的类型分别为CONTINUE、FIRE\_AND\_PURGE、FIRE和PURGE。其中CONTINUE代表当不触发前窗口，继续等待；FIRE\_AND\_PURGE代表触发当前窗口，输出窗口计算的结果，并清除该窗口中的数据；FIRE代表触发当前窗口，输出窗口计算的结果，并保留该窗口中的数据；PURGE代表不触发窗口，并清除窗口内的数据。

**onProcessingTime()**：ProcessingTime定时器执行时会调用该方法，该方法的参数依次是：定时器触发时所对应的timestamp、定时器触发时所对应的窗口、触发器上下文。方法的返回值TriggerResult决定窗口的处理方式。

**onEventTime()**：EventTime定时器执行时会调用该方法，该方法的参数依次是：定时器触发时所对应的timestamp、定时器触发时所对应的窗口、触发器上下文。方法的返回值TriggerResult决定窗口的处理方式。

**clear()**：窗口清除的时候调用该方法，该方法的参数依次是：要清除的窗口、触发器上下文。该方法通过触发器上下文清除窗口中的状态、删除对应时间的定时器。

**onMerge()**：当多个窗口被合并成一个窗口时该方法会被调用，用来合并窗口中的数据。该方法的参数依次是：合并之后的窗口，merge时的上下文。该方法只针对MergingWindowAssigner类型的窗口有效，即只有SessionWindow类型的窗口可能会调用该方法，因为只有SessionWindow类型的窗口继承了MergingWindowAssigner这个抽象类。



### **5.1 CountTrigger**

根据窗口中的数据的数量决定窗口是否触发。CountTrigger需要调用其静态的of方法并指定一个long类型的阈值进行初始化，例如CountTrigger.of(5)。如果是Non-Keyed Windows（未分组的窗口），窗口触发的条件是窗口内的数据的数量大于等于指定的阈值就触发窗口执行；如果是Keyed Windows（分组的窗口），窗口触发的条件是一个组内的数据的数量大于等于指定的阈值就触发窗口执行。下面是CounterTrigger的核心的代码：

```java
//窗口内数据最大的数量，大于等于该值该窗口就触发
private final long maxCount; 
//定义一个可以累加的状态描述器
private final ReducingStateDescriptor<Long> stateDesc = new ReducingStateDescriptor<>("count", new Sum(), LongSerializer.INSTANCE);
//用来进行状态聚合的Function，实现的逻辑是相加
private static class Sum implements ReduceFunction<Long> {
   @Override
   public Long reduce(Long value1, Long value2) throws Exception {
      return value1 + value2;
   }
}
@Override
public TriggerResult onElement(Object element, long timestamp, W window, TriggerContext ctx) throws Exception {
   //通过TriggerContext获取当前窗口或对应key的组的状态，用来记录窗口内或组内数据量的计算器，可以累加和清空
   ReducingState<Long> count = ctx.getPartitionedState(stateDesc); 
   count.add(1L); //窗口内进入一条数据，count+=1
   if (count.get() >= maxCount) { //从state中取出计数器的数量，如果大于等于指定的maxCount
      count.clear(); //清空状态，重置计数器
      return TriggerResult.FIRE; //返回TriggerResult.FIRE枚举类型，触发窗口执行
   }
   return TriggerResult.CONTINUE; //返回TriggerResult.CONTINUE枚举类型，不触发窗口执行，继续向该窗口内接入数据
}
@Override
public TriggerResult onEventTime(long time, W window, TriggerContext ctx) {
   return TriggerResult.CONTINUE; //CountTrigger与时间无关，返回TriggerResult.CONTINUE，不触发窗口
}
@Override
public TriggerResult onProcessingTime(long time, W window, TriggerContext ctx) throws Exception {
   return TriggerResult.CONTINUE; //CountTrigger与时间无关，返回TriggerResult.CONTINUE，不触发窗口
}
@Override
public void clear(W window, TriggerContext ctx) throws Exception {
   ctx.getPartitionedState(stateDesc).clear(); //窗口清除时，同时清除该对应的状态
}
```



> **原理深入：**&#x5206;析CountTriggger的源代码后可以发现：窗口中每输入一条数据就会调用一次onElement方法，CountTrigger的最核心逻辑就是在onElement方法中了，窗口每输入一条数据就要使用一个计数器计数并且判断当前窗口的数据条数是否大于等于指定的阈值，如果计数器大于等于指定的阈值，就返回TriggerResult.FIRE，触发窗口执行。需要强调的是，上面的代码中用来记录窗口内数据量的<span style="color: inherit; background-color: rgba(183,237,177,0.8)">计数器必须使用Flink的State，并且要定义一个StateDescriptor和ReudceFunction</span>，每输入一条数据就通过TriggerContext的getPartitionedState方法传入事先定义好的StateDescriptor获取状态，使用状态持有的计数器进行计数或判断。因为Flink的状态在Checkpointing时可以数据持久化到指定StateBackend中，任务失败Task重启可以从StateBackend中恢复上一次Checkpointing成功的状态。如果使用一个int或long类型的成员变量作为计数器，在任务组出现异常时，计数器无法恢复，会造成窗口触发时的数量和指定的阈值不一致。



### **5.2 ProcessingTimeTrigger**

根据ProcessingTime决定窗口是否触发，即window operator所在机器的系统时间。如果ProcessingTime大于等于window的maxTimestamp，窗口就触发执行。ProcessingTimeTrigger需要调用其静态的create方法进行初始化，例如ProcessingTimeTrigger.create()。下面是CounterTrigger的核心的代码：

```java
@Override
public TriggerResult onElement(Object element, long timestamp, TimeWindow window, TriggerContext ctx) {
   ctx.registerProcessingTimeTimer(window.maxTimestamp()); //使用windw的maxTimestamp注册ProcessingTimeTimer定时器
   return TriggerResult.CONTINUE; //返回TriggerResult.CONTINUE，不触发窗口
}
@Override
public TriggerResult onEventTime(long time, TimeWindow window, TriggerContext ctx) throws Exception {
   return TriggerResult.CONTINUE;  //与EventTime无关，返回TriggerResult.CONTINUE，不触发窗口
}
@Override
public TriggerResult onProcessingTime(long time, TimeWindow window, TriggerContext ctx) {
   return TriggerResult.FIRE; //触发窗口执行，并输出结果
}
@Override
public void clear(TimeWindow window, TriggerContext ctx) throws Exception {
   ctx.deleteProcessingTimeTimer(window.maxTimestamp()); //删除对应时间的ProcessingTimeTimer定时器
}
```



> **原理深入**：分析ProcessingTimeTriggger的源代码后可以发现：窗口中每输入一条数据就会调用一次onElement方法。，在onElement方法中可以通过TriggerContext的registerProcessingTimeTimer传入窗口触发的时间注册一个定期器，这个时间就是window的maxTimestamp，并将该时间用TimerHeapInternalTimer对象包装后，丢入到一个HeapPriorityQueueSet中，时间相同的TimerHeapInternalTimer如果多次注册前面的就会被覆盖。然后使用ProcessingTimeService注册一个定时器，就是调用ScheduledThreadPoolExecutor的schedule方法，向线程池中丢入一个实现Runnable接口的TriggerTask的实例。通过registerProcessingTimeTimer方法传入的时间和当前系统的ProcessingTime，会计算出一个delay时间，那么TriggerTask的run方法就一定会在指定的注册时间执行，并且在该run方法中经过一系列的调用，最终调用onProcessingTime方法，触发窗口计算。最后调用clear方法，再调用TriggerContext的deleteProcessingTimeTimer删除对应时间的定时器。



### **5.3 EventTimeTriggger**

根据EventTime决定窗口是否触发，即根据输入数据的EventTime计算出watermark（窗口内最大的EventTime - 延迟时间），如果watermark大于等于window的maxTimestamp，窗口就触发执行。EventTimeTrigger需要调用其静态的create方法进行初始化，例如EventTimeTrigger.create()。下面是EventTimeTrigger的核心的代码：

```java
@Override
public TriggerResult onElement(Object element, long timestamp, TimeWindow window, TriggerContext ctx) throws Exception {
   if (window.maxTimestamp() <= ctx.getCurrentWatermark()) {
      // 如果当前的watermark已经大于等于window的maxTimestamp，立即触发窗口
      return TriggerResult.FIRE;
   } else {
      //使用windw的maxTimestamp注册EventTimeTimer定时器
      ctx.registerEventTimeTimer(window.maxTimestamp());
      return TriggerResult.CONTINUE; //返回TriggerResult.CONTINUE，不触发窗口
   }
}
@Override
public TriggerResult onEventTime(long time, TimeWindow window, TriggerContext ctx) {
//判断当前的watermark时间，是否等于window的maxTimestamp，如果等于，就触发
   return time == window.maxTimestamp() ? TriggerResult.FIRE : TriggerResult.CONTINUE;
}
@Override
public TriggerResult onProcessingTime(long time, TimeWindow window, TriggerContext ctx) throws Exception {
   return TriggerResult.CONTINUE; //与ProcessingTime无关，返回TriggerResult.CONTINUE，不触发窗口
}
@Override
public void clear(TimeWindow window, TriggerContext ctx) throws Exception {
   ctx.deleteEventTimeTimer(window.maxTimestamp()); //删除对应时间的EventTimeTimer定时器
}
```



> **原理深入**：分析EventTimeTriggger的源代码后可以发现：Source接收到一条数据，就会提取数据中的EventTime并生成watermark，当窗口中每输入一条数据就会调用一次onElement方法，在onElement方法中首先使用当前的watermark和window的maxTimestamp进行判断，如果当前的watermark已经大于等于window的maxTimestamp，立即触发窗口。如果小于，就通过TriggerContext的registerEventTimeTimer传入窗口触发的时间注册一个定期器，这个时间就是window的maxTimestamp，并将该时间用TimerHeapInternalTimer对象包装后，丢入到一个HeapPriorityQueueSet中，时间相同的TimerHeapInternalTimer如果多次注册前面的就会被覆盖。接下来会在InternalTimerServiceImpl的advanceWatermark方法中，会将HeapPriorityQueueSet中的TimerHeapInternalTimer取出来，如果当前的watermark大于等于TimerHeapInternalTimer中的时间，就会最终调用onEventTime方法，触发窗口计算。最后调用clear方法，再调用TriggerContext的deleteEventTimeTimer删除对应时间的定时器。



### **5.4 自定义Trigger**

Flink虽然提供了一些默认的Trigger，可以满足绝大多数的场景，但是有一些特殊场景，需要用户自定义Trigger。例如使用TimeWindow类的窗口，窗口还没有到达触发的时间，但是窗口内已经有了大量的数据，并且数据还继续不停地输入，如果不触发将窗口，会占用大量的内存资源，甚至有造成内存溢出的风险。如果使用CountWindow，在有些时候，窗口内的数据很长时间也没有达到触发条件的数量，窗口就会一直不触发，从而造成延迟过高。鉴于以上两种特殊情况，就我们可以自定义一个Trigger，不但可以根据时间触发窗口，还可以根据窗口内数据的数量触发窗口，这两个条件满足其一窗口就可以触发计算。

下面的代码就是自定义一个Trigger，同时使用ProcessingTime和Count触发窗口，为了方便大家理解，先没有使用state作为计数器，而是使用一个int类型的成员变量作为计数器，在任务失败重启后，计数器会失效。其核心的代码在onElement方法中，窗口每输入一条数据，就会调用onElement方法，首先将计数器count++，如果窗口内的数据条数大于等于指定的阈值，就将count重置为0，返回TriggerResult.FIRE\_AND\_PURGE，即触发窗口、输出计算结果并清空窗口内的数据。如果窗口内数据的条数不满足触发条件，就使用TriggerContext的registerProcessingTimeTimer方法注册一个定期器，并返回TriggerResult.CONTINUE。在定时器执触发后，会调用onProcessingTime方法并返回TriggerResult.FIRE触发窗口执行，最后在clear方法中将count重置为0并删除定时器。



```java
private int count; //使用成员变量定义计数器（无法容错）
private final int maxCount; //指定窗口触发的数据条数
@Override
public TriggerResult onElement(Object element, long timestamp, TimeWindow window, TriggerContext ctx) throws Exception {
    count++; //进入窗口一条数据count就+1
    if (count >= maxCount) { //如果窗前内的数据条数大于等于指定的阈值
        count = 0; //重置计数器
        return TriggerResult.FIRE_AND_PURGE; //窗口触发并清空窗口内的数据
    } else {
        ctx.registerProcessingTimeTimer(window.maxTimestamp()); //使用window的maxTimestamp注册ProcessingTimeTimer定时器
        return TriggerResult.CONTINUE; //该窗口继续进入数据，不触发
    }
}
@Override
public TriggerResult onProcessingTime(long time, TimeWindow window, TriggerContext ctx) throws Exception {
    return TriggerResult.FIRE; //触发窗口执行
}
@Override
public void clear(W window, TriggerContext ctx) throws Exception {
    count = 0; //重置计数器
    ctx.deleteProcessingTimeTimer(window.maxTimestamp()); //删除对应时间的ProcessingTimeTimer定时器
}
```



下面的代码是结合了CountTrigger和ProcessingTimeTrigger自定义的ProcessingTimeTriggerWithCounter ，并且使用state作为计数器，同时可以按照窗口内的数据的数量和ProcessingTime触发窗口。代码的细节已经在前面介绍过了，这里就不赘述了。

```java
public class ProcessingTimeTriggerWithCounter extends Trigger<Object, TimeWindow> {
    private final long maxCount;
//定义一个可以累加的状态描述器
    private final ReducingStateDescriptor<Long> stateDesc = new ReducingStateDescriptor<>("count", new Sum(), Long.class);
     //用来进行状态聚合的Function，实现的逻辑是相加
    private static class Sum implements ReduceFunction<Long> {
        @Override
        public Long reduce(Long value1, Long value2) throws Exception {
            return value1 + value2;
        }
    }
    private ProcessingTimeTriggerWithCounter(int maxCount) {
        this.maxCount = maxCount;
    }
    public static ProcessingTimeTriggerWithCounter create(int maxCount) {
        return new ProcessingTimeTriggerWithCounter(maxCount);
    }
    @Override
    public TriggerResult onElement(Object element, long timestamp, TimeWindow window, TriggerContext ctx) throws Exception {
        ReducingState<Long> count = ctx.getPartitionedState(stateDesc);  //通过TriggerContext获取当前窗的状态
        count.add(1L); //窗口内进入一条数据，count+=1
        if (count.get() >= maxCount) {
            clear(window, ctx); //清空状态和删除定时器
            return TriggerResult.FIRE_AND_PURGE; 
        } else {
            ctx.registerProcessingTimeTimer(window.maxTimestamp());
            return TriggerResult.CONTINUE;
        }
    }
    @Override
    public TriggerResult onProcessingTime(long time, TimeWindow window, TriggerContext ctx) throws Exception {
        clear(window, ctx); //清空状态和删除定时器
        return TriggerResult.FIRE;
    }
    @Override
    public TriggerResult onEventTime(long time, TimeWindow window, TriggerContext ctx) throws Exception {
        return TriggerResult.CONTINUE; //与EventTime无关，返回TriggerResult.CONTINUE，不触发窗口
    }
    @Override
    public void clear(TimeWindow window, TriggerContext ctx) throws Exception {
        ctx.getPartitionedState(stateDesc).clear(); //清空状态
        ctx.deleteProcessingTimeTimer(window.maxTimestamp()); //删除定时器
    }
}
```

下面的代码是在flink程序中，使用自定义的Trigger：

```java
//先分组再划分窗口
KeyedStream<Tuple2<String, Integer>, Tuple> keyed = wordAndOne.keyBy(0);
WindowedStream<Tuple2<String, Integer>, Tuple, TimeWindow> window = keyed
        .window(TumblingProcessingTimeWindows.of(Time.seconds(10))) //划分ProcessingTime滚动窗口
        .trigger(ProcessingTimeTriggerWithCounter.create(5)); //传入自定义的Trigger
DataStream<Tuple2<String, Integer>> summed = window.sum(1);
```



# **6 Evictors数据剔除器**

在使用Flink DataStream划分窗口对数据进行处理时，可以选择性的调用evictor方法并传入相应的Evictor对进入WindowFunction前后的数据进行剔除处理，默认的Evictors都是在WindowFunction计算之前对数据进行剔除处理的，所以Evictor的功能就是将满足具体Evictor条件的数据从该窗口对应的迭代器中移除。Flink本身实现了三种Evictor，其中有CountEvictor，TimeEvictor和DeltaEvictor，它们都实现了一个共同的Evictor接口，其中的两个方法evictBefore和evictAfter分别用来决定是在调用WindowFunction计算之前还是调用WindowFunction计算之后对数据进行剔除处理，也可以根据实际需求该实现该接口自定义数据剔除器。以下代码是Evictor接口中的两个方法的和方法的说明：



```java
/**
 * 在调用WindowFunction计算之前对数据进行剔除处理
 * @param elements 当前窗口中数据对应的迭代器
 * @param size 当前窗口中数据的条数
 * @param window 当前窗口对象Window
 * @param evictorContext Evictor上下文
 */
void evictBefore(Iterable<TimestampedValue<T>> elements, int size, W window, EvictorContext evictorContext);
//在调用WindowFunction计算之后对数据进行剔除处理
void evictAfter(Iterable<TimestampedValue<T>> elements, int size, W window, EvictorContext evictorContext);
```

**evictBefore()**：在调用WindowFunction计算之前对数据进行剔除处理，该方法的参数依次是：当前窗口中数据对应的迭代器、当前窗口中数据的条数，当前窗口对象Window、Evictor上下文。其中window参数可以取窗口的开始时间，结束时间，最大timestamp等；EvictorContext参数可以获取当前的ProcessingTime和watermark。

**evictAfter()**：在调用WindowFunction计算之后对数据进行剔除处理：该方法的参数依次是：当前窗口中数据对应的迭代器、当前窗口中数据的条数，当前窗口对象Window、Evictor上下文



### **6.1 CountEvictor**

根据窗口中数据的数量作为判断标准，决定数据是否会被移除，即在窗口中保存固定数量的数据，如果超过指定数量就将数据在该窗口中移&#x9664;**。**&#x43;ountEvictor有两个重载的静态of方法，如果传入一个int类型参数，就是指在调用WindowFunction之前，如果窗口内数据的条数超过指定的条数就剔除；传入两个参数时，如果第二个boolean类型的参数为true，就是指在调用WindowFunction之后，如果数据的条数超过指定的条数就剔除。下面的代码是分别创建两个CountEvictor：

```java
DataStream<Integer> numbers = ...
//对window调用evictor方法并传入一个CountEvictor，在调用WindowFunction之前，如果数据的条数超过5就剔除
AllWindowedStream<Integer, TimeWindow> window = numbers
        .timeWindowAll(Time.seconds(5)) //使用不分组的滚动窗口，窗口长度为5秒
        .evictor(CountEvictor.of(5)); 
//对window调用evictor方法并传入一个CountEvictor，在调用WindowFunction之后，如果数据的条数超过5就剔除
//numbers.timeWindowAll(Time.seconds(5)).evictor(CountEvictor.of(5, true));
```



需要注意的是，如果是Keyed Windows（分组的窗口），调用evictor方法传入CountEvictor.of(5)是将窗口内的每一个组数据进行剔除，即每一个组最多保留5条数据。



KeyedStream\<Tuple2\<String, Integer>, Tuple> keyed = wordAndOne.keyBy(<span style="color: rgb(100,37,208); background-color: inherit">0</span>);
WindowedStream\<Tuple2\<String, Integer>, Tuple, TimeWindow> window = keyed
&#x20;       .timeWindow(Time.*seconds*(<span style="color: rgb(100,37,208); background-color: inherit">5</span>)) *<span style="color: rgb(143,149,158); background-color: inherit">//分组后划分timeWindow</span>*
&#x20;       .evictor(CountEvictor.*of*(<span style="color: rgb(100,37,208); background-color: inherit">5</span>)); *<span style="color: rgb(143,149,158); background-color: inherit">//调用evictor方法传入CountEvictor，即每一个组最多保留5条数据</span>*



**源码分析**：下面是CountEvictor的核心代码：

```java
@Override
public void evictBefore(Iterable<TimestampedValue<Object>> elements, int size, W window, EvictorContext ctx) {
   if (!doEvictAfter) { // doEvictAfter默认为false，取反为true，即在调用WindowFunction之前对数据进行剔除
      evict(elements, size, ctx); //调用evict方法实现剔除逻辑
   }
}
@Override
public void evictAfter(Iterable<TimestampedValue<Object>> elements, int size, W window, EvictorContext ctx) {
// 只有调用CountEvictor.of(5, true)方法，第二个参数传入true时才满足条件，即在调用WindowFunction之后对数据进行剔除
   if (doEvictAfter) { 
      evict(elements, size, ctx); //调用evict方法实现剔除逻辑
   }
}
private void evict(Iterable<TimestampedValue<Object>> elements, int size, EvictorContext ctx) {
   if (size <= maxCount) {  //如果窗口中的数据条数小于等于CountEvictor指定的条数，之间return，不执行剔除逻辑
      return;
   } else {
      int evictedCount = 0; //定义窗口中已经移除数据的条数
      for (Iterator<TimestampedValue<Object>> iterator = elements.iterator(); iterator.hasNext();){
         iterator.next(); //迭代一条数据条数
         evictedCount++;  //窗口中已移除数据的条数+1
         if (evictedCount > size - maxCount) {
            break; //已经移除数据的条数 > 如果窗口中数据的数量 - 窗口中最大表露的数据，就跳出循环，结束该Evictor的逻辑
         } else {
            iterator.remove(); //已经移除数据的条数 <= 如果窗口中数据的数量 - 窗口中最大表露的数据，就继续移除
         }
      }
   }
}
```



> **原理深入**：分析CountEvictor的源代码后可以发现：evict方法中定义一个自增变量evictedCount来控制已经剔除数据的数量。例如size=8（整个窗口中数据的数量），maxCount=5（窗口中保留数据的数量）时，当for循环4次时即evictedCount自增4次，就会走break的逻辑跳出循环，结束该Evictor的逻辑，即总共调用迭代器的remove方法3次，Evictor从窗口头部开始丢弃其余元素从而达到剔处窗口中多余数据的目的。



### **6.2 TimeEvictor**

根据窗口中数据的时间作为判断标准，决定数据是否会被剔除，即在窗口中保留最近一段时间内的数据，如果超过指定时间将数据在该窗口中剔&#x9664;**。**

下面是使用TimeEvictor的示例代码：

```java
AllWindowedStream<Integer, TimeWindow> window = numbers
        .timeWindowAll(Time.seconds(5)) //使用不分组的滚动窗口
        .evictor(TimeEvictor.of(Time.seconds(2))); //保留窗口中距离最大时间最近2秒的数据
```

如果是Non-Keyed Windows（未分组的窗口）使用TimeEvictor，指定的时间为2秒，就是保留距离整个窗口中的最大时间最近2秒的数据。

```java
WindowedStream<Tuple2<String, Integer>, Tuple, TimeWindow> window = keyed
        .timeWindow(Time.seconds(5)) //分组后划分窗口，
        .evictor(TimeEvictor.of(Time.seconds(2))); //传入TimeEvictor保留每个组内时间最大的那条数据相邻最近2秒的数据
```

如果是Keyed Windows（分组的窗口）使用TimeEvictor，指定的时间为2秒，就是保留距离每个组口中的最大时间最近2秒的数据。

下面是TimeEvictor中的核心代码：



```java
private void evict(Iterable<TimestampedValue<Object>> elements, int size, EvictorContext ctx) {
   if (!hasTimestamp(elements)) {
      return; //如果数据中没有timestamp，直接返回
   }
   long currentTime = getMaxTimestamp(elements); //获取该窗口或该窗口一个组内数据的最大时间
   long evictCutoff = currentTime - windowSize; //剔除的截止时间 = 数据的最大时间 - TimeEvictor的size
   for (Iterator<TimestampedValue<Object>> iterator = elements.iterator(); iterator.hasNext(); ) {
      TimestampedValue<Object> record = iterator.next(); //遍历窗口中的每一条数据
      if (record.getTimestamp() <= evictCutoff) {
         iterator.remove(); //如果该数据的timestamp <= 剔除的截止时间就移除
      }
   }
}
```



> **原理深入**：分析TimeEvictor的源代码后可以发现：在evict方法中，首先判断数据中是否包含timestamp，如果没有timestamp，立即return，不剔除任何数据。如果有timestamp，先计算出当前窗口的最大timestamp（如果是Non-Keyed Windows，这个最大时间指的是整个窗口中的最大时间，如果是Keyed Windows这个最大时间指的是窗口中当前key所在组中的最大时间），然后用这个最大的timestamp减去定义TimeEvictor时指定的size，得到一个evictCutoff作为要剔除的数据的截止时间。然后遍历窗口中的每一条数据，如果数据的timestamp小于等于evictCutoff，就将该数据从窗口中剔除。



### **6.3 DeltaEvictor**

DeltaEvictor需要指定一个threshold（阈值）和一个DeltaFunction函数，通过传入每条数据和最后一条数据，使用DeltaFunction计算后得到一个值，并将这个值与指定的threshold进行对比，如果函数计算结果大于等于threshold，则该元素会被移除。

下面是使用TimeEvictor的示例代码，分组后划分timeWindow，调用evictor方法传入DeltaEvictor，在DeltaEvictor的of方法中，传入一个double类型的阈值和一个DeltaFunction的匿名内部类的实现，功能是：用窗口中当前key所在组中的最后一条数据的Integer减去当前数据的Integer，如果大于等1.0就保留，小于1.0就剔除。

```java
//分组后划分窗口，然后在调用evictor方法，传入DeltaEvictor,并指定一个double类型的阈值和一个函数
WindowedStream<Tuple2<String, Integer>, Tuple, TimeWindow> window = keyed
        .timeWindow(Time.seconds(5))
        .evictor(DeltaEvictor.of(1.0, new DeltaFunction<Tuple2<String, Integer>>() {
            @Override
            public double getDelta(Tuple2<String, Integer> current, Tuple2<String, Integer> last) {
                return last.f1 - current.f1;
            }
        }));
```

下面是DeltaEvictor中的核心代码：

```java
private void evict(Iterable<TimestampedValue<T>> elements, int size, EvictorContext ctx) {
   TimestampedValue<T> lastElement = Iterables.getLast(elements); //获取该窗口或该窗口一个组内最后一条数据
   for (Iterator<TimestampedValue<T>> iterator = elements.iterator(); iterator.hasNext();){
      TimestampedValue<T> element = iterator.next(); //迭代出窗口中的每一条数据
      if (deltaFunction.getDelta(element.getValue(), lastElement.getValue()) >= this.threshold) {
         iterator.remove(); //应用外部传入的计算逻辑，并分别传入当前的数据和窗口的最后一条数据，运行后的值大于指定的阈值就移除
      }
   }
}
```



> **原理深入**：分析DeltaEvictor的源代码后可以发现：在evict方法中，首先获取当前窗口中的最后一条数据（如果是Non-Keyed Windows，是指整个窗口中的最后输入的那一条数据，如果是Keyed Windows是指窗口中当前key所在组中的最后输入的那一条数据）。然后遍历窗口中的每一条数据，应传入的DeltaFunction，如果经过该函数的计算返回值大于等于指定的阈值，就将该数据从窗口中剔除。

