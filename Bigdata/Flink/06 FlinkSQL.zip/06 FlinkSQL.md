# **1 FlinkSQL快速认识**

## **1.1 基本原理和架构**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">flink sql是架构于flink core之上用sql语义方便快捷地进行结构化数据处理的上层库；（非常类似sparksql和sparkcore的关系）。</span>



### **1.1.1 整体架构和工作流程**

核心工作原理如下：

* 将源数据流（数据集），绑定元数据（schema）后，注册成catalog中的表（table、view）；

* 然后由用户通过table Api或者 table sql来表达计算逻辑；

* 由table-planner利用apache calcite进行sql语法解析，绑定元数据得到逻辑执行计划；

* 再用Optimizer进行优化后，得到物理执行计划

* 物理计划经过代码生成器生成代码，得到Transformation Tree

* Transformation Tree 转成JobGraph后提交到flink集群执行



![](<images/06 FlinkSQL-image-10.png>)



### **1.1.2 关于元数据管理catalog**

元数据，即描述数据的数据。简单来说，我们创建一个table之后，这个table叫什么名字、有哪些字段、字段类型，分区等信息。这都是元数据需要知道的东西，所以元数据是描述数据的数据

catalog⽤来保存元数据（数据库、表结构、分区、视图、函数等等）,Flink也提供 了catalog，当然也可以在Flink中使⽤Hive的catalog。



![](<images/06 FlinkSQL-image-14.png>)



![](<images/06 FlinkSQL-image-8.png>)



### **1.1.3 关于逻辑执行计划**



![](<images/06 FlinkSQL-image-9.png>)



### **1.1.4 关于查询优化**



![](<images/06 FlinkSQL-image-7.png>)



FlinkSQL中有<span style="color: inherit; background-color: rgba(255,246,122,0.8)">两个优化器</span>，分别是：RBO（基于规则的优化器）和 CBO（基于代价（成本）的优化器）



* **RBO（基于规则的优化器）**

遍历一系列规则（RelOptRule），只要满足条件就对原来的计划节点（表达式）进行转换或调整位置，生成最终的执行计划。常见的规则包括：

* 分区裁剪（Partition Prune）、列裁剪

* 谓词下推（Predicate Pushdown）、投影下推（Projection Pushdown）、聚合下推、limit下推、sort下推

* 常量折叠（Constant Folding）

* 子查询内联转join等。



下面是RBO优化示意图举例：

![](<images/06 FlinkSQL-image-6.png>)



![](<images/06 FlinkSQL-image-3.png>)



![](<images/06 FlinkSQL-image-4.png>)



* **CBO（基于代价的优化器）**

会保留原有表达式，基于统计信息和代价模型，尝试探索生成等价关系表达式，最终取代价最小的执行计划。CBO的实现有两种模型，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Volcano模型</span>和<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Cascades模型</span>

这两种模型思想很是相似，不同点在于Cascades模型一边遍历SQL逻辑树，一边优化，从而进一步裁剪掉一些执行计划。

下面是CBO优化示意图举例，根据代价cost选择批处理join有方式(sortmergejoin，hashjoin，boradcasthashjoin)。比如前文中的例子，再filter下推之后，在t2.id<1000的情况下，由1 百万数据量变为了1 千条，计算cost之后，使用broadcasthashjoin最合适。

![](<images/06 FlinkSQL-image-12.png>)

## 1.2<u> 动态表特性</u>

与spark、hive等组件中的“表”的最大不同之处：<span style="color: inherit; background-color: rgb(255,233,40)">FlinkSQL中的表是</span>**<span style="color: inherit; background-color: rgb(255,233,40)">动态表</span>**<span style="color: inherit; background-color: rgb(255,233,40)">！</span>这是因为：<span style="color: inherit; background-color: rgba(186,206,253,0.7)">flink对数据的核心抽象是“无界（或有界）的数据流”，对数据处理过程的核心抽象是“流式持续处理”。</span> <span style="color: inherit; background-color: rgb(255,233,40)">因此，FlinkSQL对“源表（动态表）”的计算及输出结果（结果表），也是流式、动态、持续的；</span>动态表的有以下特点：

* 数据源的数据&#x662F;**<span style="color: rgb(216,57,49); background-color: inherit">持续输入</span>**

* 查询过程&#x662F;**<span style="color: rgb(216,57,49); background-color: inherit">持续计算</span>**

* 查询结果&#x662F;**<span style="color: rgb(216,57,49); background-color: inherit">持续输出</span>**



如下图所示：“源表clicks”是流式动态的；“聚合查询的输出结果表”，也是流式动态的。

![](<images/06 FlinkSQL-image-5.png>)

这其中&#x7684;**<span style="color: rgb(216,57,49); background-color: inherit">动态</span>**，不仅体现在“数据追加”，对于输出结果表来说，“动态”还包含对“前序输出结果”的“撤回（删除）”、“更新”等模式；

<u><span style="color: inherit; background-color: rgba(222,224,227,0.8)">那么FlinkSQL是如何将这种对于“前序输出的修正”表达给下游呢？</span></u>

它&#x7684;**<span style="color: rgb(100,37,208); background-color: inherit">核心设计</span>**&#x662F;在底层的数据流中为每条数据添加<span style="color: inherit; background-color: rgb(255,233,40)">“ChangeMode（修正模式）标记”</span>，而添加了这种ChangeMode标记的底层数据流，取名为<span style="color: inherit; background-color: rgb(255,233,40)">changelogStream</span>



在flink1.12之前，动态表所对应的底层stream，有3种分别是：<span style="color: inherit; background-color: rgb(255,233,40)">Append-only stream</span>、<span style="color: inherit; background-color: rgb(255,233,40)">Retract stream </span>和 <span style="color: inherit; background-color: rgb(255,233,40)">Upsert stream</span>。

<span style="color: inherit; background-color: rgb(255,233,40)">现在，统称为changelog stream</span>

![](<images/06 FlinkSQL-image-13.png>)



# **2** **FlinkSQL编程概览**

## **2.1 FlinkSQL程序结构**



* **开发FlinkSQL程序需要导入以下所需依赖：**

```xml
<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-table-common</artifactId>
    <version>${flink.version}</version>
</dependency>

<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-table-planner_2.12</artifactId>
    <version>${flink.version}</version>
</dependency>

<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-table-api-java-bridge</artifactId>
    <version>${flink.version}</version>
</dependency>

<!--Flink SQL解析CSV -->
<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-csv</artifactId>
    <version>${flink.version}</version>
</dependency>

<!--Flink SQL解析JSON -->
<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-json</artifactId>
    <version>${flink.version}</version>
</dependency>
```

注意：使用Flink 1.15.2版本的FlinkSQL与以前引入到flink-connector-redis\_2.12有冲突，导致程序运行出错(NoSuchMethodError)，排除老版本的依赖：

```xml
<dependency>
    <groupId>org.apache.bahir</groupId>
    <artifactId>flink-connector-redis_2.12</artifactId>
    <version>1.1.0</version>
    <!-- 排除指定的传递依赖 -->
    <exclusions>
        <exclusion>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-streaming-java_2.12</artifactId>
        </exclusion>
        <exclusion>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-table-api-java</artifactId>
        </exclusion>
        <exclusion>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-table-api-java-bridge_2.12</artifactId>
        </exclusion>
    </exclusions>
</dependency>
```



* **Flinksql编程4步曲**

1. 创建flinksql编程入口(StreamTableEnvironment)

2. 将数据源关联schema后，转换成表（视图）

3. 执行sql语义的查询（sql语法或者tableapi）

4. 将查询结果输出到目标表



```java
import org.apache.flink.table.api.*;
import org.apache.flink.connector.datagen.table.DataGenOptions;

// 创建table编程入口环境.
TableEnvironment tableEnv = TableEnvironment.create(/*…*/);

// 创建一个源表
tableEnv.createTemporaryTable("SourceTable", TableDescriptor.forConnector("kafka")
    .schema(Schema.newBuilder()
      .column("f0", DataTypes.STRING())
      .build())
    .option(DataGenOptions.ROWS_PER_SECOND, 100)
    .build());

// 创建一个目标表
tableEnv.executeSql("CREATE TEMPORARY TABLE SinkTable WITH ('connector' = 'kafka') LIKE SourceTable");
// 执行查询并输出结果
tableEnv.executeSql("INSERT INTO SinkTable SELECT * FROM SourceTable");
```



## **2.2 Table Environment**

<span style="color: inherit; background-color: rgb(255,233,40)">FlinkSQL的编程，总是从一个入口环境</span>**<span style="color: rgb(100,37,208); background-color: rgb(255,233,40)">TableEnvironment</span>**<span style="color: inherit; background-color: rgb(255,233,40)">开始；TableEnvironment的主要功能如下：</span>

* 注册catalogs

* 向catalog注册表

* 加载可插拔模块（目前有hive module，以用于扩展支持hive的语法、函数等）

* 执行sql查询（sql解析，查询计划生成，job提交）

* 注册用户自定义函数

* 提供datastream和table之间的互转



* 创建方式1（直接创建TableEnvironment）

```java
EnvironmentSettings settings = EnvironmentSettings
    .newInstance()
    .inStreamingMode() //流处理模式
    //.inBatchMode()   //批处理模式
    .build();
TableEnvironment tEnv = TableEnvironment.create(settings);
```



* 创建方式2（从StreamExecutionEnvironment创建，这样便于结合sql和stream编程）

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
StreamTableEnvironment tEnv = StreamTableEnvironment.create(env);
```



## **2.3 两种编程方式**

FlinkSQL提供两种编程方式：<span style="color: inherit; background-color: rgb(255,233,40)">Table Api</span>和<span style="color: inherit; background-color: rgb(255,233,40)">Table Sql，</span>类比sparksql的DataFrame api编程和SQL编程，即可快速理解。

### **2.3.1 Table Api 方式**

Table API是一个与编程语言（scala、java、python）集成的查询API；与SQL不同，查询逻辑不是以字符串表达，而是在“宿主语言”中调用所提供的类、方法等。&#x20;

复杂的运算可以通过调用多个方法组成；如： table.filter(...).groupBy(...).select(... ).join(....).on(...)

&#x20;下面是TableAPI 代码示例：

```java
// 创建入口
TableEnvironment tableEnv = ...; /
// 注册orders表
// 注册结果表sinkTable

// 利用env.from方法，得到Table对象
Table orders = tableEnv.from("Orders");
Table sinkTable= tableEnv.from("sinkTable");

// 执行查询："中国区"每个客户的总收入
Table revenue = orders
  .filter($("cCountry").isEqual("China"))
  .groupBy($("cID"), $("cName"))
  .select($("cID"), $("cName"), $("revenue")
  .sum().as("revSum"));

// 计算结果插入目标表
revenue.insertInto(sinkTable);
```

上述tableapi的计算逻辑，就等价于如下sql语句：

```sql
insert into sinkTable
select
    cID,
    cName,
    sum(revenue) as revSum
from orders
where cCountry = 'China'
group by cID,cName
```



### **2.3.2 Table Sql 方式**

用“sql字符串”形式进行基于表的关系运算逻辑表达

```java
// 创建入口
TableEnvironment tableEnv = ... ; 

// 注册orders源表
tableEnv.createTable("orders",.....)
// 注册RevenueChina输出表
tableEnv.createTable("RevenueChina",.....)

// 计算中国区每个客户的总收入，并输出到结果表
tableEnv.executeSql(
    "INSERT INTO RevenueChina " +
    "SELECT cID, cName, SUM(revenue) AS revSum " +
    "FROM Orders " +
    "WHERE cCountry = CHINA" +
    "GROUP BY cID, cName"
  );
```



### 2.3.3 混搭方式

Table API和Table SQL查询可以很容易地混合，因为Table对象可以和sql表进行方便的互转：

* 可以让SQL查询返回Table对象，进而调用TableAPI ；

* 可以用env.from("sql表名") 引用sql表得到Table对象，进而调用TableAPI ；&#x20;

* 可以用env.createTemporaryView("sql表名",  table对象)，将Table对象注册成sql表，进而用sql

&#x20;

# 3 完整入门示例

## 3.1 需求和准备

从socket端口读取用户的行为数据，统计每个<span style="color: inherit; background-color: rgba(255,246,122,0.8)">用户</span>每次<span style="color: inherit; background-color: rgb(255,233,40)">会话</span>中各类<span style="color: inherit; background-color: rgb(255,233,40)">行为</span>的发生次数，并将结果输出到控制台。有如下json数据通过sockect端口输入：

```java
{"guid":1,"sessionId":"s01","eventId":"e01","eventTime":1000}
{"guid":1,"sessionId":"s01","eventId":"e02","eventTime":2000}
{"guid":1,"sessionId":"s01","eventId":"e03","eventTime":3000}
{"guid":2,"sessionId":"s02","eventId":"e02","eventTime":2000}
{"guid":2,"sessionId":"s02","eventId":"e02","eventTime":3000}
{"guid":2,"sessionId":"s02","eventId":"e01","eventTime":4000}
{"guid":2,"sessionId":"s02","eventId":"e03","eventTime":5000}
```

## **3.2 获取数据流**



```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
StreamTableEnvironment tenv = StreamTableEnvironment.create(env);

DataStreamSource<String> source = env.socketTextStream("doitedu", 9999);
DataStream<EventBean> stream = source.map(s -> JSON.parseObject(s, EventBean.class));
```



## **3.3 Table SQL方式查询**



```java
// 将dataStream注册成临时视图
tenv.createTemporaryView("t_event", stream);
// 查询每个用户每次会话中每类事件的发生次数
tenv.executeSql("select guid,sessionId,eventId,count(1) from t_event group by guid,sessionId,eventId").print();
```



## **3.4 Table API 方式查询**



```java
// 从dataStream创建Table对象
Table table = tenv.fromDataStream(stream);
// 查询每个用户每次会话中每类事件的发生次数
Table select =
        table.groupBy($("guid"), $("sessionId"), $("eventId"))
                .aggregate($("eventId").count().as("event_cnt"))
                .select($("guid"), $("sessionId"), $("eventId"), $("event_cnt"));
select.execute().print();
```



# 4 表的概念及类别

## **4.1表的标识结构**



每一个表的标识由3部分组成：

* catalog name （常用于标识不同的“源”，比如hive catalog，inner catalog等）

* database name（通常语义中的“库”）

* <u>table</u> name（通常语义中的“表”）



```java
TableEnvironment tEnv = ...;
tEnv.useCatalog("a_catalog");
tEnv.useDatabase("db1");

Table table = ...;

// 注册在默认catalog的默认database中
tableEnv.createTemporaryView("a_view", table);

// 注册在默认catalog的指定database中
tableEnv.createTemporaryView("db2.a_view", table);

// 注册在指定catalog并指定database
tableEnv.createTemporaryView("x_catalog.db3.a_view", table); 
```



一个FlinkSQL程序在运行时，tableEnvironment通过持有一个map结构来记录所注册的catalog；

```java
public final class CatalogManager {
    private static final Logger LOG = LoggerFactory.getLogger(CatalogManager.class);
    private final Map<String, Catalog> catalogs;
    private final Map<ObjectIdentifier, CatalogBaseTable> temporaryTables;  
    //...
}
```



## **4.2 表与视图**



<span style="color: inherit; background-color: rgba(222,224,227,0.8)">FlinkSQL中的表，</span> <span style="color: inherit; background-color: rgb(255,233,40)">可以是 virtual的（view 视图，查询的中间结果）</span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">和</span> <span style="color: inherit; background-color: rgb(255,233,40)">regular的（table 常规表，对应的Source源或Sink存储系统），不管是table还是view，在tableAPI中得到的都是Table对象</span>

* table描述了一个物理上的外部数据源，如文件、数据库表、kafka消息topic

* view则基于表创建，代表一个或多个表上的一段计算逻辑，即对数据转换查询（就是对一段查询计划的逻辑封装）



## 4.3 **临时与永久**



* 临时表（视图）： <span style="color: rgb(143,149,158); background-color: inherit">创建时带 temporary 关键字（crate temporary view，create temporary table）</span>

* 永久表（视图）： <span style="color: rgb(143,149,158); background-color: inherit">创建时不带temporary关键字 （create view ，create table ）</span>



```java
// sql定义方式
tableEnv.executeSql("create view view_1 as select .. from projectedTable")
tableEnv.executeSql("create temporary view  view_2 as select .. from projectedTable")

tableEnv.executeSql("create table (id int,...) with ( 'connector'= ...)")
tableEnv.executeSql("create temporary table (id int,...) with ( 'connector'= ...)")

// table api方式
tenv.createTable("t_1",tableDescriptor);
tenv.createTemporaryTable("t_1",tableDescriptor);

tenv.createTemporaryView("v_1",dataStream,schema);
tenv.createTemporaryView("v_1",table);
```



* **临时表与永久表的本质区别：schema信息是否被持久化存储**



临时表（视图）特点：

* 表<u>schema只维护在所属flink session运行时内存中；</u>

* 当所属的flink session结束后表信息将不复存在；且该表无法在flink session间共享；



常规表（视图）特点：

* 表<u>schema可记录在外部持久化的元数据管理器中</u>（比如hive的metastore）；

* 当所属flink session结束后，该表信息不会丢失；且在不同flink session中都可访问到该表的信息；



# 5 表定义概览

## **5.1 \[ Table Api ] Table创建概览**

![](<images/06 FlinkSQL-image-11.png>)

![](<images/06 FlinkSQL-image-1.png>)



**Table对象获取方式解析：**

* 已注册的表名（catalog\_name.database\_name.object\_name）

* TableDescriptor（表描述器，核心是connector连接器）

* Datastream（底层流）

* 测试数据值



## 5.2 \[ Table Api ] Table创建示例



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> 通过已注册的表名生成Table对象**

```java
Table t1 = tenv.from("t1"); // 通过已经在env的catalog中注册的表名，获得Table对象
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> 通过DataStream生成Table对象**

* 自动推断schema（反射手段）

```java
DataBean bean1 = new DataBean(1, "s1", "e1", "pg1", 1000);
DataBean bean2 = new DataBean(2, "s2", "e3", "pg1", 1000);
DataStreamSource<DataBean> dataStream1 = env.fromElements(bean1, bean2);
Table table1 = tenv.fromDataStream(dataStream1);
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> 通过tableEnv的fromValues方法获得Table对象（快速测试用）**

```java
//定义map类型
HashMap<String, String> info = new HashMap<String, String>();
info.put("name", "tom");
info.put("gender", "male");

Table table = tEnv.fromValues(
        DataTypes.ROW(
                DataTypes.FIELD("id", DataTypes.INT()),
                DataTypes.FIELD("name", DataTypes.STRING()),
                DataTypes.FIELD("info", DataTypes.MAP(DataTypes.STRING(), DataTypes.STRING())),
                DataTypes.FIELD("ts1", DataTypes.TIMESTAMP(3)), 
                DataTypes.FIELD("ts2", DataTypes.BIGINT()),
                DataTypes.FIELD("ts3", DataTypes.TIMESTAMP_LTZ(3))
        ),
        Row.of(1, "a", info, "
        ",1654236105000L, "2022-06-03 13:59:20.200")
);

tEnv.toChangelogStream(table).print();
```



//TIMESTAMP(3)

//2022-06-03 13:59:20.200&#x20;

> *TIMESTAMP和TIMESTAMP\_LTZ的区别:*
>
> 相同点：两者都可用来表示 YYYY-MM-DD HH:MM:SS 类型的日期。
>
> 不同点：对于timestamp：它把客户端插入的时间从 当前时区 转化为UTC（世界标准时间）进行存储。查询时，将其又转化为客户端当前时区进行返回。对于datetime:入库的时候数据库是什么时区，取出来就是什么时区。即，flink中的TIMESTAMP不携带时，TIMESTAMP\_LTZ携带时区。
>
> 二者都接受一个小于9的参数: TIMSTAMP\_LTZ(num),TO\_TIMESTAMP(num)  指的是时间的精确度，开发中经常用到TIMESTAMP(3)或者是TIMSTAMP\_LTZ(3)意思是保留三位，实际含义就是精确到毫秒，TIMESTAMP(6)和TIMSTAMP\_LTZ(6)表示微秒，TIMESTAMP(9)和TIMSTAMP\_LTZ(9)表示纳秒。  一般用TIMESTAMP(3)或者是TIMSTAMP\_LTZ(3)就够了。



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> 通过Table上调用查询api，生成新的Table对象（本质上就是view）**

```java
Table table = table3.select($("guid"), $("uuid"));
```



## **5.3 \[ Table Sql ] 表创建概览**

![](<images/06 FlinkSQL-image.png>)

![](<images/06 FlinkSQL-image-2.png>)



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 注册sql表（视图）方式解析</span>**

* 从已存在的datastream注册

* 从已存在的Table对象注册

* 从TableDescriptor（连接器）注册

* 执行Sql的DDL语句来注册



## **5.4 \[ Table Sql ] 表创建示例**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 将已存在的Table对象注册成sql视图</span>**

```java
tenv.createTemporaryView("t1",table);
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 将datastream注册成sql视图</span>**

```java
DataBean bean1 = new DataBean(1, "s1", "e1", "pg1", 1000);
DataBean bean2 = new DataBean(1, "s1", "e1", "pg1", 1000);
DataStreamSource<DataBean> dataStream1 = env.fromElements(bean1, bean2);
// 1.自动推断schema
tenv.createTemporaryView("t1",dataStream1);
// 2.也可以手动指定schema
Schema schema = Schema.Builder.column...build();
tenv.createTemporaryView("t1",dataStream1,schema);
tenv.executeSql("desc t1");
tenv.executeSql("select * from t1");
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 通过connector注册sql表</span>**

```java
tEnv.createTable("t1", TableDescriptor
        .forConnector("kafka") //指定connector类型为kafka
        .option("topic", "user-behavior") //指定topic
        .option("properties.bootstrap.servers", "node-1.51doit.cn:9092,node-2.51doit.cn:9092,node-3.51doit.cn:9092")
        .option("properties.group.id", "testGroup") //指定组ID
        .option("scan.startup.mode", "latest-offset") //指定读取数据的为最新的
        .option("csv.ignore-parse-errors", "true") //忽略解析出错的数据，转成NULL
        .format("csv") //指定读取数据的格式为csv
        .schema(Schema.newBuilder()
                .column("guid", DataTypes.STRING())
                .column("name", DataTypes.STRING())
                .column("age", DataTypes.INT())
                .build())
        .build());

TableResult tableResult = tEnv.executeSql("select * from t1");
tableResult.print();
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 通过sql DDL语句定义sql表</span>**

```java
tEnv.executeSql(
        "CREATE TABLE KafkaTable ( \n" +
                "  `user_id` BIGINT, \n" +
                "  `item_id` BIGINT, \n" +
                "  `behavior` STRING \n" +
                ") WITH (\n" +
                "  'connector' = 'kafka',\n" +
                "  'topic' = 'user-behavior',\n" +
                "  'properties.bootstrap.servers' = 'node-1.51doit.cn:9092,node-2.51doit.cn:9092,node-3.51doit.cn:9092',\n" +
                "  'properties.group.id' = 'testGroup',\n" +
                "  'scan.startup.mode' = 'earliest-offset',\n" +
                "  'format' = 'csv', \n" +
                "  'csv.ignore-parse-errors' = 'true' \n" +
                ")"
);
TableResult tableResult = tEnv.executeSql("select * from KafkaTable");
tableResult.print();
```



# 6 catalog详解

## 6.1 **什么是catalog**

**<span style="color: inherit; background-color: rgb(255,233,40)">一句话： catalog就是一个元数据空间，简单说就是记录、获取元数据（表定义信息）的实体；</span>**&#x66;linksql在运行时，可以拥有多个catalog，它们由catalogManager模块来注册、管理；



CatalogManager中可以注册多个元数据空间：

**<span style="color: rgb(143,149,158); background-color: rgb(247,105,100)"> 1 </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">环境创建之初，就会初始化一个默认的元数据空间</span>

* 空间名称： default\_catalog

* 空间实现类： GenericInMemoryCatalog



![](<images/06 FlinkSQL-image-19.png>)



```java
public class GenericInMemoryCatalog extends AbstractCatalog {

    public static final String DEFAULT_DB = "default";
    // 用于记录本catalog空间中所有database的 linkedHashMap
    private final Map<String, CatalogDatabase> databases;
    // 用于记录本catalog空间中所有table的linkedHashMap
    private final Map<ObjectPath, CatalogBaseTable> tables;
    //...   
}
```



```java
private CatalogManager(
        String defaultCatalogName, Catalog defaultCatalog, DataTypeFactory typeFactory) {
    checkArgument(
            !StringUtils.isNullOrWhitespaceOnly(defaultCatalogName),
            "Default catalog name cannot be null or empty");
    checkNotNull(defaultCatalog, "Default catalog cannot be null");
    // 用于记录session中所有的catalog
    catalogs = new LinkedHashMap<>();
    // 放入一个defaultCatalog
    catalogs.put(defaultCatalogName, defaultCatalog);
    // 设置当前的catalog为default_catalog
    currentCatalogName = defaultCatalogName;
    // 设置当前的database为default_database
    currentDatabaseName = defaultCatalog.getDefaultDatabase();
    // 构造一个空的hashmap，用来记录session中注册的临时表
    temporaryTables = new HashMap<>();
    // right now the default catalog is always the built-in one
    builtInCatalogName = defaultCatalogName;

    this.typeFactory = typeFactory;
}
```



**<span style="color: rgb(143,149,158); background-color: rgb(247,105,100)"> 2 </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">用户还可以向环境中注册更多的catalog，如下代码新增注册了一个hivecatalog</span>

```java
// 创建了一个hive元数据空间的实现对象
HiveCatalog hiveCatalog = new HiveCatalog("hive", "default", "d:/conf/hiveconf");
// 将hive元数据空间对象注册到 环境中
tenv.registerCatalog("mycatalog",hiveCatalog);
```



## **6.2 深入测试catalog**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 通过源码和测试代码，深入理解catalog</span>**



```java
package cn.doitedu.flinksql.demos;

public class Demo5_CatalogDemo {

    public static void main(String[] args) {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // 环境创建之初，底层会自动初始化一个 元数据空间实现对象（default_catalog => GenericInMemoryCatalog）
        StreamTableEnvironment tenv = StreamTableEnvironment.create(env);

        // 创建了一个hive元数据空间的实现对象
        HiveCatalog hiveCatalog = new HiveCatalog("hive", "default", "d:/conf/hiveconf");
        // 将hive元数据空间对象注册到 环境中
        tenv.registerCatalog("mycatalog",hiveCatalog);

        tenv.executeSql(
                "create temporary table `mycatalog`.`default`.`t_kafka`    "
                        + " (                                                   "
                        + "   id int,                                           "
                        + "   name string,                                      "
                        + "   age int,                                          "
                        + "   gender string                                     "
                        + " )                                                   "
                        + " WITH (                                              "
                        + "  'connector' = 'kafka',                             "
                        + "  'topic' = 'user-behavior',                              "
                        + "  'properties.bootstrap.servers' = 'node-1.51doit.cn:9092',   "
                        + "  'properties.group.id' = 'g1',                      "
                        + "  'scan.startup.mode' = 'earliest-offset',           "
                        + "  'format' = 'json',                                 "
                        + "  'json.fail-on-missing-field' = 'false',            "
                        + "  'json.ignore-parse-errors' = 'true'                "
                        + " )                                                   "
        );

        tenv.executeSql(
                "create temporary table `t_kafka2`    "
                        + " (                                                   "
                        + "   id int,                                           "
                        + "   name string,                                      "
                        + "   age int,                                          "
                        + "   gender string                                     "
                        + " )                                                   "
                        + " WITH (                                              "
                        + "  'connector' = 'kafka',                             "
                        + "  'topic' = 'doit30-3',                              "
                        + "  'properties.bootstrap.servers' = 'doitedu:9092',   "
                        + "  'properties.group.id' = 'g1',                      "
                        + "  'scan.startup.mode' = 'earliest-offset',           "
                        + "  'format' = 'json',                                 "
                        + "  'json.fail-on-missing-field' = 'false',            "
                        + "  'json.ignore-parse-errors' = 'true'                "
                        + " )                                                   "
        );


        tenv.executeSql("create  view if not exists `mycatalog`.`default`.`t_kafka_view` as select id,name,age from `mycatalog`.`default`.`t_kafka`");


        tenv.listCatalogs();


        tenv.executeSql("show catalogs").print();
        tenv.executeSql("use catalog default_catalog");
        tenv.executeSql("show databases").print();
        tenv.executeSql("use default_database");
        tenv.executeSql("show tables").print();

        System.out.println("----------------------");

        tenv.executeSql("use catalog mycatalog");
        tenv.executeSql("show databases").print();
        tenv.executeSql("use  `default`");
        tenv.executeSql("show tables").print();
    }
}
```



<span style="color: inherit; background-color: rgba(222,224,227,0.8)">可以在上述代码运行前，设置debug断点，然后就可以清晰看到catalogManager中的各个元数据空间及临时表空间的情况</span>



![](<images/06 FlinkSQL-image-21.png>)



## 6.3 **临时表与永久表的底层差异**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">结论1：如果选择hive元数据空间来创建表、视图，则</span>

* 永久表（视图）的元信息，都会被写入hive的元数据管理器中，从而可以实现永久存在

* 临时表（视图）的元信息，并不会写入hive的元数据管理其中，而是放在catalogManager的一个temporaryTables的内存hashmap中记录

* 临时表空间中的表名（全名）如果与hive空间中的表名相同，则查询时会优先选择临时表空间的表



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">结论2：如果选择GenericInMemoryCatalog元数据空间来创建表、视图，则</span>

* 永久表（视图）的元信息，都会被写入GenericInMemoryCatalog的元数据管理器中（内存中）

* 临时表（视图）的元信息，放在catalogManager的一个temporaryTables的内存hashmap中记录

* 无论永久还是临时，当flink的运行session结束后，所创建的表（永久、临时）都将不复存在



## 6.4 如何理解hive catalog

<span style="color: inherit; background-color: rgb(255,233,40)">flinksql利用hive catalog来建表（查询、修改、删除表），本质上只是利用了hive的metastore服务；</span>更具体来说，flinksql只是把flinksql的表定义信息，按照hive元数据的形式，托管到hive的metastore中而已！

<span style="color: inherit; background-color: rgb(255,233,40)">当然，hive中也能看到这些托管的表信息，但是，并不能利用它底层的mapreduce或者spark引擎来查询这些表；</span>因为mapreduce或者spark引擎，并不能理解flinksql表定义中的信息，也无法为这些定义信息提供相应的组件去读取数据（比如，mr或者spark就没有flinksql中的各种connector组件）



# **7 表定义详解**

## 7.1 定义表的核心要素

定义表需要指定表的描述信息，即schema信息，schema信息有如下重要的核心要素。



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 定义表时所需的核心要素</span>**

* **表名 （**&#x63;atalog\_name.database\_name.object\_nam&#x65;**）**

* **TableDescriptor**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> TableDescriptor核心要素</span>**

* Connector 连接器

* Format 数据格式

* Schema 表结构（字段）

* Option 连接器参数



## 7.2 schema字段定义详解



### **7.2.1 physical column**

**physical column为物理字段**：<span style="color: inherit; background-color: rgb(255,233,40)">源自于“外部存储”系统本身schema中的字段：</span>

如kafka消息的key、value（json格式）中的字段；

mysql表中的字段；hive表中的字段；parquet文件中的字段……



### **7.2.2 computed column**

**computed column为表达式字段（逻辑字段）**：<span style="color: inherit; background-color: rgb(255,233,40)">在物理字段上施加一个sql表达式，并将表达式结果定</span>义为一个字段。



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> TableApi中的定义方式</span>**

```java
Schema.newBuilder()
// 声明表达式字段age_exp, 它来源于物理字段 age+10
.columnByExpression("age_exp", "age+10")
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> Sql DDL中的定义方式</span>**

```sql
CREATE TABLE MyTable (
  `user_id` BIGINT,
  `price` DOUBLE,
  `quantity` DOUBLE,
  `cost` AS price * quantity,  -- cost 来源于： price*quantity
) WITH (
  'connector' = 'kafka'
  ...
);
```



### 7.2.3 metadata column



**metadata column为元数据字段**：<span style="color: inherit; background-color: rgb(255,233,40)">来源于connector从外部存储系统中获取到的“外部系统元信息”</span>

&#x20;

比如，kafka的消息，通常意义上的数据内容是在record的key和value中的，而实质上（底层角度来看），kafka中的每一条record，不光带了key和value数据内容，还带了这条record所属的topic，所属的partition，所在的offset，以及record的timetamp和timestamp类型等“元信息”，<span style="color: rgb(216,57,49); background-color: rgb(255,233,40)">而flink的connector可以获取并暴露这些元信息，并允许用户将这些信息定义成flinksql表中的字段</span> <span style="color: rgb(216,57,49); background-color: inherit">；</span>



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> TableApi中的定义方式</span>**

```java
Schema.newBuilder()
.columnByMetadata("topic",DataTypes.STRING())
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> Sql DDL中的定义方式</span>**

```sql
CREATE TABLE MyTable (
  `user_id` BIGINT,
  `name` STRING,
   -- 元数据字段，来源于kafka record的timestamp
  `record_time` TIMESTAMP_LTZ(3) METADATA FROM 'timestamp' 
) WITH (
  'connector' = 'kafka'
  ...
);
```



### **7.2.4 主键约束**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 单字段主键约束语法</span>**

```sql
id INT PRIMARY KEY NOT ENFORCED, --flink中不存储数据  , 数据是源源的不断的输入的不能强制限制ENFORCED
name STRING
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 多字段主键约束语法</span>**

```sql
id,
name,
PRIMARY KEY(id,name) NOT ENFORCED -- 是按照主键进行upsert
```



### **7.2.5 表字段定义完整实例**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> sql的DDL方式</span>**

```java
TableEnvironment tenv = TableEnvironment.create(EnvironmentSettings.inStreamingMode());

// 建表（数据源表）
// {"id":4,"name":"zs","nick":"tiedan","age":18,"gender":"male"}
tenv.executeSql(
        "create table t_person                                        "
                + " (                                                 "
                + "   id int ,                                        "  // -- 物理字段
                + "   name string,                                    "  // -- 物理字段
                + "   nick string,                                    "
                + "   age int,                                        "
                + "   gender string ,                                 "
                + "   guid as id,                                     "  // 表达式字段（逻辑字段）
                + "   big_age as age + 10 ,                           "  //表达式字段（逻辑字段）
                + "   offs  bigint metadata from 'offset' ,           " //元数据字段
                + "   ts TIMESTAMP_LTZ(3) metadata from 'timestamp'   "   //元数据字段
                + "   PRIMARY KEY(id,name) NOT ENFORCED               " // -- 主键约束
                + " )                                                   "
                + " WITH (                                              "
                + "  'connector' = 'kafka',                             "
                + "  'topic' = 'doit30-4',                              "
                + "  'properties.bootstrap.servers' = 'doitedu:9092',   "
                + "  'properties.group.id' = 'g1',                      "
                + "  'scan.startup.mode' = 'earliest-offset',           "
                + "  'format' = 'json',                                 "
                + "  'json.fail-on-missing-field' = 'false',            "
                + "  'json.ignore-parse-errors' = 'true'                "
                + " )                                                   "
);

tenv.executeSql("desc t_person").print();
tenv.executeSql("select * from t_person").print();
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> Api方式</span>**

```java
// 建表（数据源表）
// {"id":4,"name":"zs","nick":"tiedan","age":18,"gender":"male"}
tenv.createTable("t_person",
        TableDescriptor
                .forConnector("kafka")
                .schema(Schema.newBuilder()
                        .column("id", DataTypes.INT())   // column是声明物理字段到表结构中来
                        .column("name", DataTypes.STRING())   // column是声明物理字段到表结构中来
                        .column("nick", DataTypes.STRING())   // column是声明物理字段到表结构中来
                        .column("age", DataTypes.INT())   // column是声明物理字段到表结构中来
                        .column("gender", DataTypes.STRING())   // column是声明物理字段到表结构中来
                        .columnByExpression("guid","id")  // 声明表达式字段
                        /*.columnByExpression("big_age",$("age").plus(10))*/     // 声明表达式字段
                        .columnByExpression("big_age","age + 10")  // 声明表达式字段
                        // isVirtual 是表示： 当这个表被sink表时，该字段是否出现在schema中
                        .columnByMetadata("offs",DataTypes.BIGINT(),"offset",true)  // 声明元数据字段
                        .columnByMetadata("ts",DataTypes.TIMESTAMP_LTZ(3),"timestamp",true)  // 声明元数据字段
                        /*.primaryKey("id","name")*/
                        .build())
                .format("json")
                .option("topic","doit30-4")
                .option("properties.bootstrap.servers","doitedu:9092")
                .option("properties.group.id","g1")
                .option("scan.startup.mode","earliest-offset")
                .option("json.fail-on-missing-field","false")
                .option("json.ignore-parse-errors","true")
                .build()
);

tenv.executeSql("select * from t_person").print();
```



## 7.3 **format概述**



connector连接器在对接外部存储时，根据外部存储中的数据格式不同，需要用到不同的format组件；

<span style="color: inherit; background-color: rgb(255,233,40)">format组件的作用就是：告诉连接器，如何解析外部存储中的数据及映射到表schema；</span>



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> format组件的使用要点</span>**



* 导入format组件的jar包依赖

* 指定format组件的名称

* 设置format组件所需的参数（不同format组件有不同的参数配置需求）



![](<images/06 FlinkSQL-image-26.png>)



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  flinksql目前支持的format如下</span>**



![](<images/06 FlinkSQL-image-27.png>)



### 7.3.1 **json format 详解**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  所需依赖</span>**

```java
<dependency>
  <groupId>org.apache.flink</groupId>
  <artifactId>flink-json</artifactId>
  <version>1.15.2</version>
</dependency>
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  可用参数</span>**



```properties
format   组件名： json
json.fail-on-missing-field   缺失字段是否失败
json.ignor-parse-errors   是否忽略json解析错误
json.timestamp-format.standard   json中的timestamp类型字段的格式
json.map-null-key.mode  可取：FAIL ,DROP, LITERAL
json.map-null-key.literal  替换null的字符串
json.encode.decimal-as-plain-number
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  数据类型映射</span>**





**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  基本使用</span>**



假设kafka或文件中有如下数据：

```json
{"id":10,"name":"nick","age":28,"regTime":"2022-06-06 12:30:30.100"}
```

映射成flinksql表

```json
Schema schema = Schema.newBuilder()
        .column("id", DataTypes.INT())
        .column("name", DataTypes.STRING())
        .column("age", DataTypes.INT())
        .column("regTime", DataTypes.TIMESTAMP(3))
        .build();

tenv.createTable("t1",
        TableDescriptor.forConnector("filesystem")
                .option("path", "file:///d:/json.txt")
                .format("json")
                .schema(schema)
                .build());

tenv.executeSql("select id,name,age,regTime from t1").print();
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 复杂json格式解析（嵌套对象） </span>**



* 有如下嵌套json

```json
{"id":10,"name":{"nick":"doe","formal":"doit edu"}}
```



* 映射成flinksql表

```java
Schema schema = Schema.newBuilder()
        .column("id", DataTypes.INT())
        .column("name", DataTypes.ROW(
                        DataTypes.FIELD("nick", DataTypes.STRING()),
                        DataTypes.FIELD("formal", DataTypes.STRING())
                )
        )
        .build();
```



* 查询

```sql
select id,name.nick,name.formal from t
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  复杂json格式解析（嵌套数组，数组内又嵌套对象）</span>**

有如下嵌套json

```json
{"id":1,"friends":[{"name":"a","info":{"addr":"bj","gender":"male"}},{"name":"b","info":{"addr":"sh","gender":"female"}}]}
```

映射成flinksql表

```java
Schema schema3 = Schema.newBuilder()
        .column("id", DataTypes.INT())
        .column("friends", DataTypes.ARRAY(
                DataTypes.ROW(
                        DataTypes.FIELD("name", DataTypes.STRING()),
                        DataTypes.FIELD("info", DataTypes.ROW(
                                DataTypes.FIELD("addr", DataTypes.STRING()),
                                DataTypes.FIELD("gender", DataTypes.STRING())
                        ))
                )))
        .build();
```



* 查询

```sql
select  id,friends[1].name,friends[1].info.addr from t1
```



### 7.3.2 **csv format 详解**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  所需依赖</span>**

```xml
<dependency>
  <groupId>org.apache.flink</groupId>
  <artifactId>flink-csv</artifactId>
  <version>1.15.2</version>
</dependency>
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  可用参数</span>**

```properties
format = csv
csv.field-delimiter = ','
csv.disable-quote-character = false
csv.quote-character = ' " '
csv.allow-comments = false
csv.ignore-parse-erros = false  #是否忽略解析错误
csv.array-element-delimiter = ' ; '  #数组元素之间的分隔符
csv.escape-character = none    #转义字符
csv.null-literal = none   #null的字面量字符串
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 代码示例 </span>**



```java
tenv.executeSql(
        "create table t_csv(                                    "
                + "  id int,                                    "
                + "  name string,                               "
                + "  age  string                                "
                + ") with (                                     "
                + " 'connector' = 'filesystem',                "
                + " 'path' = 'data/csv/',                       "
                + " 'format'='csv',                             "
                + " 'csv.disable-quote-character' = 'false',   "
                + " 'csv.quote-character' = '|',               "
                + "  'csv.ignore-parse-errors' = 'true' ,      "
                + "  'csv.null-literal' = '\\N'          ,      "
                + "  'csv.allow-comments' = 'true'             "
                + ")                                            "
);
tenv.executeSql("desc t_csv").print();
tenv.executeSql("select * from  t_csv").print();
```



## 7.4 FlinkSQL的工具类封装

* 将SQL写入到文件中

```sql
-- 创建Source表
CREATE TABLE KafkaTable (
  `user_id` BIGINT,
  `item_id` BIGINT,
  `behavior` STRING,
  `ts` TIMESTAMP(3) METADATA FROM 'timestamp' VIRTUAL, -- 将写入到kafka中对应的数据取出来作为ts字段
  `topic` STRING METADATA FROM 'topic' VIRTUAL, -- 获取数据的topic
  `partition_id` BIGINT METADATA FROM 'partition' VIRTUAL,  -- 获取partiton信息
  `offset` BIGINT METADATA VIRTUAL  -- from Kafka connector -- 获取偏移量信息 `offset` BIGINT METADATA FROM 'offset' VIRTUAL
) WITH (
  'connector' = 'kafka', -- 指定connector类型
  'topic' = 'user-behavior-json', -- 指定从Kafka中读取数据的topic
  'properties.bootstrap.servers' = 'node-1.51doit.cn:9092,node-2.51doit.cn:9092,node-3.51doit.cn:9092', -- 指定kafka的地址
  'properties.group.id' = 'testGroup', -- 指定消费者组ID
  'scan.startup.mode' = 'earliest-offset', -- 指定消费的起始偏移量
  'format' = 'json', -- 读取csv格式，默认的分隔符为","
  'json.ignore-parse-errors' = 'true' -- 忽略解析失败的数据
)
;
-- 创建Sink表
CREATE TABLE print_table (
  `user_id` BIGINT,
  `item_id` BIGINT,
  `behavior` STRING,
  `ts` TIMESTAMP(3),
  `topic` STRING,
  `partition_id` BIGINT,
  `offset` BIGINT
) WITH (
  'connector' = 'print' -- 指定为print sink，将数据在控制台打印
)
;
-- 从Source中查询数据，然后将结果插入到Sink表中
INSERT INTO print_table select * from KafkaTable where behavior <> 'pay'
```



* 工具类封装

```java
public class FlinkSQLUtils {
    
    public static void execute(String path) throws Exception { 
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        StreamTableEnvironment tEnv = StreamTableEnvironment.create(env);
        //读取指定文件中的全部内容
        String str = FileUtils.readFileToString(new File(path), "UTF-8");
        //按照分号切分sql
        String[] sqls = str.split(";"); 
        //从前到后循环执行每一条sql
        for (String sql : sqls) {
            tEnv.executeSql(sql);
        }
    }
}
```

* 主程序

```java
public class WordCount {

    public static void main(String[] args) throws Exception {

        FlinkSQLUtils.execute("sqls/EventFilter.sql");

    }
}
```



## 7.5 **watermark与时间属性详解**



时间属性定义，主要是用于各类基于时间的运算操作（如基于时间窗口的查询计算）



### **7.5.1 eventTime与waterMark定义**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> Table Api中的定义方式</span>**

```java
// guid,uuid,eventId,pageId,ts
DataStreamSource<String> ss = env.socketTextStream("doitedu", 9999);
// 换成pojo类型的datastream
SingleOutputStreamOperator<DataBean> ds = ss.map(s -> {
    String[] arr = s.split(",");
    return new DataBean(Integer.parseInt(arr[0]), arr[1], arr[2], arr[3], Long.parseLong(arr[4]));
});
// 分配watermark策略
SingleOutputStreamOperator<DataBean> ds2 = ds.assignTimestampsAndWatermarks(
        WatermarkStrategy.<DataBean>forMonotonousTimestamps()
                .withTimestampAssigner((element, recordTimestamp) -> element.ts));


// 转成 table
Table table2 = tenv.fromDataStream(ds2, Schema.newBuilder()
        // 声明表达式字段，并声明为 processing time属性字段
        .columnByExpression("pt", "proctime()")
        // 声明表达式字段（来自ts）
        .columnByExpression("rt", "to_timestamp_ltz(ts,3)")
        // 将rt字段指定为event time属性字段，并基于它指定watermark策略： = rt
        .watermark("rt", "rt")
        // 将rt字段指定为event time属性字段，并基于它指定watermark策略： = rt - 8s
        .watermark("rt", "rt - interval '8' second")
        // 将rt字段指定为event time属性字段，并沿用“源头流”的watermark
        .watermark("rt", "SOURCE_WATERMARK()")  // 得到与源头watermark完全一致
        .build());
table2.printSchema(); 
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> Sql DDL中的定义方式</span>**

```sql
watermark for timeAttrColumn AS timeAttrColumn - interval '1' second,
ptime AS proctime( )
```

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">核心要点：</span>

* 需要一个<span style="color: inherit; background-color: rgba(183,237,177,0.8)">timestamp</span>(3)类型字段（可以是物理字段，也可以是表达式字段，也可以是元数据字段）

* 需要用一个watermarkExpression来指定watermark策略（有2种表达式）



### 7.5.2 表与流之间waterMark传承



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 流转表时</span>**

流转表的过程中，无论“源流”是否存在watermark，都不会自动传递watermark

如需时间运算（如时间窗口等），<span style="color: inherit; background-color: rgb(255,233,40)">需要在转换定义中显式声明watermark策略</span>：

先设法定义一个timestamp(3)或者timestamp\_ltz(3)类型的字段（可以来自于数据字段，也可以来自于一个元数据： rowtime&#x20;

```sql
rt as to_timestamp_ltz(eventTime)  -- 从一个bigint得到一个timestamp（3）类型的字段
rt timestamp(3) metadata from 'rowtime'  -- 从一个元数据rowtime得到一个timestamp(3)类型的字段
```

然后基于该字段，用watermarkExpression声明watermark策略

```sql
watermark for rt  AS rt- interval '1' second
watermark for rt  AS source_watermark()  -- 代表使用底层流的watermark策略
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 表转流时</span>**



<u>前提：源表定义了wartermark策略；</u>

则将表转成流时，将会自动传递源表的watermark；

可通过类似如下代码进行测试：



```java
/**
 * 前提： table2已经是一个存在watermark的表对象, 转成datastream后，打印watermark
 *  */
tenv.toDataStream(table2)
        .process(new ProcessFunction<Row, String>() {
            @Override
            public void processElement(Row value, Context ctx, Collector<String> out) throws Exception {
                long wt = ctx.timerService().currentWatermark();
                System.out.println(wt + " => " + value);
            }
        }).print();
```



### 7.5.3 **processing time**



<span style="color: inherit; background-color: rgba(222,224,227,0.8)">定义一个</span> <u><span style="color: inherit; background-color: rgba(222,224,227,0.8)">表达式字段</span></u> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">，并用表达式</span> <span style="color: rgb(216,57,49); background-color: rgba(222,224,227,0.8)"> proctime( ) </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">将其声明为processing time即可；</span>



```java
// 转成 table
Table table = tenv.fromDataStream(ds, Schema.newBuilder()
        // 声明表达式字段，并声明为 processing time属性字段
        .columnByExpression("pt", "proctime()")
```



## 7.6 connector详解

### 7.6.1 connector概述

connector通常是用于对接外部存储建表（源表或目标表）时的映射器、桥接器，<span style="color: inherit; background-color: rgb(255,233,40)">connector本质上是对flink的table source /table sink 算子的封装；</span>



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 连接器使用的核心要素：</span>**

* 导入连接器jar包依赖

* 指定连接器类型名

* 指定连接器所需的参数（不同连接器有不同的参数配置需求）

* 获取连接器所提供的元数据



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 连接器使用的速览示例</span>**

导入依赖

```xml
<dependency>
  <groupId>org.apache.flink</groupId>
  <artifactId>flink-connector-kafka</artifactId>
  <version>1.15.2</version>
</dependency>
```

配置参数

* Table API 方式

![](<images/06 FlinkSQL-image-18.png>)



* Table SQL 方式

![](<images/06 FlinkSQL-image-25.png>)



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> FlinkSql内置支持的connector</span>**



![](<images/06 FlinkSQL-image-24.png>)



### 7.6.2 **kafka connector详解**

可以从Kafka中读取数据创建数据流，并且可以将数据流写入到Kafka，<span style="color: inherit; background-color: rgb(255,233,40)">但是写入到Kafka只能是append-only 流</span> （只有 +I 这种changemode）



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 导入依赖</span>**

```xml
<dependency>
  <groupId>org.apache.flink</groupId>
  <artifactId>flink-connector-kafka</artifactId>
  <version>1.15.2</version>
</dependency>
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 建表语句</span>**

```sql
CREATE TABLE KafkaTable (
  `user_id` BIGINT,
  `item_id` BIGINT,
  `behavior` STRING,
  `ts` TIMESTAMP(3) METADATA FROM 'timestamp'
) WITH (
  'connector' = 'kafka',
  'topic' = 'user_behavior',
  'properties.bootstrap.servers' = 'localhost:9092',
  'properties.group.id' = 'testGroup',
  'scan.startup.mode' = 'earliest-offset',
  'format' = 'csv'
)
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  可用的元数据（来自于kafka的record中的metadata）</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  可用的参数（部分展示）</span>**

```sql
connector
topic / topic-pattern
properties.bootstrap.servers
properties.*  传给kafka-client的（会自动去除proerpties.前缀）
format  / key.format / value.format
key.fields  如 'fields1;fields2'
scan.startup.mode  可取： earliest-offset , latest-offset , group-offsets ,timestamp, specific-offsets 
scan.startup.specific-offsets 
sink.partitioner  默认default，可取 fixed , round-robin , 自定义类 'cn.doitedu.MyPartitioner'
sink.delivery-guarantee 可取 at-least-once , exactly-once , none
sink.parallelism 默认为none，根据算子chain决定
```



### **7.6.3 upsert-kafka-connector**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 基本工作机制</span>**

* 作为source

根据所定义的主键，将读取到的数据转换为 +I/-U/+U 记录，如果读到null，则转换为-D记录；

&#x20;kafka 中假设有如下数据 <span style="color: rgb(46,161,33); background-color: inherit">1</span>,zs,18 <span style="color: rgb(46,161,33); background-color: inherit">1</span>,zs,28

kafka <span style="color: rgb(100,37,208); background-color: inherit">-</span> connector  产生出appendonly流 <span style="color: rgb(216,57,49); background-color: inherit">+</span>I \[1,zs,18] <span style="color: rgb(216,57,49); background-color: inherit">+</span>I \[1,zs,28]

upsert-kafka-connector 产生出upsert模式的changelog流 <span style="color: rgb(216,57,49); background-color: inherit">+</span>I \[1,zs,18] <span style="color: rgb(100,37,208); background-color: inherit">-U</span> \[1,zs,18] <span style="color: rgb(216,57,49); background-color: inherit">+</span>U \[1,zs,28]



* 作为sink

对于 -U/+U/+I 记录， 都以正常的append消息写入kafka；

对于-D 记录，则写入一个null到kafka来表示delete操作；

&#x20;

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 代码示例</span>**

```sql
tenv.executeSql(
    " CREATE TABLE upsert_kafka (         "
        + "   province STRING,                      "
        + "   pv BIGINT,                            "
        + "   PRIMARY KEY (province) NOT ENFORCED   "
        + " ) WITH (                                "
        + "   'connector' = 'upsert-kafka',         "
        + "   'topic' = 'upsert-kafka2',                "
        + "   'properties.bootstrap.servers' = 'doitedu:9092',  "
        + "   'key.format' = 'csv',                   "
        + "   'value.format' = 'csv'                  "
        + " )                                         "
);
```



写入的程序：

```sql
DataStreamSource<Row> stream = env.fromElements(
        Row.ofKind(RowKind.INSERT, "sx", 1),
        Row.ofKind(RowKind.INSERT, "sx", 2),
        Row.ofKind(RowKind.INSERT, "gx", 1),
        Row.ofKind(RowKind.INSERT, "sx", 2),
        Row.ofKind(RowKind.INSERT, "gx", 2));


tenv.createTemporaryView("s", stream, Schema.newBuilder()
        .column("f0", DataTypes.STRING().notNull())
        .column("f1", DataTypes.INT())
        .build());

// 将查询结果（changelog流），写入kafka
tenv.executeSql("insert into upsert_kafka select f0,sum(f1) as pv  from s group by f0");

 /*
        +----+--------------------------------+-------------+
        | op |                             f0 |          pv |
        +----+--------------------------------+-------------+
        | +I |                             sx |           1 |
        | -U |                             sx |           1 |
        | +U |                             sx |           3 |
        | +I |                             gx |           1 |
        | -U |                             sx |           3 |
        | +U |                             sx |           5 |
        | -U |                             gx |           1 |
        | +U |                             gx |           3 |
        +----+--------------------------------+-------------+
*/

// 从kafka再读出上面的changelog结果
tenv.executeSql("select * from upsert_kafka").print();

 /*
    +----+--------------------------------+----------------------+
    | op |                       province |                   pv |
    +----+--------------------------------+----------------------+
    | +I |                             sx |                    1 |
    | -U |                             sx |                    1 |
    | +U |                             sx |                    3 |
    | +I |                             gx |                    1 |
    | -U |                             sx |                    3 |
    | +U |                             sx |                    5 |
    | -U |                             gx |                    1 |
    | +U |                             gx |                    3 |
  */
```



### 7.6.4 **jdbc connector详解**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  jdbc connector有如下特性</span>**

* 可作为<span style="color: rgb(216,57,49); background-color: inherit">scan source</span> ，底层产生Bounded Stream

* 可作为<u><span style="color: rgb(216,57,49); background-color: inherit">lookup source</span></u>，底层是“事件驱动”式查询

* 可作为 Batch模式的sink

* 可作为 Stream模式下的  append sink和upsert sink



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  所需依赖</span>**

```xml
<dependency>
  <groupId>org.apache.flink</groupId>
  <artifactId>flink-connector-jdbc</artifactId>
  <version>1.15.2</version>
</dependency>

```



根据所连接的数据库不同，需要相应的jdbc驱动，比如连接mysql

```xml
<dependency>
   <groupId>mysql</groupId>
   <artifactId>mysql-connector-java</artifactId>
   <version>8.0.21</version>
</dependency>
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  建表语句示例</span>**

```sql
-- 将mysql的users表，注册到flinksql中
CREATE TABLE MyUserTable (
  id BIGINT,
  name STRING,
  age INT,
  status BOOLEAN,
  PRIMARY KEY (id) NOT ENFORCED
) WITH (
   'connector' = 'jdbc',
   'url' = 'jdbc:mysql://doitedu:3306/mydatabase',
   'table-name' = 'users'
);

-- 将一个查询结果，通过jdbc连接器表插入到mysql表中
INSERT INTO MyUserTable
SELECT id, name, age, status FROM T;

-- 从jdbc连接器表查询数据（scan模式）
SELECT id, name, age, status FROM MyUserTable;

-- 将jdbc连接器表作为一个维表进行时态关联（temporal join详见后续的查询详解章节）
SELECT * FROM myTopic
LEFT JOIN MyUserTable FOR SYSTEM_TIME AS OF myTopic.proctime
ON myTopic.key = MyUserTable.id;
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  幂等写出</span>**

jdbc connector 可以利用目标数据库的特性，实现幂等写出；

幂等写出可以避免在failover发生后的可能产生的数据重复；

&#x20;

<u>实现幂等写出，本身并不需要对jdbc connector 做额外的配置，只需要：</u> <u><span style="color: inherit; background-color: rgb(255,233,40)">指定主键字段</span></u> <u> ，jdbc connector 就会利用目标数据库的upsert语法（如下），来实现幂等写出；</u>



### **7.6.5 filesystem connector**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  filesystem connector 表特性</span>**

* 可读可写

* 作为source表时，支持持续监视读取目录下新文件，且每个新文件只会被读取一次

* 作为sink表时，支持 多种文件格式、分区、文件滚动、压缩设置等功能



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  参数举例</span>**

```sql
path
format
source.monitor-interval
sink.rolling-policy.file-size
sink.rolling-policy.rollover-interval
sink.rolling-policy.check-interval
auto-compaction=false  自动压缩
compaction.file-size = rolling file size  压缩文件目标大小
sink.partition-commit.trigger 分区提交触发器，可用 process-time,partition-time（需要watermark）
sink.partition-commit.delay 提交延迟 ，可用  '1 d' , '1 h' , '1 s'等
sink.partition-commit.policy.kind = success-file ，提交策略，可取 metastore
sink.parallelism = none   sink并行度
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  实例代码</span>**

```sql
public class Demo13_FileSystemConnectorTest {
    public static void main(String[] args) throws Exception {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.enableCheckpointing(1000, CheckpointingMode.EXACTLY_ONCE);
        env.getCheckpointConfig().setCheckpointStorage("file:///d:/checkpoint");
        env.setRuntimeMode(RuntimeExecutionMode.STREAMING);

        EnvironmentSettings environmentSettings = EnvironmentSettings.inStreamingMode();
        StreamTableEnvironment tenv = StreamTableEnvironment.create(env, environmentSettings);


        // 建表来映射 mysql中的 flinktest.stu
        tenv.executeSql(
                "CREATE TABLE fs_table (\n" +
                        "  user_id STRING,\n" +
                        "  order_amount DOUBLE,\n" +
                        "  dt STRING,\n" +
                        "  `hour` STRING\n" +
                        ") PARTITIONED BY (dt, `hour`) WITH (\n" +
                        "  'connector'='filesystem',\n" +
                        "  'path'='file:///d:/filetable/',\n" +
                        "  'format'='json',\n" +
                        "  'sink.partition-commit.delay'='1 h',\n" +
                        "  'sink.partition-commit.policy.kind'='success-file',\n" +
                        "  'sink.rolling-policy.file-size' = '8M',\n" +
                        "  'sink.rolling-policy.rollover-interval'='30 min',\n" +
                        "  'sink.rolling-policy.check-interval'='10 second'\n" +
                        ")"
        );


        // u01,88.8,2022-06-13,14
        SingleOutputStreamOperator<Tuple4<String, Double, String, String>> stream = env
                .socketTextStream("doitedu", 9999)
                .map(s -> {
                    String[] split = s.split(",");
                    return Tuple4.of(split[0], Double.parseDouble(split[1]), split[2], split[3]);
                }).returns(new TypeHint<Tuple4<String, Double, String, String>>() {
                });

        tenv.createTemporaryView("orders",stream);

        tenv.executeSql("insert into fs_table select * from orders");



        env.execute();
    }
```



### **7.6.6 flink-doris-connector**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> flink-doris-connector （用于读写doris）</span>**

```sql
CREATE TABLE cdc_mysql_source (
  id int
  ,name VARCHAR
  ,PRIMARY KEY (id) NOT ENFORCED
) WITH (
 'connector' = 'mysql-cdc',
 'hostname' = 'doitedu',
 'port' = '3306',
 'username' = 'root',
 'password' = 'password',
 'database-name' = 'db_doit',
 'table-name' = 't_doit'
);

-- 支持删除事件同步(sink.enable-delete='true'),需要 Doris 表开启批量删除功能
CREATE TABLE doris_sink (
id INT,
name STRING
) 
WITH (
  'connector' = 'doris',
  'fenodes' = 'doitedu:8030',
  'table.identifier' = 'db_doit.t_doit',
  'username' = 'root',
  'password' = '',
  'sink.properties.format' = 'json',
  'sink.properties.strip_outer_array' = 'true',
  'sink.enable-delete' = 'true'
);

insert into doris_sink select id,name from cdc_mysql_source;
```



# **8 cdc连接器**

## **8.1 cdc的通用概念**

CDC，Change Data Capture,**变更数据获取**的简称，使用CDC我们可以从数据库中获取已提交的更改并将这些更改发送到下游，供下游使用。这些变更可以包括INSERT,DELETE,UPDATE等，

用户可以在以下的场景下使用CDC：

* 使用flink sql进行数据同步,将数据从一个地方同步到其他地方，比如从mysql到doris

* 可以在源数据库上实时的物化一个聚合视图

* 因为只是增量同步，所以可以实时的低延迟的同步数据

市面上有大量类似cdc的工具，知名度最高的如： <span style="color: rgb(36,91,219); background-color: inherit">canal</span>，<span style="color: rgb(36,91,219); background-color: inherit">Debezium</span>

如canal，可以捕获到mysql的binlog，形成cdc日志形式的输出供给下游使用；

## **8.2 flinksql对cdc的支持**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> flinksql底层的设计，就天然支持cdc</span>**

* 在flinksql 中，cdc数据几乎等价于changelog：&#x20;

*&#x20;<span style="color: inherit; background-color: rgba(222,224,227,0.8)">cdc的数据格式，是对变化数据的表达模式；changelog也如是；</span>*

* flinksql对cdc的支持，核心就在对record的rowkind（+I/-U/+U/-D）进行适配；

&#x20;

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> flinksql中操作cdc数据，通过cdc连接器即可</span>**

* 不需要开发者做太多的底层维护操作

* 使用各种cdc connector就可以获得输入的cdc模式数据并转成changelog流（映射成表）

* 对cdc表进行各种sql查询时，flink也已做好了适配

* 并且还可以把计算结果的cdc数据，通过cdc connector输出到目标存储系统

&#x20;

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink的cdc connector，在核心包中是没有集成的，需要额外引入依赖；</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">目前，官方有一个专门的开源项目，提供了若干种常用的cdc-connector；</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">项目地址： </span>
[<u><span style="color: rgb(100,37,208); background-color: rgba(222,224,227,0.8)">ververica/flink-cdc-connectors: CDC Connectors for Apache Flink® (github.com)</span></u>](https://github.com/ververica/flink-cdc-connectors)



## **8.3 mysql-cdc-connector使用**



1. **mysql binlog配置**

* 修改mysql配置文件， /etc/my.cnf

* 在\[mysqld]节的下面添加如下配置（最简配置）

```properties
log-bin=mysql-bin #开启binlog
binlog-format=ROW #选择row模式
server_id=1 #配置mysql replaction需要定义，不能和canal的slaveId重复
```

复杂的配置

```properties
server-id=1
log_bin=/var/lib/mysql/mysql-bin.log
expire_logs_days=7
binlog_format=ROW
max_binlog_size=100M
binlog_cache_size=16M
max_binlog_cache_size=256M
relay_log_recovery=1
sync_binlog=1
innodb_flush_log_at_trx_commit=1
```



* 配置完成后，重启mysql服务

```properties
systemctl restart mysqld
```

* 查看binlog是否生效



```properties
mysql> show variables like 'log_%';
+----------------------------------------+--------------------------------+
| Variable_name                          | Value                          |
+----------------------------------------+--------------------------------+
| log_bin                                | ON                             |
| log_bin_basename                       | /var/lib/mysql/mysql-bin       |
| log_bin_index                          | /var/lib/mysql/mysql-bin.index |
```



* 导入依赖

```xml
<!-- 导入flink mysql cdc的依赖，就是Flink特殊的源 -->
<dependency>
   <groupId>com.ververica</groupId>
   <artifactId>flink-sql-connector-mysql-cdc</artifactId>
   <version>2.3.0</version>
</dependency>

       <!-- 将以前引入MySQL的依赖注释掉，因为会与cdc引入的mysql依赖冲突 -->
<!--      <dependency>-->
<!--         <groupId>mysql</groupId>-->
<!--         <artifactId>mysql-connector-java</artifactId>-->
<!--         <version>8.0.30</version>-->
<!--      </dependency>-->
```







* **flink-mysql-cdc代码测试**

```java
public class MysqlCdcConnector {

    public static void main(String[] args) {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.enableCheckpointing(1000, CheckpointingMode.EXACTLY_ONCE);
        env.getCheckpointConfig().setCheckpointStorage("file:///d:/checkpoint");

        StreamTableEnvironment tenv = StreamTableEnvironment.create(env);

        // 建cdc连接器源表
        tenv.executeSql("CREATE TABLE flink_score (\n" +
                "      id INT,\n" +
                "      name string,\n" +
                "      gender string,\n" +
                "      score double,\n" +
                "     PRIMARY KEY(id) NOT ENFORCED\n" +
                "     ) WITH (\n" +
                "     'connector' = 'mysql-cdc',\n" +
                "     'hostname' = 'doitedu',\n" +
                "     'port' = '3306',\n" +
                "     'username' = 'root',\n" +
                "     'password' = 'root',\n" +
                "     'database-name' = 'flinktest',\n" +
                "     'table-name' = 'score'\n" +
                ")");

        // 简单查询
        tenv.executeSql("select * from flink_score")/*.print()*/;

        // groupby聚合查询
        tenv.executeSql("select  gender,avg(score) as avg_score  from  flink_score group by gender")/*.print()*/;

        // 建一个目标表，用来存放查询结果： 每种性别中，总分最高的前2个人
        tenv.executeSql(
                "create table flink_rank(\n" +
                        "   gender  string  , \n" +
                        "   name string, \n" +
                        "   score_amt double, \n" +
                        "   rn bigint  , \n" +
                        "   primary key(gender,rn) not enforced  \n" +
                        ") with (\n" +
                        "  'connector' = 'jdbc',\n" +
                        "  'url' = 'jdbc:mysql://doitedu:3306/flinktest',\n" +
                        "  'table-name' = 'score_rank',\n" +
                        "  'username' = 'root',\n" +
                        "  'password' = 'root' \n" +
                        ")"
        );

        // 执行复杂查询，并将结果以upsert模式写入mysql
        tenv.executeSql("insert into flink_rank  \n" +
                "SELECT\n" +
                "  gender,\n" +
                "  name,\n" +
                "  score_amt,\n" +
                "  rn\n" +
                "from(\n" +
                "    SELECT\n" +
                "      gender,\n" +
                "      name,\n" +
                "      score_amt,\n" +
                "      row_number() over(partition by gender order by score_amt desc) as rn\n" +
                "    from \n" +
                        "(\n" +
                            "SELECT\n" +
                            "gender,\n" +
                            "name,\n" +
                            "sum(score) as score_amt\n" +
                            "from flink_score\n" +
                            "group by gender,name\n" +
                        ") o1\n" +
                "    ) o2\n" +
                "where rn<=2");
    }
}
```



# **9 表与流的集成**

## **9.1 changelogStream**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 动态表概念回顾</span>**

如前文第一章所述，flinksql中的表相关概念，是持续输入，持续查询，持续数据的动态概念；很多关系运算，如分组聚合，分组topn，全局topn，表关联等运算查询，在动态表的概念中，其输出结果不是一个简单的“结果记录”不断追加的状态，而是一个需要对“前序”结果进行修正的状态；为了能向下游传递其输出结果的动态信息，flink设计了一种DataStream，叫做changelogStream（改变日志流）；

&#x20;

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 现象观察</span>**

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">有如下测试数据：</span>

```java
DataType schema = DataTypes.ROW(
        DataTypes.FIELD("id", DataTypes.INT()),
        DataTypes.FIELD("event", DataTypes.STRING()),
        DataTypes.FIELD("ts", DataTypes.BIGINT())
);
Table table = tenv.fromValues(
        schema,
        row(1, "e1", 1000),
        row(1, "e1", 2000),
        row(1, "e2", 3000),
        row(1, "e3", 4000),
        row(1, "e3", 5000),
        row(1, "e2", 6000),
        row(1, "e2", 7000)
);
tenv.createTemporaryView("t",table);
```



* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">执行查询1：求每种事件的发生次数</span>

```java
tenv.executeSql("select event,count(1) as event_cnt from t group by event")
  .print();
```

![](<images/06 FlinkSQL-image-17.png>)





# **10 表输出详解**

## 10.1 **输出方式**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 利用table对象的api输出</span>**

![](<images/06 FlinkSQL-image-23.png>)



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 将table对象转成datastream，然后用sink 算子输出</span>**

![](<images/06 FlinkSQL-image-16.png>)



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 用insert语句输出</span>**

```sql
tenv.executeSql("insert into dest_table select ... from t1");
```

## **10.2 多语句批量执行**

```sql
// 构建一个statementSet
StatementSet stmtSet = tenv.createStatementSet();
// 添加insert
stmtSet.addInsert("t_dest",table);
stmtSet.addInsert(TableDescriptor.forConnector(...).build(),t1); 
stmtSet.addInsertSql("insert into t_dest select ... from t1");
// 批量执行
stmtSet.execute();
```



# **11 表查询详解**

## 11.1 **table api 概览**



![](<images/06 FlinkSQL-image-22.png>)



## **11.2 基本查询**

* select&#x20;

```sql
SELECT order_id, price + tax FROM Orders
```

* where 过滤

```sql
SELECT order_id, price
FROM orders
WHERE price+10 > 100;
```

* group by 聚合

```sql
SELECT order_id, SUM(price)
FROM orders
WHERE price > 100
GROUP BY order_id
HAVING SUM(price) >200;
```

* with 语法

```sql
 WITH orders_with_total AS (
    SELECT order_id, price + tax AS total
    FROM Orders
)
SELECT order_id, SUM(total)
FROM orders_with_total
GROUP BY order_id;
```

* distinct 去重

```sql
SELECT DISTINCT uid FROM Orders
```

* limit

```sql
 SELECT order_id, price + tax FROM Orders limit 10
```

* order by&#x20;

```sql
 SELECT order_id, price + tax FROM Orders order by price desc
```



实战案例：有如下数据，是一个游戏公司产生的游戏日志，要求按照游戏ID、游戏ZoneID（区）、统计充值累加金额，在游戏新开区时，某个区的用户比较多，如果直接按照游戏ID、游戏ZoneID进行groupBy，会导致数据倾斜。要解决数据倾斜和写入MySQL过慢导致的背压问题

```sql
-- gid,zid,uid,money
g001,z01,u001,300
g001,z02,u011,100
g002,z01,u001,100
g001,z03,u012,100
g001,z03,u012,100
g001,z03,u013,100
```







## **11.3 高阶聚合**



### **11.3.1 高阶聚合方式**

```sql
group by cube(维度1，维度2，维度3)
group by grouping sets((维度1，维度2), (维度1，维度3), (维度2)，())
group by rollup(省，市，区)
```

### **11.3.2 语法示例**

* cube

```sql
select
  province,
  city,
  region,
  count(distinct uid) as u_cnt
from t 
group by cube(province,city,region)
```



* grouping sets

```sql
select
  province,
  city,
  region,
  count(distinct uid) as u_cnt
from t 
group by grouping sets((province,city),(province,city,region))
```



* rollup

```sql
select
  province,
  city,
  region,
  count(distinct uid) as u_cnt
from t 
group by rollup(province,city,region)
```



## **11.4 时间窗口TVF（表值函数）**

flink1.13开始，提供了时间窗口聚合计算的TVF语法

* 表值函数的使用约束：

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">1. 在窗口上做</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">分组聚合</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">，必须带上 window_start 和 window_end 作为分组key</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">2. 在窗口上做</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">topN 计算</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)"> ，必须带上window_start 和 window_end 作为 partition的 key.</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">3. 带条件的</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">join</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">，必须包含 2个输入表的window start 和 window end 等值条件.</span>

```sql
select  
  .......
from  TABLE(TUMBLE( TABLE t_x, DESCRIPTOR(rt), interval  '10' minute))
```



### 11.4.1 **支持的时间窗口类型**

* 滚动窗口 （Tumble Windows）

```sql
TUMBLE(TABLE t_action，DESCRIPTOR(时间属性字段) ,  INTERVAL '10' SECONDS[ 窗口长度 ] ）
```



* 滑动窗口 （Hop Windows）

```sql
HOP(TABLE t_action, DESCRIPTOR(时间属性字段) , INTERVAL '5' SECONDS[ 滑动步长 ],  INTERVAL '10' SECONDS[ 窗口长度 ]  )
```



* 累计窗口（Cumulate Windows）

```sql
CUMULATE(TABLE t_action, DESCRIPTOR(时间属性字段) , INTERVAL '5' SECONDS[ 更新步长 ],  INTERVAL '10' SECONDS[ 窗口最大长度 ]  )
```



* 会话窗口（Session Windows）&#x20;

**暂不支持！**



### **11.4.2 语法示例**



```sql
select
   window_start,
   window_end,
   channel,
   count(distinct guid) as uv
from table(
  tumble(table t_applog,descriptor(rw), interval '5' minutes)
)
group by window_start,window_end,channel
```



## **11.5 window 聚合**

按照EventTime划分滚动窗口，将数据聚合后，写入到MySQL中

```sql
-- 注册Kafka的Source源表
-- 数据说明：时间,游戏id,分区id,金额
-- 数据样例：10000,g1,z1,330.0
CREATE TABLE kafka_game_log (
  ts BIGINT,
  `gameId` STRING,
  `zoneId` STRING,
  `money` DOUBLE,
  e_time as TO_TIMESTAMP_LTZ(ts, 3), -- 将long类型的ts转成timestamp(3)
  WATERMARK FOR e_time AS e_time - INTERVAL '2' SECOND
) WITH (
  'connector' = 'kafka', -- 指定connector类型
  'topic' = 'game-log', -- 指定从Kafka中读取数据的topic
  'properties.bootstrap.servers' = 'node-1.51doit.cn:9092,node-2.51doit.cn:9092,node-3.51doit.cn:9092', -- 指定kafka的地址
  'properties.group.id' = 'testGroup', -- 指定消费者组ID
  'scan.startup.mode' = 'latest-offset', -- 指定消费的起始偏移量
  'format' = 'csv', -- 读取csv格式，默认的分隔符为","
  'csv.ignore-parse-errors' = 'true' -- 忽略解析失败的数据
)
;

-- 创建一个Sink表，类型为print
-- 创建Sink表
CREATE TABLE print_table (
  `gameId` STRING,
  `zoneId` STRING,
  win_start TIMESTAMP(3),
  win_end TIMESTAMP(3),
  `money` DOUBLE
) WITH (
  'connector' = 'print' -- 指定为print sink，将数据在控制台打印
)
;

INSERT INTO print_table
SELECT
  gameId,
  zoneId,
  window_start win_start,
  window_end win_end,
  sum(money) money
FROM TABLE(
  TUMBLE(TABLE kafka_game_log, DESCRIPTOR(e_time), INTERVAL '10' SECOND))
GROUP BY window_start, window_end, gameId, zoneId
```



## **11.6 window topn**

flink目前只支持滚动窗口的TopN

```sql
-- 注册Kafka的Source源表
-- 数据说明：时间,游戏id,分区id,金额
-- 数据样例：10000,g1,z1,330.0
CREATE TABLE kafka_game_log (
  ts BIGINT,
  `gameId` STRING,
  `zoneId` STRING,
  `money` DOUBLE,
  e_time as TO_TIMESTAMP_LTZ(ts, 3), -- 将long类型的ts转成timestamp(3)
  WATERMARK FOR e_time AS e_time - INTERVAL '2' SECOND
) WITH (
  'connector' = 'kafka', -- 指定connector类型
  'topic' = 'game-log', -- 指定从Kafka中读取数据的topic
  'properties.bootstrap.servers' = 'node-1.51doit.cn:9092,node-2.51doit.cn:9092,node-3.51doit.cn:9092', -- 指定kafka的地址
  'properties.group.id' = 'testGroup', -- 指定消费者组ID
  'scan.startup.mode' = 'latest-offset', -- 指定消费的起始偏移量
  'format' = 'csv', -- 读取csv格式，默认的分隔符为","
  'csv.ignore-parse-errors' = 'true' -- 忽略解析失败的数据
)
;
-- 创建Sink表
CREATE TABLE game_res (
  `gameId` STRING,
  `zoneId` STRING,
  `money` DOUBLE,
  rk BIGINT -- 排序顺序
) WITH (
  'connector' = 'print'
)
;

-- 先按照窗口进行聚合
select
  gameId,
  zoneId,
  window_start,
  window_end,
  money,
  rk
from
(
  select
    gameId,
    zoneId,
    window_start,
    window_end,
    money,
    row_number() over(partition by gameId, window_start, window_end order by money desc) rk
  from
  (
    SELECT
      gameId,
      zoneId,
      window_start,
      window_end,
      sum(money) money
    FROM TABLE(
      TUMBLE(TABLE kafka_game_log, DESCRIPTOR(e_time), INTERVAL '10' SECOND))
    GROUP BY window_start, window_end, gameId, zoneId
  )
) where rk <= 3
```



## **11.7 window join**

<span style="color: inherit; background-color: rgb(255,233,40)">将数据缓存在窗口中，如果条件相同，并且在同一个窗口内，就可以join上</span>，窗口触发后，会清除缓存在窗口内的数据。

```sql
-- 让两个流实现window的join
-- 窗口一个第一个流对应的表
CREATE TABLE LeftTable (
  `row_time` TIMESTAMP(3),
  `num` INT,
  `id` STRING,
  WATERMARK FOR `row_time` AS row_time - INTERVAL '1' SECOND
) WITH (
  'connector' = 'kafka',
  'topic' = 'tp-left1',
  'properties.bootstrap.servers' = 'node-1.51doit.cn:9092,node-2.51doit.cn:9092,node-3.51doit.cn:9092',
  'properties.group.id' = 'testGroup1',
  'scan.startup.mode' = 'latest-offset',
  'format' = 'csv',
  'csv.ignore-parse-errors' = 'true'
  )
;

CREATE TABLE RightTable (
  `row_time` TIMESTAMP(3),
  `num` INT,
  `id` STRING,
  WATERMARK FOR `row_time` AS row_time - INTERVAL '1' SECOND
) WITH (
  'connector' = 'kafka',
  'topic' = 'tp-right1',
  'properties.bootstrap.servers' = 'node-1.51doit.cn:9092,node-2.51doit.cn:9092,node-3.51doit.cn:9092',
  'properties.group.id' = 'testGroup2',
  'scan.startup.mode' = 'latest-offset',
  'format' = 'csv',
  'csv.ignore-parse-errors' = 'true'
  )
;

select
  L.num as L_Num, L.id as L_Id, R.num as R_Num, R.id as R_Id, L.window_start, L.window_end
from
(
  SELECT
    *
  FROM TABLE(
    TUMBLE(TABLE LeftTable, DESCRIPTOR(row_time), INTERVAL '5' MINUTES)
  )
) L
FULL JOIN
(
  SELECT
    *
  FROM TABLE(
    TUMBLE(TABLE RightTable, DESCRIPTOR(row_time), INTERVAL '5' MINUTES)
  )
) R
ON L.num = R.num and L.window_start = R.window_start and L.window_end = R.window_end
```

## **11.8 regular join**



regular join(常规join)是<span style="color: inherit; background-color: rgb(255,233,40)">将所有的数据都缓存到状态中</span>，<span style="color: inherit; background-color: rgb(255,233,40)">默认是一直缓存</span>，也可以设置TTL，参数如下：

#####

```java
configuration.set("table.exec.state.ttl", "5000ms"); //设置状态态TTL
```



* Innerjoin

```sql
SELECT * FROM Orders INNER JOIN Product ON Orders.productId = Product.id
```



* OuterJoin

```sql
SELECT *
FROM Orders
LEFT JOIN Product
ON Orders.product_id = Product.id

SELECT *
FROM Orders
RIGHT JOIN Product
ON Orders.product_id = Product.id

SELECT *
FROM Orders
FULL OUTER JOIN Product
ON Orders.product_id = Product.id
```



## **11.9 lookup join**

### **11.9.1 Lookup join的内在原理**

![](<images/06 FlinkSQL-image-15.png>)

根据商品分类ID，查询MySQL维表关联维度

```sql
-- 创建Source表
CREATE TABLE kafka_events (
  `oid` STRING,
  `cid` BIGINT,
  `money` double,
  `proctime` AS PROCTIME() -- 取出当前的系统时间作为processingTime
) WITH (
  'connector' = 'kafka', -- 指定connector类型
  'topic' = 'event-log', -- 指定从Kafka中读取数据的topic
  'properties.bootstrap.servers' = 'node-1.51doit.cn:9092,node-2.51doit.cn:9092,node-3.51doit.cn:9092', -- 指定kafka的地址
  'properties.group.id' = 'testGroup', -- 指定消费者组ID
  'scan.startup.mode' = 'earliest-offset', -- 指定消费的起始偏移量
  'format' = 'csv', -- 读取csv格式，默认的分隔符为","
  'csv.ignore-parse-errors' = 'true' -- 忽略解析失败的数据
)
;
-- 创建维表
CREATE TABLE tb_dimemsion (
  id BIGINT,
  name STRING
) WITH (
  'connector' = 'jdbc',
  'url' = 'jdbc:mysql://node-1.51doit.cn:3306/doit32?characterEncoding=utf-8',
  'table-name' = 'tb_category', -- 在MySQL中实际对应的表
  'username' = 'root',
  'password' = '123456',
  'lookup.cache.max-rows' = '500', -- 缓存数据的最大行数
  'lookup.cache.ttl' = '2min' -- 缓存数据的时长
)
;
-- 创建Sink表
CREATE TABLE result_sink (
  `oid` STRING,
  `cid` BIGINT,
  `money` double,
  name STRING
) WITH (
  'connector' = 'print' -- 指定connector类型
)
;
-- 查询语句并插入到sink表中
INSERT INTO result_sink SELECT oid, cid, money, name FROM kafka_events
LEFT JOIN tb_dimemsion FOR SYSTEM_TIME AS OF kafka_events.proctime -- 以kafka_events表中的proctime做为缓存的时间判断标准
ON kafka_events.cid = tb_dimemsion.id
```



## 11.10 **interval join**

按照时间范围进行join

```sql
SELECT * FROM Orders o, Shipments s
WHERE o.id = s.order_id
AND o.order_time BETWEEN s.ship_time - INTERVAL '4' HOUR AND s.ship_time + INTERVAL '4' HOUR
```

* 时间区间条件的可用语法：

* ltime = rtime

* ltime >= rtime AND ltime < rtime + INTERVAL '10' MINUTE

* ltime BETWEEN rtime - INTERVAL '10' SECOND AND rtime + INTERVAL '5' SECOND





## **11.11 temporal join（时态join/版本join）**

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">要义：  </span> <span style="color: inherit; background-color: rgb(255,233,40)">左表的数据永远去</span> <span style="color: inherit; background-color: rgb(255,165,61)">关联右表数据的对应时间上的最新版本</span>

```sql
-- 有如下交易订单表（订单id，金额，货币，时间）
1,88,e,1000
2,88,e,1999
2,88,e,2999
3,68,e,3000
3,68,e,3500
3,68,e,2000

-- 有如下汇率表（货币，汇率，更新时间）
e,1.0,1000
e,2.0,3000


-- temporal join 的结果如下
1,88,e,1000  , 1.0
2,88,e,2000  , 1.0
3,68,e,3000  , 2.0
```



* 创建表orders

```sql
.
-- append-only表
CREATE TABLE orders (
    order_id    STRING,
    price       DECIMAL(32,2),
    currency    STRING,
    order_time  TIMESTAMP(3),
    WATERMARK FOR order_time AS order_time
) WITH (/* ... */);
```



* 创建汇率表（典型的versioned 动态表，带时间属性字段）

```sql
-- 比如，从cdc过来的表
CREATE TABLE currency_rates (
    currency STRING,
    conversion_rate DECIMAL(32, 2),
    update_time TIMESTAMP(3) METADATA FROM `values.source.timestamp` VIRTUAL,
    WATERMARK FOR update_time AS update_time,
    PRIMARY KEY(currency) NOT ENFORCED
) WITH (
   'connector' = 'kafka',
   'value.format' = 'debezium-json',
   /* ... */
);
```



* 查询语句

```sql
SELECT 
     order_id,
     price,
     currency,
     conversion_rate,
     order_time
FROM orders
LEFT JOIN currency_rates FOR SYSTEM_TIME AS OF orders.order_time
ON orders.currency = currency_rates.currency;
```



* 返回结果

```sql
order_id  price  currency  conversion_rate  order_time
========  =====  ========  ===============  =========
o_001     11.11  EUR       1.14             12:00:00
o_002     12.51  EUR       1.10             12:06:00
```



## **11.12 over 窗口聚合**

row\_number( ) over (  )

&#x20;

flinksql中，over聚合时，指定聚合数据区间有两种方式

* 方式1，带时间设定区间

RANGE **BETWEEN** <span style="color: rgb(36,91,219); background-color: inherit">INTERVAL</span> <span style="color: rgb(216,57,49); background-color: inherit">&#39;30&#39;</span> **MINUTE** PRECEDING **AND** **CURRENT** **ROW**

&#x20;

* 方式2，按行设定区间

**ROWS** **BETWEEN** <span style="color: rgb(143,149,158); background-color: inherit">10</span> PRECEDING **AND** **CURRENT** **ROW**





```sql
SELECT order_id, order_time, amount,
  SUM(amount) OVER (
    PARTITION BY product
    ORDER BY order_time
    RANGE BETWEEN INTERVAL '1' HOUR PRECEDING AND CURRENT ROW
  ) AS one_hour_prod_amount_sum
FROM Orders
```



```sql
SELECT order_id, order_time, amount,
  SUM(amount) OVER w AS sum_amount,
  AVG(amount) OVER w AS avg_amount
FROM Orders
WINDOW w AS (
  PARTITION BY product
  ORDER BY order_time
  RANGE BETWEEN INTERVAL '1' HOUR PRECEDING AND CURRENT ROW)
```



# **12 内置函数及自定义函数**



## **12.1 ScalarFunction（UDF）**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">标量函数</span>

特点： 每次只接收一行的数据，输出结果也是1行1列

典型的标量函数如： upper(str), lower(str), abs(salary)

&#x20;

## **12.2 TableFunction （UDTF）**

表生成函数

特点：运行时每接收一行数据（一个或多个字段），能产出多行、多列的结果

典型的如： explode( ) ,  unnest ( )

&#x20;

## **12.3 AggregateFunction （UDAF）**

聚合函数

特点：对输入的数据行（一组）进行持续的聚合，最终对每组数据输出一行（多列）结果

典型的如： sum( )  max( )

&#x20;

## **12.4 TableAggregateFunction**

聚合函数

特点：对输入的数据行（一组）进行持续的聚合，最终对每组数据输出一行或多行（多列）结果

&#x20;







# **13 SqlClient使用**

## **13.1 基本介绍**

sql-client是flink安装包中自带的一个命令行工具，用于快捷方便地进行sql操作

注意： 首先要启动一个flink session集群 (standalone，on yarn)

* 命令核心参数：

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">-f :  指定初始化sql脚本文件</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">-l : 指定要添加的外部jar包所在的文件夹（来加载文件夹中所有的依赖jar）</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">-j : 指定一个jar包文件路径来加载这个jar包依赖</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">-s : 指定要连接的flink session集群</span>

&#x20;

![](<images/06 FlinkSQL-image-20.png>)



## **13.2 完整示例**

* 需求背景：

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">从kafka中读取一个topic的数据</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">然后统计每5分钟的去重用户数</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">并且，把结果写入mysql</span>



* 操作步骤

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: rgb(143,149,158); background-color: rgb(247,105,100)">1</span> <span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 需要额外的依赖jar包</span>**

* flink-connector-jdbc\_2.12-1.15.2.jar

* flink-csv-1.15.2.jar

* flink-json-1.15.2.jar

* flink-sql-connector-kafka\_2.12-1.15.2.jar

可以把这些jar包直接放在flink安装目录的lib中，当然，也可以放在任意一个自定义的目录

&#x20;

&#x20;

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: rgb(143,149,158); background-color: rgb(247,105,100)">2</span> <span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 启动sql-client</span>**

```sql
 bin/sql-client.sh  -l lib/
```

&#x20;

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: rgb(143,149,158); background-color: rgb(247,105,100)">3</span> <span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 需求开发</span>**

&#x20;

* 建数据源表（kafka连接器表）

```sql
 CREATE TABLE events (
      account            STRING  ,
      appId              STRING  ,
      appVersion         STRING  ,
      carrier            STRING  ,
      deviceId           STRING  ,
      deviceType         STRING  ,
      eventId            STRING  ,
      ip                 STRING  ,
      latitude           DOUBLE  ,
      longitude          DOUBLE  ,
      netType            STRING  ,
      osName             STRING  ,
      osVersion          STRING  ,
      properties         MAP<STRING,STRING>  ,
      releaseChannel     STRING  ,
      resolution         STRING  ,
      sessionId          STRING  ,
      `timeStamp`        BIGINT  ,
      rt as to_timestamp_ltz(`timeStamp`,3),
      watermark for rt as rt - interval '0' second
) WITH (
  'connector' = 'kafka',
  'topic' = 'doit-events',
  'properties.bootstrap.servers' = 'doitedu:9092',
  'properties.group.id' = 'testGroup',
  'scan.startup.mode' = 'earliest-offset',
  'format' = 'json'
)
```

* 目标表的创建

```sql
CREATE TABLE uv_report (
  window_start timestamp(3),
  window_end  timestamp(3),
  uv bigint
) WITH (
   'connector' = 'jdbc',
   'url' = 'jdbc:mysql://doitedu:3306/doitedu',
   'table-name' = 'uv_report',
   'username' = 'root',
   'password'= 'root'
);
```

* 查询sql开发

```sql
INSERT INTO uv_report
SELECT
   window_start,
   window_end,
   count(distinct deviceId) as uv
FROM TABLE(TUMBLE(table events,descriptor(rt),interval '1' minute))
group by window_start,window_end
```



# **13 FlinkSql与hive集成**

Flinksql与hive有两个整合角度

角度1：元数据整合

角度2：将flink做为hive的执行引擎

## **13.1 idea中整合hive catalog**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 准备hive配置文件</span>**

准备一个hive-site.xml配置文件（可放在任何本地目录），至少包含如下内容



```xml
<configuration>
  <property>
    <name>hive.metastore.uris</name>
    <value>thrift://node-1.51doit.cn:9083</value>
  </property>
</configuration>
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 添加依赖</span>**

```xml
<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-connector-hive_2.12</artifactId>
    <version>1.15.2</version>
    <scope>provided</scope>
</dependency>

<dependency>
    <groupId>org.apache.hive</groupId>
    <artifactId>hive-exec</artifactId>
    <version>3.1.2</version>
    <scope>provided</scope>
</dependency>

<dependency>
    <groupId>org.apache.hadoop</groupId>
    <artifactId>hadoop-client-api</artifactId>
    <version>3.2.1</version>
</dependency>
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 在代码中注册hive catalog</span>**

```java
String catalogTypename  = "hive";
String defaultDatabase = "default";
String hiveConfDir     = "D:/hiveconf/";

// 创建和注册 hive catalog
HiveCatalog hive = new HiveCatalog(catalogTypeName, defaultDatabase, hiveConfDir);
tenv.registerCatalog("myhive", hive);

 // set the HiveCatalog as the current catalog of the session
tenv.useCatalog("myhive");

// 打印当前env中所有的catalog
tenv.executeSql("show catalogs").print();

// 查询hive中的表
tenv.executeSql("select * from t2").print();
```



## **14.2 sql-client中整合hive catalog**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 添加依赖</span>**

在flink安装目录中，创建一个文件夹，如extlib ；

放入所需的依赖 ：

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink-connector-hive_2.12-1.15.2.jar  (hive整合所需)</span>

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink-sql-connector-kafka_2.12-1.15.2.jar   (示例中需要用到kafka连接器)</span>

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink-shaded-hadoop-3-uber-3.1.1.7.2.9.0-173-9.0.jar   (与hadoop整合所需)</span>

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink-csv-1.15.2.jar  (支持csv格式所需）</span>

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink-json-1.15.2.jar  (支持json格式所需）</span>



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 启动sql-client</span>**

```sql
bin/sql-client.sh -l extlib/
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 注册hive catalog</span>**

```sql
Flink SQL> create catalog myhive with ('type' = 'hive', 'hive-conf-dir' = '/opt/apps/hive-3.1.2/conf');
[INFO] Execute statement succeed.

Flink SQL> use catalog myhive;
[INFO] Execute statement succeed.

Flink SQL> load module hive;
[INFO] Execute statement succeed.

Flink SQL> use modules hive,core;
[INFO] Execute statement succeed.

Flink SQL> set table.sql-dialect=hive;
[INFO] Session property has been set.
```



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 查看catalog中的表</span>**

```sql
Flink SQL> show tables;
+------------+
| table name |
+------------+
|          t |
|         t2 |
+------------+
```
