# **1 FlinkSQL快速认识**

## **1.1 基本原理和架构**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">flink sql是架构于flink core之上用sql语义方便快捷地进行结构化数据处理的上层库；（非常类似sparksql和sparkcore的关系）。更方便的进行数据分析!</span>

和spark一样 flink-sql提供了如下两种处理数据的方式&#x20;

* Table  API&#x20;

* 纯  SQL

### **1.1.1 整体架构和工作流程**

核心工作原理如下： 流--->表   表--->流

* &#x20;将源数据流（数据集），绑定元数据（schema）后，注册成<span style="color: inherit; background-color: rgba(183,237,177,0.8)">catalog</span>中的表（table、view）；

* 然后由用户通过table Api或者<span style="color: inherit; background-color: rgb(251,191,188)"> table sql</span>来表达计算逻辑；

* 由table-planner利用apache calcite进行sql语法解析，绑定元数据得到逻辑执行计划；

* 再用Optimizer进行优化后，得到物理执行计划

* 物理计划经过代码生成器生成代码，得到Transformation Tree

* Transformation Tree 转成JobGraph后提交到flink集群执行

<span style="color: inherit; background-color: rgba(183,237,177,0.8)">纯sql - 解析语法 - </span>**<span style="color: inherit; background-color: rgba(183,237,177,0.8)">绑定元数据(catalog)</span>**<span style="color: inherit; background-color: rgba(183,237,177,0.8)">  -生成逻辑执行计划 -优化(优化后的逻辑执行计划)  -物理执行计划</span>

<span style="color: inherit; background-color: rgba(183,237,177,0.8)">代码模板  -生成job图-分布式运行</span>

![](images/多易教育-FlinkSQL-image-14.png)



### **1.1.2 关于元数据管理catalog**

元数据，即描述数据的数据。简单来说，我们创建一个table之后，这个table叫什么名字、有哪些字段、字段类型，分区等信息。这都是元数据需要知道的东西，所以元数据是描述数据的数据

<span style="color: inherit; background-color: rgb(251,191,188)">catalog⽤来保存元数据（数据库、表结构、分区、视图、函数等等）</span>,Flink也提供 了catalog，当然也可以在Flink中使⽤Hive的catalog。



![](images/多易教育-FlinkSQL-image-13.png)



![](images/多易教育-FlinkSQL-image-9.png)



### **1.1.3 关于逻辑执行计划**



![](images/多易教育-FlinkSQL-image-11.png)



### **1.1.4 关于查询优化**



![](images/多易教育-FlinkSQL-image.png)



FlinkSQL中有<span style="color: inherit; background-color: rgba(255,246,122,0.8)">两个优化器</span>，分别是：RBO（基于规则的优化器）和 CBO（基于代价（成本）的优化器）

* **RBO（基于规则的优化器）**

遍历一系列规则（RelOptRule），只要满足条件就对原来的计划节点（表达式）进行转换或调整位置，生成最终的执行计划。常见的规则包括：

* 分区裁剪（Partition Prune）、列裁剪

* 谓词下推（Predicate Pushdown）、投影下推（Projection Pushdown）、聚合下推、limit下推、sort下推

* 常量折叠（Constant Folding）

* 子查询内联转join等。

下面是RBO优化示意图举例：

![](images/多易教育-FlinkSQL-image-1.png)



![](images/多易教育-FlinkSQL-image-7.png)



![](images/多易教育-FlinkSQL-image-6.png)



* **CBO（基于代价的优化器）**

会保留原有表达式，基于统计信息和代价模型，尝试探索生成等价关系表达式，最终取代价最小的执行计划。CBO的实现有两种模型，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Volcano模型</span>和<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Cascades模型</span>

这两种模型思想很是相似，不同点在于Cascades模型一边遍历SQL逻辑树，一边优化，从而进一步裁剪掉一些执行计划。

下面是CBO优化示意图举例，根据代价cost选择批处理join有方式(sortmergejoin，hashjoin，boradcasthashjoin)。比如前文中的例子，再filter下推之后，在t2.id<1000的情况下，由1 百万数据量变为了1 千条，计算cost之后，使用broadcasthashjoin最合适。

![](images/多易教育-FlinkSQL-image-8.png)

## 1.2<u> 动态表特性</u>

与spark、hive等组件中的“表”的最大不同之处：<span style="color: inherit; background-color: rgb(255,233,40)">FlinkSQL中的表是</span>**<span style="color: inherit; background-color: rgb(255,233,40)">动态表</span>**<span style="color: inherit; background-color: rgb(255,233,40)">！</span>这是因为：<span style="color: inherit; background-color: rgba(186,206,253,0.7)">flink对数据的核心抽象是“无界（或有界）的数据流”，对数据处理过程的核心抽象是“流式持续处理”。</span> <span style="color: inherit; background-color: rgb(255,233,40)">因此，FlinkSQL对“源表（动态表）”的计算及输出结果（结果表），也是流式、动态、持续的；</span>动态表的有以下特点：

* 数据源的数据&#x662F;**<span style="color: rgb(216,57,49); background-color: inherit">持续输入</span>**

* 查询过程&#x662F;**<span style="color: rgb(216,57,49); background-color: inherit">持续计算</span>**

* 查询结果&#x662F;**<span style="color: rgb(216,57,49); background-color: inherit">持续输出</span>**

如下图所示：“源表clicks”是流式动态的；“聚合查询的输出结果表”，也是流式动态的。

![](images/多易教育-FlinkSQL-image-5.png)

这其中&#x7684;**<span style="color: rgb(216,57,49); background-color: inherit">动态</span>**，不仅体现在“数据追加”，对于输出结果表来说，“动态”还包含对“前序输出结果”的“撤回（删除）”、“更新”等模式；

<u><span style="color: inherit; background-color: rgba(222,224,227,0.8)">那么FlinkSQL是如何将这种对于“前序输出的修正”表达给下游呢？</span></u>

它&#x7684;**<span style="color: rgb(100,37,208); background-color: inherit">核心设计</span>**&#x662F;在底层的数据流中为每条数据添加<span style="color: inherit; background-color: rgb(255,233,40)">“ChangeMode（修正模式）标记”</span>，而添加了这种ChangeMode标记的底层数据流，取名为<span style="color: inherit; background-color: rgb(255,233,40)">changelogStream</span>



在flink1.12之前，动态表所对应的底层stream，有3种分别是：<span style="color: inherit; background-color: rgb(255,233,40)">Append-only stream</span>、<span style="color: inherit; background-color: rgb(255,233,40)">Retract stream </span>和 <span style="color: inherit; background-color: rgb(255,233,40)">Upsert stream</span>。

<span style="color: inherit; background-color: rgb(255,233,40)">现在，统称为</span>**<span style="color: rgb(216,57,49); background-color: rgb(255,233,40)">changelog stream</span> <span style="color: inherit; background-color: rgb(255,233,40)">  KIND(数据的操作标记)</span>**

![](images/多易教育-FlinkSQL-image-4.png)

flink函数地址:&#x20;

&#x20;https://nightlies.apache.org/flink/flink-docs-release-1.17/docs/dev/table/functions/systemfunctions/#string-functions&#x20;

# **2** **FlinkSQL编程概览**

## **2.1 FlinkSQL程序结构**

* **开发FlinkSQL程序需要导入以下所需依赖：**



* **Flinksql编程4步曲**

1. 创建flinksql编程入口(StreamTableEnvironment)

2. 将数据源关联schema后，转换成表（视图）  \[1) table-name   2) Table对象]

3. 执行sql语义的查询（sql语法或者tableapi）

4. 将查询结果输出到目标表&#x20;



## **2.2 Table Environment**

<span style="color: inherit; background-color: rgb(255,233,40)">FlinkSQL的编程，总是从一个入口环境</span>**<span style="color: rgb(100,37,208); background-color: rgb(255,233,40)">TableEnvironment</span>**<span style="color: inherit; background-color: rgb(255,233,40)">开始；TableEnvironment的主要功能如下：</span>

* 注册catalogs

* 向catalog注册表

* 加载可插拔模块（目前有hive module，以用于扩展支持hive的语法、函数等）

* 执行sql查询（sql解析，查询计划生成，job提交）

* 注册用户自定义函数

* 提供datastream和table之间的互转



* 创建方式1（直接创建TableEnvironment）



* 创建方式2（从StreamExecutionEnvironment创建，这样便于结合sql和stream编程）



## **2.3 两种编程方式**

FlinkSQL提供两种编程方式：<span style="color: inherit; background-color: rgb(255,233,40)">Table Api</span>和<span style="color: inherit; background-color: rgb(255,233,40)">Table Sql，</span>类比sparksql的DataFrame api编程和SQL编程，即可快速理解。

### **2.3.1 Table Api 方式**

Table API是一个与编程语言（scala、java、python）集成的查询API；与SQL不同，查询逻辑不是以字符串表达，而是在“宿主语言”中调用所提供的类、方法等。&#x20;

复杂的运算可以通过调用多个方法组成；如： table.filter(...).groupBy(...).select(... ).join(....).on(...)

&#x20;下面是TableAPI 代码示例：

上述tableapi的计算逻辑，就等价于如下sql语句：



### **2.3.2 Table Sql 方式**

用“sql字符串”形式进行基于表的关系运算逻辑表达

### 2.3.3 混搭方式

Table API和Table SQL查询可以很容易地混合，因为Table对象可以和sql表进行方便的互转：

* 可以让SQL查询返回Table对象，进而调用TableAPI ；

* 可以用env.from("sql表名") 引用sql表得到Table对象，进而调用TableAPI ；&#x20;

* 可以用env.createTemporaryView("sql表名",  table对象)，将Table对象注册成sql表，进而用sql

## 2.4  建表示例

### Table&#x20;

### 没有返回

### 纯SQL

* 物理字段  正常写的字段

* 逻辑字段  计算出的字段

* 元数据字段  自动获取的连接器中的元数据信息

# 3 完整入门示例

## 3.1 需求和准备

&#x20;从socket端口读取用户的行为数据，统计每个用户每次会话中各类行为的发生次数，并将结果输出到控制台。有如下json数据通过sockect端口输入：

## **3.2 获取数据流**



## **3.3 Table SQL方式查询**

首先创建  视图/表   from  视图/表

方式1&#x20;

![](images/多易教育-FlinkSQL-image-12.png)

tableEnv.createTable(**"tb\_x"&#x20;**, TableDescriptor.*forConnector*(**""**).build());

方式2  纯sql



## **3.4 Table API 方式查询**

核心点  获取Table对象  &#x20;

1 . 将 字符串table/视图 &#x20;

# 4 表的概念及类别

## **4.1表的标识结构**

每一个表的标识由3部分组成：

* catalog name （常用于标识不同的“源”，比如hive catalog，inner catalog等）

* database name（通常语义中的“库”）

* table name（通常语义中的“表”）



一个FlinkSQL程序在运行时，tableEnvironment通过持有一个map结构来记录所注册的catalog；



## **4.2 表与视图**



<span style="color: inherit; background-color: rgba(222,224,227,0.8)">FlinkSQL中的表，</span> <span style="color: inherit; background-color: rgb(255,233,40)">可以是 virtual的（view 视图，查询的中间结果）</span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">和</span> <span style="color: inherit; background-color: rgb(255,233,40)">regular的（table 常规表，对应的Source源或Sink存储系统），不管是table还是view，在tableAPI中得到的都是Table对象</span>

* table描述了一个物理上的外部数据源，如文件、数据库表、kafka消息topic

* view则基于表创建，代表一个或多个表上的一段计算逻辑，即对数据转换查询（就是对一段查询计划的逻辑封装）



## 4.3 **临时与永久**



* 临时表（视图）： <span style="color: rgb(143,149,158); background-color: inherit">创建时带 temporary 关键字（create temporary view，create temporary table）</span>

* <span style="color: inherit; background-color: rgba(255,246,122,0.8)">永久表（视图）</span>： <span style="color: rgb(143,149,158); background-color: inherit">创建时不带temporary关键字 （create view ，create table ）</span>





* **临时表与永久表的本质区别：schema信息是否被持久化存储**



临时表（视图）特点：

* 表<u>schema只维护在所属flink session运行时内存中；</u>

* 当所属的flink session结束后表信息将不复存在；且该表无法在flink session间共享；



常规表（视图）特点：

* 表<u>schema可记录在外部持久化的元</u> <u><span style="color: inherit; background-color: rgba(255,246,122,0.8)">数据管理器</span></u> <u>中</u>（比如hive的metastore）；

* 当所属flink session结束后，该表信息不会丢失；且在不同flink session中都可访问到该表的信息；



# 5 表定义概览

## **5.1 \[ Table Api ] Table创建概览**

![](images/多易教育-FlinkSQL-image-10.png)

![](images/多易教育-FlinkSQL-image-2.png)



**Table对象获取方式解析：**

* 已注册的表名（catalog\_name.database\_name.object\_name）

* TableDescriptor（表描述器，核心是connector连接器）

* Datastream（底层流）

* 测试数据值

* tb\_name (path)中转换成Table   from("table\_name")

## 5.2 \[ Table Api ] Table创建示例



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> 通过已注册的表名生成Table对象**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> 通过DataStream生成Table对象**

* 自动推断schema（反射手段）



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> 通过tableEnv的fromValues方法获得Table对象（快速测试用）**



//TIMESTAMP(3)

//2022-06-03 13:59:20.200&#x20;

> *TIMESTAMP和TIMESTAMP\_LTZ的区别:*
>
> 相同点：两者都可用来表示 YYYY-MM-DD HH:MM:SS 类型的日期。
>
> 不同点：对于timestamp：它把客户端插入的时间从 当前时区 转化为UTC（世界标准时间）进行存储。查询时，将其又转化为客户端当前时区进行返回。对于datetime:入库的时候数据库是什么时区，取出来就是什么时区。即，flink中的TIMESTAMP不携带时，TIMESTAMP\_LTZ携带时区。
>
> 二者都接受一个小于9的参数: TIMSTAMP\_LTZ(num),TO\_TIMESTAMP(num)  指的是时间的精确度，开发中经常用到TIMESTAMP(3)或者是TIMSTAMP\_LTZ(3)意思是保留三位，实际含义就是精确到毫秒，TIMESTAMP(6)和TIMSTAMP\_LTZ(6)表示微秒，TIMESTAMP(9)和TIMSTAMP\_LTZ(9)表示纳秒。  一般用TIMESTAMP(3)或者是TIMSTAMP\_LTZ(3)就够了。



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> 通过Table上调用查询api，生成新的Table对象（本质上就是view）**



## **5.3 \[ Table Sql ] 表创建概览**

![](images/多易教育-FlinkSQL-image-3.png)

![](images/多易教育-FlinkSQL-image-26.png)



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 注册sql表（视图）方式解析</span>**

* 从已存在的datastream注册

* 从已存在的Table对象注册

* 从TableDescriptor（连接器）注册

* 执行Sql的DDL语句来注册



## **5.4 \[ Table Sql ] 表创建示例**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 将已存在的Table对象注册成sql视图</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 将datastream注册成sql视图</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 通过connector注册sql表</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 通过sql DDL语句定义sql表</span>**



# 6 catalog详解

## 6.1 **什么是catalog**

**<span style="color: inherit; background-color: rgb(255,233,40)">一句话： catalog就是一个元数据空间，简单说就是记录、获取元数据（表定义信息）的实体；</span>**&#x66;linksql在运行时，可以拥有多个catalog，它们由catalogManager模块来注册、管理；



CatalogManager中可以注册多个元数据空间：

**<span style="color: rgb(143,149,158); background-color: rgb(247,105,100)"> 1 </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">环境创建之初，就会初始化一个默认的元数据空间</span>

* 空间名称： default\_catalog

* 空间实现类： GenericInMemoryCatalog



![](images/多易教育-FlinkSQL-image-25.png)

导入依赖 :&#x20;

添加配置文件   conf/hive-site.xml

![](images/多易教育-FlinkSQL-image-24.png)



![](images/多易教育-FlinkSQL-image-23.png)

**<span style="color: rgb(143,149,158); background-color: rgb(247,105,100)"> 2 </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 使用</span>**

**<span style="color: rgb(143,149,158); background-color: rgb(247,105,100)"> 3 </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 去hive中查看</span>**

![](images/多易教育-FlinkSQL-image-28.png)

**<span style="color: rgb(143,149,158); background-color: rgb(247,105,100)"> 4 </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 测试   再写一个类</span>**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)"> 注意:  在hive中只是存储flink中的元数据而已 , 不会在hive中对表进行任何操作! </span>

## **6.2 深入测试catalog**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 通过源码和测试代码，深入理解catalog</span>**



<span style="color: inherit; background-color: rgba(222,224,227,0.8)">可以在上述代码运行前，设置debug断点，然后就可以清晰看到catalogManager中的各个元数据空间及临时表空间的情况</span>



![](images/多易教育-FlinkSQL-image-29.png)



## 6.3 **临时表与永久表的底层差异**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">结论1：如果选择hive元数据空间来创建表、视图，则</span>

* 永久表（视图）的元信息，都会被写入hive的元数据管理器中，从而可以实现永久存在

* 临时表（视图）的元信息，并不会写入hive的元数据管理其中，而是放在catalogManager的一个temporaryTables的内存hashmap中记录

* 临时表空间中的表名（全名）如果与hive空间中的表名相同，则查询时会优先选择临时表空间的表



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">结论2：如果选择GenericInMemoryCatalog元数据空间来创建表、视图，则</span>

* 永久表（视图）的元信息，都会被写入GenericInMemoryCatalog的元数据管理器中（内存中）

* 临时表（视图）的元信息，放在catalogManager的一个temporaryTables的内存hashmap中记录

* 无论永久还是临时，当flink的运行session结束后，所创建的表（永久、临时）都将不复存在



## 6.4 如何理解hive catalog

<span style="color: inherit; background-color: rgb(255,233,40)">flinksql利用hive catalog来建表（查询、修改、删除表），本质上只是利用了hive的metastore服务；</span>更具体来说，flinksql只是把flinksql的表定义信息，按照hive元数据的形式，托管到hive的metastore中而已！

<span style="color: inherit; background-color: rgb(255,233,40)">当然，hive中也能看到这些托管的表信息，但是，并不能利用它底层的mapreduce或者spark引擎来查询这些表；</span>因为mapreduce或者spark引擎，并不能理解flinksql表定义中的信息，也无法为这些定义信息提供相应的组件去读取数据（比如，mr或者spark就没有flinksql中的各种connector组件）



# **7 表定义详解**

## 7.1 定义表的核心要素

定义表需要指定表的描述信息，即schema信息，schema信息有如下重要的核心要素。



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 定义表时所需的核心要素</span>**

* **表名 （**&#x63;atalog\_name.database\_name.object\_nam&#x65;**）**

* **TableDescriptor**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> TableDescriptor核心要素</span>**

* <span style="color: rgb(216,57,49); background-color: rgb(255,233,40)">Connector 连接器   kafks   jdbc    filesystem</span>

* <span style="color: rgb(216,57,49); background-color: rgb(255,233,40)">Format 数据格式   csv  json  orc </span>

* <span style="color: rgb(216,57,49); background-color: rgb(255,233,40)">Schema 表结构（字段）</span>

&#x20;   &#x20;

* <span style="color: rgb(216,57,49); background-color: rgb(255,233,40)">Option 连接器参数</span>



## 7.2 schema字段定义详解

### **7.2.1 physical column**

**physical column为物理字段**：<span style="color: inherit; background-color: rgb(255,233,40)">源自于“外部存储”系统本身schema中的字段：</span>

如kafka消息的key、value（json格式）中的字段；

mysql表中的字段；hive表中的字段；parquet文件中的字段……



### **7.2.2 computed column**

**computed column为表达式字段（逻辑字段）**：<span style="color: inherit; background-color: rgb(255,233,40)">在物理字段上施加一个sql表达式，并将表达式结果定</span>义为一个字段。



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> TableApi中的定义方式</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> Sql DDL中的定义方式</span>**



### 7.2.3 metadata column



**metadata column为元数据字段**：<span style="color: inherit; background-color: rgb(255,233,40)">来源于connector从外部存储系统中获取到的“外部系统元信息”</span>

比如kafka中支持的元数据有

![](images/多易教育-FlinkSQL-image-27.png)

&#x20;

比如，kafka的消息，通常意义上的数据内容是在record的key和value中的，而实质上（底层角度来看），kafka中的每一条record，不光带了key和value数据内容，还带了这条record所属的topic，所属的partition，所在的offset，以及record的timetamp和timestamp类型等“元信息”，<span style="color: rgb(216,57,49); background-color: rgb(255,233,40)">而flink的connector可以获取并暴露这些元信息，并允许用户将这些信息定义成flinksql表中的字段</span> <span style="color: rgb(216,57,49); background-color: inherit">；</span>



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> TableApi中的定义方式</span>**



**<span style="color: rgb(216,57,49); background-color: rgb(247,105,100)"> </span> <span style="color: rgb(216,57,49); background-color: rgba(222,224,227,0.8)"> Sql DDL中的定义方式(完整示例) </span>**

### **7.2.4 主键约束**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 单字段主键约束语法</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 多字段主键约束语法</span>**



### **7.2.5 表字段定义完整实例**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> sql的DDL方式</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> Api方式</span>**

## 7.3 **format概述&#x20;**



connector连接器在对接外部存储时，根据外部存储中的数据格式不同，需要用到不同的format组件；

<span style="color: inherit; background-color: rgb(255,233,40)">format组件的作用就是：告诉连接器，如何解析外部存储中的数据及映射到表schema；</span>

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> format组件的使用要点</span>**

* 导入format组件的jar包依赖

* 指定format组件的名称

* 设置format组件所需的参数（不同format组件有不同的参数配置需求）



![](images/多易教育-FlinkSQL-image-19.png)

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  flinksql目前支持的format如下</span>**

![](images/多易教育-FlinkSQL-image-22.png)

### 7.3.1 **json format 详解**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  所需依赖</span>**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  可用参数</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  数据类型映射</span>**





**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  基本使用</span>**



假设kafka或文件中有如下数据：

映射成flinksql表



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 复杂json格式解析（嵌套对象） </span>**



* 有如下嵌套json



* 映射成flinksql表



* 查询



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  复杂json格式解析（嵌套数组，数组内又嵌套对象）</span>**

有如下嵌套json

映射成flinksql表



* 查询



### 7.3.2 **csv format 详解**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  所需依赖</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  可用参数   </span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 代码示例 </span>**





## 7.4 FlinkSQL的工具类封装

* 将SQL写入到文件中



* 工具类封装

* 主程序



## 7.5 **watermark与时间属性详解**

时间属性定义，主要是用于各类基于时间的运算操作（如基于时间窗口的查询计算）

处理时间不能分配水位线

### **7.5.1 eventTime与waterMark定义**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> Table Api中的定义方式</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> Sql DDL中的定义方式</span>**

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">核心要点：</span>

* 需要一个<span style="color: inherit; background-color: rgba(183,237,177,0.8)">timestamp</span>(3)类型字段（可以是物理字段，也可以是表达式字段，也可以是元数据字段）

* 需要用一个watermarkExpression来指定watermark策略（有2种表达式）



### 7.5.2 表与流之间waterMark传承



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 流转表时</span>**

流转表的过程中，无论“源流”是否存在watermark，<span style="color: rgb(216,57,49); background-color: inherit">都不会自动传递watermark</span>

如需时间运算（如时间窗口等），需要在转换定义中显式声明watermark策略：

先设法定义一个timestamp(3)或者timestamp\_ltz(3)类型的字段（可以来自于数据字段，也可以来自于一个元数据： rowtime&#x20;

然后基于该字段，用watermarkExpression声明watermark策略



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 表转流时</span>**

<u>前提：源表定义了wartermark策略；</u>

**则将表转成流时<span style="color: inherit; background-color: rgba(183,237,177,0.8)">，将会自动传递源表的watermark；</span>**

可通过类似如下代码进行测试：



### 7.5.3 **processing time**



<span style="color: inherit; background-color: rgba(222,224,227,0.8)">定义一个</span> <u><span style="color: inherit; background-color: rgba(222,224,227,0.8)">表达式字段</span></u> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">，并用表达式</span> <span style="color: rgb(216,57,49); background-color: rgba(222,224,227,0.8)"> proctime( ) </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">将其声明为processing time即可；</span>





## 7.6 connector详解

### 7.6.1 connector概述

connector通常是用于对接外部存储建表（源表或目标表）时的映射器、桥接器，<span style="color: inherit; background-color: rgb(255,233,40)">connector本质上是对flink的table source /table sink 算子的封装；</span>



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 连接器使用的核心要素：</span>**

* 导入连接器jar包依赖

* 指定连接器类型名

* 指定连接器所需的参数（不同连接器有不同的参数配置需求）

* 获取连接器所提供的元数据



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 连接器使用的速览示例</span>**

导入依赖

配置参数

* Table API 方式

![](images/多易教育-FlinkSQL-image-21.png)



* Table SQL 方式

![](images/多易教育-FlinkSQL-image-20.png)



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> FlinkSql内置支持的connector</span>**



![](images/多易教育-FlinkSQL-image-18.png)



### 7.6.2 **kafka connector详解**

可以从Kafka中读取数据创建数据流，并且可以将数据流写入到Kafka，<span style="color: inherit; background-color: rgb(255,233,40)">但是写入到Kafka只能是append-only 流</span> （只有 +I 这种changemode）



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 导入依赖</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 建表语句</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  可用的元数据（来自于kafka的record中的metadata）</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  可用的参数（部分展示）</span>**



### **7.6.3 upsert-kafka-connector**

普通的kafkaconnector只支持+I&#x20;

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 基本工作机制</span>**

* 作为source

根据所定义的主键，将读取到的数据转换为 +I/-U/+U 记录，如果读到null，则转换为-D记录；

&#x20;kafka 中假设有如下数据 <span style="color: rgb(46,161,33); background-color: inherit">1</span>,zs,18 <span style="color: rgb(46,161,33); background-color: inherit">1</span>,zs,28

kafka <span style="color: rgb(100,37,208); background-color: inherit">-</span> connector  产生出appendonly流 <span style="color: rgb(216,57,49); background-color: inherit">+</span>I \[1,zs,18] <span style="color: rgb(216,57,49); background-color: inherit">+</span>I \[1,zs,28]

upsert-kafka-connector 产生出upsert模式的changelog流 <span style="color: rgb(216,57,49); background-color: inherit">+</span>I \[1,zs,18] <span style="color: rgb(100,37,208); background-color: inherit">-U</span> \[1,zs,18] <span style="color: rgb(216,57,49); background-color: inherit">+</span>U \[1,zs,28]



* 作为sink

对于 -U/+U/+I 记录， 都以正常的append消息写入kafka；

对于-D 记录，则写入一个null到kafka来表示delete操作；

示例

*--  kafka表  源表   id , name  ,age , city&#x20;*&#xA;*-- table  connector  = kafka  &#x20;*&#xA;*--  select  city , count(1) as cnt   from  tb   group by  city &#x20;*&#xA;*-- kafka表   upsert-kafka*





**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 代码示例</span>**

示例程序:&#x20;

建表语句&#x20;

测试代码

写入的程序：



### 7.6.4 **jdbc connector详解**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  jdbc connector有如下特性</span>**

* 可作为<span style="color: rgb(216,57,49); background-color: inherit">scan source</span> ，底层产生Bounded Stream

* 可作为<u><span style="color: rgb(216,57,49); background-color: inherit">lookup source</span></u>，底层是“事件驱动”式查询

* 可作为 Batch模式的sink

* 可作为 Stream模式下的  append sink和upsert sink



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  所需依赖</span>**



根据所连接的数据库不同，需要相应的jdbc驱动，比如连接mysql



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  建表语句示例</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  幂等写出</span>**

jdbc connector 可以利用目标数据库的特性，实现幂等写出；

幂等写出可以避免在failover发生后的可能产生的数据重复；

&#x20;

<u>实现幂等写出，本身并不需要对jdbc connector 做额外的配置，只需要：</u> <u><span style="color: inherit; background-color: rgb(255,233,40)">指定主键字段</span></u> <u> ，jdbc connector 就会利用目标数据库的upsert语法（如下），来实现幂等写出；</u>



### **7.6.5 filesystem connector**

注意依赖

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  filesystem connector 表特性</span>**

* 可读可写

* 作为source表时，支持持续监视读取目录下新文件，且每个新文件只会被读取一次

* 作为sink表时，支持 多种文件格式、分区、文件滚动、压缩设置等功能



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  参数举例</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">  实例代码</span>**



### **7.6.6 flink-doris-connector**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> flink-doris-connector （用于读写doris）</span>**



# **8 cdc连接器**

## **8.1 cdc的通用概念**

CDC，Change Data Capture,**变更数据获取**的简称，使用CDC我们可以从数据库中获取已提交的更改并将这些更改发送到下游，供下游使用。这些变更可以包括INSERT,DELETE,UPDATE等，

用户可以在以下的场景下使用CDC：

* 使用flink sql进行数据同步,将数据从一个地方同步到其他地方，比如从mysql到doris

* 可以在源数据库上实时的物化一个聚合视图

* 因为只是增量同步，所以可以实时的低延迟的同步数据

市面上有大量类似cdc的工具，知名度最高的如： <span style="color: rgb(36,91,219); background-color: inherit">canal</span>，<span style="color: rgb(36,91,219); background-color: inherit">Debezium</span>

如canal，可以捕获到mysql的binlog，形成cdc日志形式的输出供给下游使用；

## **8.2 flinksql对cdc的支持**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> flinksql底层的设计，就天然支持cdc</span>**

* 在flinksql 中，cdc数据几乎等价于changelog：&#x20;

*&#x20;<span style="color: inherit; background-color: rgba(222,224,227,0.8)">cdc的数据格式，是对变化数据的表达模式；changelog也如是；</span>*

* flinksql对cdc的支持，核心就在对record的rowkind（+I/-U/+U/-D）进行适配；

&#x20;

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> flinksql中操作cdc数据，通过cdc连接器即可</span>**

* 不需要开发者做太多的底层维护操作

* 使用各种cdc connector就可以获得输入的cdc模式数据并转成changelog流（映射成表）

* 对cdc表进行各种sql查询时，flink也已做好了适配

* 并且还可以把计算结果的cdc数据，通过cdc connector输出到目标存储系统

&#x20;

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink的cdc connector，在核心包中是没有集成的，需要额外引入依赖；</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">目前，官方有一个专门的开源项目，提供了若干种常用的cdc-connector；</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">项目地址： </span>
[<u><span style="color: rgb(100,37,208); background-color: rgba(222,224,227,0.8)">ververica/flink-cdc-connectors: CDC Connectors for Apache Flink® (github.com)</span></u>](https://github.com/ververica/flink-cdc-connectors)



## **8.3 mysql-cdc-connector使用**

> 数据源开启binlog功能 当对数据进行修改的时候, 会将变化的信息记录在binlog日志中  ;
>
> flink可以加载binlog中的数据 ,解析出变化的数据 , 计算实时数据结果 ;
>
> **flink可以加载binlog中的数据是在<span style="color: rgb(216,57,49); background-color: inherit">checkpoint</span>的时候读取的binlog文件&#x20;**
>
> <span style="color: rgb(216,57,49); background-color: inherit">所以必须开启checkpoint</span>



1. **mysql binlog配置**

* 修改mysql配置文件， /etc/my.cnf

* 在\[mysqld]节的下面添加如下配置（最简配置）

复杂的配置



* 配置完成后，重启mysql服务

* 查看binlog是否生效





* 导入依赖

* **flink-mysql-cdc代码测试**

# **9 表与流的集成**

## **9.1 changelogStream**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 动态表概念回顾</span>**

如前文第一章所述，flinksql中的表相关概念，是持续输入，持续查询，持续数据的动态概念；很多关系运算，如分组聚合，分组topn，全局topn，表关联等运算查询，在动态表的概念中，其输出结果不是一个简单的“结果记录”不断追加的状态，而是一个需要对“前序”结果进行修正的状态；为了能向下游传递其输出结果的动态信息，flink设计了一种DataStream，叫做changelogStream（改变日志流）；

&#x20;

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 现象观察</span>**

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">有如下测试数据：</span>



* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">执行查询1：求每种事件的发生次数</span>

![](images/多易教育-FlinkSQL-image-17.png)

# **10 表输出详解**

## 10.1 **输出方式**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 利用table对象的api输出</span>**

![](images/多易教育-FlinkSQL-image-15.png)



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 将table对象转成datastream，然后用sink 算子输出</span>**

![](images/多易教育-FlinkSQL-image-16.png)



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 用insert语句输出</span>**

## **10.2 多语句批量执行**



# **11 表查询详解**

## 11.1 **table api 概览**



![](images/多易教育-FlinkSQL-image-31.png)



## **11.2 基本查询**

* select&#x20;

* where 过滤

* group by 聚合

* with 语法

* distinct 去重

* limit

* order by&#x20;



实战案例：有如下数据，是一个游戏公司产生的游戏日志，要求按照游戏ID、游戏ZoneID（区）、统计充值累加金额，在游戏新开区时，某个区的用户比较多，如果直接按照游戏ID、游戏ZoneID进行groupBy，会导致数据倾斜。要解决数据倾斜和写入MySQL过慢导致的背压问题

## **11.3 高阶聚合**



### **11.3.1 高阶聚合方式**

### **11.3.2 语法示例**

* cube



* grouping sets



* rollup



## **11.4 时间窗口TVF（表值函数）**

flink1.13开始，提供了时间窗口聚合计算的TVF语法

* 表值函数的使用约束：

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">1. 在窗口上做</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">分组聚合</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">，必须带上 window_start 和 window_end 作为分组key</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">2. 在窗口上做</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">topN 计算</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)"> ，必须带上window_start 和 window_end 作为 partition的 key.</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">3. 带条件的</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">join</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">，必须包含 2个输入表的window start 和 window end 等值条件.</span>



### 11.4.1 **支持的时间窗口类型**

滚动  滑动  累计窗口 , 窗口的触发取决于时间 , 如果使用事件语义  分配水位线  推进窗口的触发



* 滚动窗口 （Tumble Windows）

tumble(参数1  , 参数2 , 参数3)



* 滑动窗口 （Hop Windows）

tumble(参数1  , 参数2 , 参数3 ,参数4)



* 累计窗口（Cumulate Windows）

cumulate(参数1  , 参数2 , 参数3 ,参数4)



* 会话窗口（Session Windows）&#x20;

**暂不支持！**



### **11.4.2 语法示例**





## **11.5 window 聚合**

按照EventTime划分滚动窗口，将数据聚合后，写入到MySQL中



## **11.6 window topn**

flink目前只支持滚动窗口的TopN



## **11.7 window join**

<span style="color: inherit; background-color: rgb(255,233,40)">将窗口内的数据缓存在窗口中，如果条件(满足)相同，并且在同一个窗口内，就可以join上 ! </span>

注意:  相关联的两张表对应的窗口**都满足**触发条件后, 进行数据关联 ,输出结果 ,清空触发窗口中的缓存数据

## **11.8 regular join**

regular join(常规join)是<span style="color: inherit; background-color: rgba(255,246,122,0.8)">将所有的数据都缓存到状态中，默认是一直缓存</span>，也可以设置TTL，参数如下：

* Innerjoin



* OuterJoin



## **11.9 lookup join**

### **11.9.1 Lookup join的内在原理**

![](images/多易教育-FlinkSQL-image-30.png)

根据商品分类ID，查询MySQL维表关联维度



## 11.10 **interval join**

按照时间范围进行join

* 时间区间条件的可用语法：

* ltime = rtime

* ltime >= rtime AND ltime < rtime + INTERVAL '10' MINUTE

* ltime BETWEEN rtime - INTERVAL '10' SECOND AND rtime + INTERVAL '5' SECOND





## **11.11 temporal join（时态join/版本join）**

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">要义：  </span> <span style="color: inherit; background-color: rgb(255,233,40)">左表的数据永远去</span> <span style="color: inherit; background-color: rgb(255,165,61)">关联右表数据的对应时间上的最新版本</span>



* 创建表orders



* 创建汇率表（典型的versioned 动态表，带时间属性字段）



* 查询语句



* 返回结果



## **11.12 over 窗口聚合**

row\_number( ) over (  )

&#x20;

flinksql中，over聚合时，指定聚合数据区间有两种方式

* 方式1，带时间设定区间

<span style="color: inherit; background-color: rgba(183,237,177,0.8)">RANGE</span> **BETWEEN** <span style="color: rgb(36,91,219); background-color: inherit">INTERVAL</span> <span style="color: rgb(216,57,49); background-color: inherit">&#39;30&#39;</span> **MINUTE** PRECEDING **AND** **CURRENT** **ROW**

&#x20;

* 方式2，按行设定区间

**ROWS** **BETWEEN** <span style="color: rgb(143,149,158); background-color: inherit">10</span> PRECEDING **AND** **CURRENT** **ROW**









# **12 内置函数及自定义函数**



## **12.1 ScalarFunction（UDF）**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">标量函数</span>

特点： 每次只接收一行的数据，输出结果也是1行1列

典型的标量函数如： upper(str), lower(str), abs(salary)

&#x20;

## **12.2 TableFunction （UDTF）**

表生成函数

特点：运行时每接收一行数据（一个或多个字段），能产出多行、多列的结果

典型的如： explode( ) ,  unnest ( )

&#x20;

## **12.3 AggregateFunction （UDAF）**

聚合函数

特点：对输入的数据行（一组）进行持续的聚合，最终对每组数据输出一行（多列）结果

典型的如： sum( )  max( )

&#x20;

## **12.4 TableAggregateFunction**

聚合函数

特点：对输入的数据行（一组）进行持续的聚合，最终对每组数据输出一行或多行（多列）结果

&#x20;







# **13 SqlClient使用**

## **13.1 基本介绍**

sql-client是flink安装包中自带的一个命令行工具，用于快捷方便地进行sql操作

注意： 首先要启动一个flink session集群 (standalone，on yarn)

* 命令核心参数：

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">-f :  指定初始化sql脚本文件</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">-l : 指定要添加的外部jar包所在的文件夹（来加载文件夹中所有的依赖jar）</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">-j : 指定一个jar包文件路径来加载这个jar包依赖</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">-s : 指定要连接的flink session集群</span>

&#x20;

![](images/多易教育-FlinkSQL-image-32.png)



## **13.2 完整示例**

* 需求背景：

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">从kafka中读取一个topic的数据</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">然后统计每5分钟的去重用户数</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">并且，把结果写入mysql</span>



* 操作步骤

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: rgb(143,149,158); background-color: rgb(247,105,100)">1</span> <span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 需要额外的依赖jar包</span>**

* flink-connector-jdbc\_2.12-1.15.2.jar

* flink-csv-1.15.2.jar

* flink-json-1.15.2.jar

* flink-sql-connector-kafka\_2.12-1.15.2.jar

可以把这些jar包直接放在flink安装目录的lib中，当然，也可以放在任意一个自定义的目录

&#x20;

&#x20;

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: rgb(143,149,158); background-color: rgb(247,105,100)">2</span> <span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 启动sql-client</span>**

&#x20;

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: rgb(143,149,158); background-color: rgb(247,105,100)">3</span> <span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 需求开发</span>**

&#x20;

* 建数据源表（kafka连接器表）

* 目标表的创建

* 查询sql开发



# **13 FlinkSql与hive集成**

Flinksql与hive有两个整合角度

角度1：元数据整合

角度2：将flink做为hive的执行引擎

## **13.1 idea中整合hive catalog**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 准备hive配置文件</span>**

准备一个hive-site.xml配置文件（可放在任何本地目录），至少包含如下内容





**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 添加依赖</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 在代码中注册hive catalog</span>**



## **14.2 sql-client中整合hive catalog**

**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 添加依赖</span>**

在flink安装目录中，创建一个文件夹，如extlib ；

放入所需的依赖 ：

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink-connector-hive_2.12-1.15.2.jar  (hive整合所需)</span>

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink-sql-connector-kafka_2.12-1.15.2.jar   (示例中需要用到kafka连接器)</span>

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink-shaded-hadoop-3-uber-3.1.1.7.2.9.0-173-9.0.jar   (与hadoop整合所需)</span>

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink-csv-1.15.2.jar  (支持csv格式所需）</span>

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">flink-json-1.15.2.jar  (支持json格式所需）</span>



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 启动sql-client</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 注册hive catalog</span>**



**<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 查看catalog中的表</span>**
