# 1.Flink的使用场景

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Apache Flink是一个框架和分布式处理引擎，用于对无界和有界数据流进行有状态计算，</span> Flink可以用来做实时计算（流计算），也可以用来做离线计算（批处理），但是目前Flink在实时计算领域应用的比较多！

&#x20;

1.Event-driven Applications【事件驱动应用】

2.Data Analytics Applications【数据分析应用】

3.Data Pipeline Applications【管道式ETL应用】

![](images/一文搞定Flink-image-5.png)



# 2.flink的特点

## 批流统一

Batch 和 Streaming 一个系统流处理和批处理共用一个引擎，Flink 为流处理和批处理应用公用一个通用的引擎。批处理应用可以以一种特殊的流处理应用高效地运行。

![](images/一文搞定Flink-e993f6d40190f8898aa1487b2096803b.jpeg)



## 高吞吐、低延迟、高性能

在spark中，一切都是由批次组成的，离线数据是一个大批次，而实时数据是由一个一个无限的小批次组成的。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Flink支持纯粹的实时计算，即来一条数据处理一条数据</span>，也支持将数据攒到窗口中实现微批次的计算，Flink 的流处理引擎只需要很少配置就能实现高吞吐率和低延迟。



## 支持事件时间概念（Event Time）

大多数窗口计算采用的都是系统时间（Process Time）,也是事件传输到计算框架时，系统主机的当前时间。Flink能够支持基于时间事件时间（Event Time）语义进行窗口计算，也就是时间产生的时间。这种基于时间驱动的机制使得事件即使是乱序到达，流系统也能够计算出精确的结果，保持了时间原本产生的时序性。尽量避免网络传输或硬件系统影响。

![](<images/一文搞定Flink-f682d96baae111df566596a21ef9934d (1).jpeg>)



## &#x20;支持有状态计算

所谓的状态就是流式计算过程中将算子的中间结果数据保存在内存中或者是文件系统中，等下一个时间进入算子后可以从之前的状态中获取中间结果中计算当前的结果，从而无需每次都基于全部的原始数据来统计结果，这种方式极大提升了系统的性能，并降低了计算过程资源的消耗，对于数据量大且运算逻辑非常复杂的流式计算场景，有状态发挥了非常重要的作用。

![](images/一文搞定Flink-image-4.png)



## 支持高度灵活的窗口（Window）操作

在流处理应用中，数据是连续不断的，需要通过窗口的方式对数据进行一定范围的聚合计算，例如统计在过去一分钟内多少用户点击某一网页，在这种情况下，我们必须定义一个窗口，用来收集最近一分钟的数据，并对窗口内的数据进行统计计算。Flink将窗口划分为基于Time,count,Session,以及Data-driven等类型的窗口操作，窗口可以用灵活的触发条件定制化达到对复杂的流传输模式的支持，用户可以定义不同窗口触发机制来满足不同的需求。



![](images/一文搞定Flink-image-3.png)



## 基于轻量级分布式快照（CheckPoint）实现的容错

Flink能够分布式运行在上千个节点上，将一个大型计算任务的流程拆解成小的计算过程，然后将tesk分布到并行节点上进行处理，在执行任务过程中，能够自动发现事件处理过程中的错误而导致数据不一致的问题。比如：节点宕机、网路传输问题，或是由于用户因为升级或修复问题导致计算服务重启等。在这些情况下，通过基于分布式快照技术CheckPoints，将执行过程中的状态信息进行持久化存储，一但任务出现异常停止，Flink就能够从Checkpoint中进行任务的自动恢复，以确保数据在处理过程中的一致性（Exactly-ONCE），对于7\*24小时运行的流式运用，数据源源不断地接入，在一段时间内应用的终止有可能导致数据丢失或者计算结果不准确，例如进行集群版本的升级、停机运维操作等。值得一提的是，Flink通过Save Points技术将任务执行的快照保存在存储介质上，当任务重启的时候可以直接从事保存的Save Points恢复原有的计算状态，使得任务继续按照停机之前的状态运行，Sava Point技术可以让用户更好的管理和运维

![](images/一文搞定Flink-output.png)

## 基于JVM实现独立的内存管理

内存管理是所有计算框架需要重点考虑的部分，尤其对于计算量比较大的计算场景，数据在内存中该如何进行管理显得至关重要，针对内存管理，Flink实现了自身管理内存机制，尽可能减少JVM GC对系统的影响，另外，Flink通过序列化/反序列化方法将所有的数据对象转化为二进制在内存中存储，降低GC带来的性能下降或任务异常的风险，因此Flink较其他分布式处理的框架显得更加稳定，不会因为JVM GC等问题而影响整个应用的运行，Flink在JVM中实现了自己的内存管理，应用可以超出主内存的大小限制，并且承受更少的垃圾收集的开销。

![](images/一文搞定Flink-f198c5abe42640574f2be95df9bd6577.jpeg)



## **<span style="color: rgb(143,149,158); background-color: inherit">带反压的连续流模型</span>**

Flink在运行时有着天然的流控：慢的数据算子节点会通过RPC消息<span style="color: inherit; background-color: rgba(255,246,122,0.8)">逐级向前反压</span>（backpressure）通知前面快的算子，从而实现数据处理的动态平衡。

![](images/一文搞定Flink-bd545e5882355762ae95e970a8b9a96a.jpeg)



# 3.**Flink架构**

![](images/一文搞定Flink-image-1.png)

## **<span style="color: inherit; background-color: rgba(222,224,227,0.8)">各角色主要职责说明</span>**

* Client

Flink 客户端是 F1ink 提供的 CLI 命令行工具，用来提交 Flink 作业到 Flink 集群，在客户端中负责 StreamGraph (流图)和 Job Graph (作业图)的构建。

* JobManager

JobManager根据并行度将Flink客户端提交的Flink应用分解为子任务，从资源管理器 ResourceManager 申请所需的计算资源，资源具备之后，开始分发任务到TaskManager 执行 Task，并负责应用容错，跟踪作业的执行状态，发现异常则恢复作业等。

* TaskManager

TaskManager 接收 JobManage 分发的子任务，根据自身的资源情况 管理子任务的启动、 停止、销毁、异常恢复等生命周期阶段。Flink 程序中必须有一个TaskManager。



## **&#x20;OnYarn 的三种模式**



Flink程序可以运行为以下3种模式:

* Application Mode【生产中建议使用的模式】

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">每个job独享一个集群，job退出集群则退出，用户类的main方法在集群上运行</span>



* ~~Per-Job Mode~~

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">每个job独享一个集群，job退出集群则退出，用户类的main方法在client端运行；</span>（大job，运行时长很长，比较合适；因为每起一个job，都要去向yarn申请容器启动jm,tm，比较耗时）



* Yarn Session Mode.

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">多个job共享同一个集群&lt;jobmanager/taskmanager&gt;、job退出集群也不会退出，用户类的main方法在client端运行；</span>（需要频繁提交大量小job的场景比较适用；因为每次提交一个新job的时候，不需要去向yarn注册应用）



> 上述3种模式的区别点在:
>
> 集群的生命周期和资源的隔离保证
>
> 用户类的main方法是运行在client端，还是在集群端



![](images/一文搞定Flink-image.png)

# 4.Flink的核心要点

## Task和SubTask的区别

在Flink中，Task和SubTask的概念模糊不清，经常被混淆；<span style="color: inherit; background-color: rgba(255,246,122,0.8)">SubTask是Flink中最小的任务执行单元，即是Flink创建的类的实例对象，里面封装着描述信息和运算逻辑。一个Task中可以有一到多个SubTask，同一个Task中的多个SubTask的运算逻辑相同，仅是计算的数据不同而已。</span>

下面是一个简单的实时程序，执行环境的并行度设置为2。先从Kafka中读取数据，数据的格式为String类型的单词，然后调用map将单词和1组合，再调用keyBy进行分区，keyBy后再将次数进行sum，然后调用print sink，并且设置sink的并行度为1。



程序运行后，查询web管理界面，该job的执行计划图如下：

![](images/一文搞定Flink-QQ20221121-141225@2x.png)

可以看出，该job有3个Task，5个SubTask；第一个Task和第二个Task中间是一个调用了keyBy进行了分区，第二个和第三个Task是因为并行度发送变化（最后Sink算子对应的DataStream并行度这设置为1了）。



<span style="color: inherit; background-color: rgba(255,246,122,0.8)">从宏观的角度来看，多个Task连接在一起，形成了DataFlow Graph（数据流图）</span>，从微观的角度，即将Task展开，每个Task中又可以有一到多个SubTask，一个SubTask对应一个线程。



## **算子链**

DataStream经过一系列的Transformation转换后，最后调用Sink，形成一个完整的DataFlow Graph，这个任务在生成JobGraph阶段，会将代码中相邻的两个或两个以上的算子<span style="color: inherit; background-color: rgba(255,246,122,0.8)">优化</span>成一个算子链（Operator Chains）以放到一个subtask（一个subtask对应一个线程）中执行，<span style="color: rgb(31,35,41); background-color: rgb(247,105,100)">这样以减少线程之间的切换和数据缓冲的开销，从而提高整体的吞吐量和降低延迟。</span>



![](images/一文搞定Flink-QQ20221121-135325@2x.png)

##

## Task槽和资源

每个 worker（TaskManager）都是一个 JVM 进程，可以在单独的线程中执行一个或多个 subtask。为了控制一个 TaskManager 中接受多少个 subtask，就有了所谓的 **task slots**（一个TaskManager中至少要有一个slot）。

**<span style="color: inherit; background-color: rgba(255,246,122,0.8)">每个 task slot 代表 TaskManager 中资源的固定子集</span>**。例如，一个TaskManager中 有3 个 slot  ，会将其托管内存平均分配给每个 slot。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">分配资源意味着当前job的 对应的subtask 不会与其他job的 对应的subtask 竞争托管内存</span>，而是具有一定数量的保留托管内存。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">注意slot计算对托管内存进行隔离，并没有对 CPU进行隔离</span>。

通过调整 task slot 的数量，用户可以定义 subtask 如何互相隔离。每个 TaskManager 有一个 slot，这意味着一个slot中的多个subtask 都在单独的 JVM 中运行（例如，可以在单独的容器中启动）。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">具有多个 slot 意味着更多 subtask 共享同一 JVM</span>。同一 JVM 中的 subtask 共享 TCP 连接（通过多路复用）和心跳信息。它们还可以共享数据集和数据结构(static)，从而减少了每个subtask 的开销。



默认情况下，<span style="color: inherit; background-color: rgb(98,210,86)">Flink 允许来自于同一job，不同Task的subtask 共享同一个 slot。</span>结果就是一个 slot 运行多个subtask，形成一个持有整个作业管道（pipeline）。允许 *slot 共享*有两个主要优点：

* Flink 集群所需的 task slot 和作业中使用的最大并行度恰好一样。无需计算程序总共包含多少个 task（具有不同并行度）。

* 容易获得更好的资源利用。如果没有 slot 共享，非密集 subtask（*source/map()*）将阻塞和密集型 subtask（*window*） 一样多的资源。通过 slot 共享，我们示例中的基本并行度从 2 增加到 6，可以充分利用分配的资源，同时确保繁重的 subtask 在 TaskManager 之间公平分配。



<span style="color: inherit; background-color: rgb(98,210,86)">下面的图是没有共享资源槽</span>

![](images/一文搞定Flink-QQ20221121-140852@2x.png)

例如上面的程序，如果没有共享资源槽，只能运行2并行，但是允许共享资源槽，可以运行6个并行，<span style="color: inherit; background-color: rgb(98,210,86)">提高了资源利用率并增大了吞吐量</span>。



<span style="color: inherit; background-color: rgb(98,210,86)">下面的图使用共享资源槽的情况（默认的）</span>

![](images/一文搞定Flink-QQ20221121-195526@2x.png)



# 5.DataStream编程

在分布式计算框架中，需要处理分散在多台机器上的海量数据，对于大数据开发人员面临最大的挑战就是代码的编写、部署、调度、容错等。<span style="color: rgb(100,37,208); background-color: inherit">Flink在实时计算方面，提供流一个抽象的集即DataStream，开发者只要调用统一的编程API，传入具体的计算逻辑，不必太多关心底层的细节，就可以完成各种复杂的计算了，并且可以实现快速部署、资源调度、任务容错等，大大的提高了开发效率</span>。

> DataStream是Flink流式计算编程的抽象数据集（与Spark的RDD是类似的），抽象数据集里面不装要真正要计算的数据，而是记录一些描述信息，例如从哪里读取数据，掉了用了什么方法，传入了什么计算逻辑，通过调用DataStreamTransformation(s)和Sink后，构建成执行计划图DataFlow Graph（类似Spark的DAG），然后生成Task提交到集群中执行真正的计算逻辑。



在开发Flink实时计算程序，首先学要创建StreamExecutionEnvironment，然后调用相应的Source算子创建原始的DataStream，再调用零到多次Transformation（转换算子），每调用一次Transformation都会生成一个新的DataStream，最后调用Sink，我们写的程序就形成一个Data Flow Graph（数据流图），然后提交给JobManager，经过优化后生成包含有具体计算逻辑的Task实例，然后调度到TaskManager的slot中开始计算。



## 编程模型简介



![](images/一文搞定Flink-image-2.png)



Flink提供了不同级别的编程抽象，通过调用抽象的数据集调用算子构建DataFlow就可以实现对分布式的数据进行流式计算和离线计算，**DataSet是批处理的抽象数据集，DataStream是流式计算的抽象数据集**，他们的方法都分别&#x4E3A;**<span style="color: rgb(216,57,49); background-color: inherit">Source、Transformation、Sink</span>**

&#x20;

* **Source**主要负责数据的读取

* **Transformation**主要负责对数据的转换操作

* **Sink**负责最终计算好的结果数据输出。



## 重要的Transformation算子

Transformation翻译成中文意为转换，是将一个或多个DataStream调用某个转换算子，生成一个新的DataStream，原来的DataStream不变。Flink程序可以将多个Transformation生成的DataStream组合成一个复杂的DataFlow拓扑。这里所提到的转换算子，其实就是DataStream的转换方法，调用转换算子后，一定会生成一个新的DataStream。



* **map映射（DataStream → DataStream）**

该方法是将一个DataStream调用map方法返回一个新的DataStream。本质是将该DataStream中对应的每一条数据依次迭代出来，应用map方法传入的计算逻辑，返回一个新的DataStream。原来的DataStream中对应的每一条数据，与新生成的DataStream中数据是一一对应的，也可以说是存在着映射关系的。



* **keyBy按key分区（DataStream → KeyedStream）**

该方法是将一个DataStream调用keyBy方法返回一个新的KeyedStream，本质上是将该DataStream中的每一条按照指定<span style="color: inherit; background-color: rgba(255,246,122,0.8)">的key进行分区</span>，返回一个新的KeyedStream。key相同的数据一定会分到同一个区内，一个区的数据一定是在一个TaskManager的一个subtask中，但是一个subtask中可以有零到多个不同的key的数据。在分布式计算中，如果key相同的数据分散在不同的机器中，需要通过网络将key相同的数据传输到同一台机器的同一个组内，这就是所谓的shuffle。一个单词到底会被shuffle到哪一个组，跟key的hashcode值和该任务的并行度相关，



* **reduce归约（KeyedStream → DataStream）**

该方法是将一个KeyedStream调用reduce方法返回一个新的DataStream，本质上是将该KeyedStream同一个分区一个组内持续输入的数据按照传入的聚合逻辑进行<span style="color: rgb(31,35,41); background-color: rgb(255,233,40)">实时滚动</span>地聚合。



## 分区算子

与其他的流式计算框架一样，Flink DataStream同样提供了一些底层的算子来精准控制数据在重分区时数据流向下游具体哪个分区，这些方法都属于Transformation转换算子。本质是决定数据进入具体哪一个或哪几个Channel（通道），每个Channel都有自己的Index，并与下游的subtask存在对应关系。这些用来控制数据流向的Transformation算子也称为物理分区方法。这些物理分区方法内部都有对应的流分区器，会在原理深入章节再详细讲解这些流分区器的底层实现。



### 1. **rebalance轮询**

DataStream调用rebalance方法后会生成一个新的DataStream，该方法的功能是将上游产生的数据轮询地发送给下游的subtask，内部使用的是RebalancePartitioner，这个分区器实现了一个轮询分区算法，数据经过该分区器的算法计算后，会返回一个Channel Index，然后将数据放入到对应Index的Chennel中，下游的subtask会通过网络到对应的Channel中拉取数据。





### 2. **shuffle随机**

DataStream调用shuffle方法后会生成一个新的DataStream，该方法的功能是将上游产生的数据随机地发送给下游的subtask，内部使用的是ShufflePartitioner，数据经过该分区器的算法计算后，会随机返回一个Channel Index。



&#x20;

提示：rebalance和shuffle是有区别的，shuffle是将上游的数据随机发给下游的subtask，而rebalance将上游的数据以循环方式依次发给下游的subtask。由于shuffle随机的，数据可能会分布不均。

&#x20;

### 3. **rescale在一个TashManager中轮询**

与rebalance相比，减少了网络传输，同时可以在同一个TaskManager进行轮询，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">可以一定程度上缓解数据倾斜的问题，极端情况也有数据倾斜</span>。

重缩放分区和轮询分区非常类似，当调用resacle()方法时，底层调用的其实就是Round-Robin算法进行轮询。不同的是，rescale重缩放分区会将上游不同的数据来源分为不同的“团体”，在下游的同一团体内，对所有slot进行轮询分发。

从底层实现上看，rebalance 和 rescale 的根本区别在于任务之间的连接机制不同。rebalance 将会针对所有上游任务（发送数据方）和所有下游任务（接收数据方）之间建立通信通道，这是一个笛卡尔积的关系；而 rescale 仅仅针对每一个任务和下游对应的部分任务之间建立通信通道，节省了很多资源。





### 4. **forward直传**

上下游并行度一致，调用了一下特殊的方法，union，startNewChain、disableChaining端口算子链，那么就会分区策略为直传，即上游的0号分区的subtask将数据传输给下游的0号分区的subtask



下面的图为union时，两个流并行度不一致的情况



![](images/一文搞定Flink-QQ20221125-103609@2x.png)



下面是调用disableChaining是对应的执行计划图

![](images/一文搞定Flink-QQ20221125-104602@2x.png)

### 5. **broadcast广播**

DataStream调用broadcast方法后会生成一个新的DataStream，该方法的功能是将上游产生的数据发送给下游的所有的subtask，内部使用的是BroadcastPartitioner，数据经过该分区器的计算后，会随机返下游所有的Channel Index。

### 6. **partitionCustom自定义分区规则**

DataStream的API运行用户根据自己的需求，自定义分区规则。这个方法就是partitionCustom，调用该方法会返回一个新的DataStream。

下面的例子是根据输入的字符串，将key为java的分配到1号分区，key为scala的分配到2号分区，key为其他的值分配到0号分区。首先要定义一个类，实现Partitioner接口，指定的泛型为输入key的类型，并重写partition方法。partition方法的第一个参数为输入数据的key，第二个位下游DataStream的并行度的数量。在该方法中，可以使用if判断或switch等逻辑，根据传入的参数计算返回一个int类型的分区编号。

接下来在调用DataStream的partitionCustom，将自定义分区器类的实例作为第一个参数传入到到该方法中，第二个参数为key对应的下标或名称。

### 7. keyBy

按照key的hashcode值进行分区，前面已经讲过了，不再赘述了。

### 8. 全局分区

全局分区器：默认会选择索引为0的channel进行输出



# 6.Flink的窗口

流式计算是一种被设计用于处理无限数据集的数据计算引擎，所谓无限数据集是指一种源源不断的数据流抽象成的集合。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">而Window就是一种将无限数据集按照一定的规则（按照时间或条数）切分成多个有限数据集并对每一个有限数据集分别进行处理的手段。</span>Window本质上是将数据流按照一定的规则，逻辑地切分成很多个有限大小的“bucket”桶，这样就可以对每一个在“桶里面”的有限的数据依次地进行计算了。

流式计算引擎的特点是每输入一条数据就立即处理，延迟低。然而在一些场景下偏偏希望将数据先攒成一个个小批次，然后对每一个小批次再进行运算。例如用FlinkDataStream API将数据进行实时的聚合后，再将结果实时的写入到数据库，每输入一条数据都会输出一个聚合后的结果，如果数据量非常大，那么对外部的数据库的写入压力就比较大。而划分成Window，即将每一个Window中的有限的数据先聚合成一条或几条，再写入到数据库中，虽然延迟变高了，但是对数据库的写入压力变小了。Window操作可以认为是微批次准实时的计算，这样Flink DataStream API 既可以实现高效的实时运算，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">又可以实现微批次的准实时运算，让Flink在实时计算领域更加强大和灵活</span>。



## 窗口的分类

&#x20;窗口总体分为两种类型：CountWindow和TimeWindow



* CountWindow：按照数据的条数划分窗口

* TimeWindow：按照时间划分窗口



窗口是否keyBy，分为KeyedWindow和NonKeyedWindow

* KeyedWindow：先keyBy，然后在划分窗口，key相同的数据一定会进入到同一个分区内，Window和WindowOperator所在的DataStream<span style="color: inherit; background-color: rgba(255,246,122,0.8)">可以是多个并行</span>，

* NonKeyedWindow：不keyBy，直接划分Window，Window和WindowOperator所在的DataStream<span style="color: inherit; background-color: rgba(255,246,122,0.8)">只有一个并行</span>，即所有的数据都被分到了一个分区内，生成环境很少使用，因为会出现性能瓶颈。





![](images/一文搞定Flink-image-9.png)



时间窗口又分为滚动窗口、滑动窗口、会话窗口



* **滚动窗口**

滚动窗口是按照时间划分的窗口，其Assinger会将输入的每一条数据按照时间分配到固定长度的窗口内，并且<span style="color: inherit; background-color: rgba(255,246,122,0.8)">按照这个固定的时间进行滚动，窗口和窗口之间没有数据重叠</span>。

![](images/一文搞定Flink-QQ20221118-130558@2x.png)

* **滑动窗口**

滑动窗口是按照时间划分的窗口，其Assinger会将输入的每一条数据按照时间分配到固定长度的窗口内，并且还可以指定一个额外的滑动参数用来指定窗口滑动的频率（也叫滑动步长），<span style="color: inherit; background-color: rgba(255,246,122,0.8)">因此当滑动步长小于窗口的长度时，窗口和窗口之间有数据重叠</span>。

![](images/一文搞定Flink-QQ20221118-131705@2x.png)



* **会话窗口**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">会话窗口是按照时间间隔划分窗口的，当超过指定的时间间隔，就会划分一个新的窗口</span>。会话窗口没有固定的起始时间和结束时间，窗口中的数据也不会重叠。会话窗口可以指定一个固定的时间间隔，也可以根据数据中的信息传入一个函数计算出一个动态变化的时间间隔。

![](images/一文搞定Flink-QQ20221118-180301@2x.png)



## WaterMark

在流式计算中，从数据产生，到被Source接收，再到被Window Operator处理，中间是需要一些时间，也是存在微小的延迟的。虽然大部分情况下，数据都是按照事件产生时间的先后顺序被Operator处理的，但是也不排除由于网络延迟、背压阻塞等特殊原因，导致数据是乱序的，即Flink接收到数据在被Window Operator处理时先后顺序并不是严格按照事件的Event Time顺序排列的。



那么此时出现一个问题，一旦数据出现乱序，如果只根据Event Time决定Window何时形成并触发计算，那么就不能保证数据是否全部到齐，但是又不能无限期的等下去，此时必须要有一种机制来保证在一个特定的时间后，必须触发Window将对应的数据进行计算，这个特殊的机制，就是Watermark。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Watermark是一种衡量Event Time进展的机制</span>，就好比是水库的水位线一样，当水位达到了警戒线时，就要采取必要的措施了。Watermark机制与Window结合就可以让窗口延迟触发，从而实现正确的处理乱序事件，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Watermark也可以理解为分布式的窗口按照EventTime统一触发一种机制(信号)，并且允许数据乱序延迟，保证属于同一个EventTime类型窗口的数据被运算（如果数据迟到的时间，大于允许的延迟时间，数据会被丢弃，后面可以使用侧流数据在捞回来）。</span>



<span style="color: inherit; background-color: rgb(98,210,86)">watermark解决了两个问题：</span>

<span style="color: inherit; background-color: rgb(98,210,86)">1.EventTime数据乱序延迟问题</span>

<span style="color: inherit; background-color: rgb(98,210,86)">2.分布式窗口统一触发标准</span>





# 8.Flink的容错



## 有状态计算

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">在分布式实时计算领域，其中最复杂的一个问题就是任务的容错，即任务在任何情况下出现错误时，都可以保证最终的结果是正确的</span>。Flink为了保证计算任务可以容错，<span style="color: inherit; background-color: rgb(98,210,86)">使用了有状态计算这种机制，这也是Flink中最为重要的一个特征</span>。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">所谓的有状态计算就是指程序在计算过程中，会产生一些中间结果，</span>并提供给后续的计算使用。这些中间结果可以保存在内存中，也可以保存到外部的存储系统中。如果将中间结果仅保存到内存中，任务失败内存中的数据就会丢失，任务重启后需要从头开始读取数据，并重新计算，这种方式可能会造成大量的重复计算，浪费大量的计算资源，任务的延迟会变得很高；另外一种方式就是将程序在计算过程中产生的中间结果不但在内存中维护，同时定期将内存中的中间结果保存的一个<span style="color: inherit; background-color: rgba(255,246,122,0.8)">高可用的存储系统中做检查点（checkpoint）</span>，如果程序在出现错误，任务重启并可以从最近一次成功的检查点恢复中间结果并重新加载到内存，然后继续进行计算，这样就可以保证计算结果是完全正确。这种方式虽然需要额外花费一些时间和资源做检查点，但综合比较后，后者更高效，延迟更低。

## 什么是状态

Flink实时程序在计算过程中，为了保证任务出现异常可以容错，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">要将计算的中间结果在内存中维护并定期存储到相应的存储系统里，这些中间数据就叫做state（状态）</span>。

State可以是多种类型的，默认是保存在JobManager的内存中，也可以保存到TaskManager本地文件系统或HDFS这样的分布式文件系统。



![](images/一文搞定Flink-image-8.png)

## **什么是 StateBackEnd**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">用来保存State的存储后端就叫做StateBackEnd</span>，默认是保存在JobManager的内存中，也可以保存的本地文件系统或HDFS这样的分布式文件系统、或RocksDB数据库中

## &#x20;什么是 Checkpointing

Flink实时计算为了容错，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">可以将中间数据定期保存到起来，这种定期触发保存中间结果的机制叫CheckPointing。</span>CheckPointing是周期执行的。具体的过程是JobManager定期的向TaskManager中的SubTask发送RPC消息，SubTask将其计算的State保存到StateBackEnd中，并且向JobManager相应Checkpoint是否成功。如果程序出现异常或重启，TaskManager中的SubTask可以从上一次成功的CheckPointing的State恢复 。

![](images/一文搞定Flink-output-1.png)

主要的步骤：

1.jobManager中的<span style="color: inherit; background-color: rgba(78,131,253,0.55)">CheckpointCoordinator</span>定期会向对应的TaskManager发送RPC请求，即通知TaskManager中的subtask要保存状态了，这个过程叫做TriggerCheckpoint  !(保存状态)

2.TaskManager中的subtask将接收到JobManager发送过来的情况后，会将当前自己的状态持久化到StateBackend中，即将状态发送并写入到StataBackend中，这个过程叫snapshot state !

3.TaskManager中的subtask将状态成功写入到StateBackend中后，会向JobManager发送RPC请求，通知JobManger，当前这个subtask状态保存成功了 !

4.JobManager接收到当前job所有subtask成功完成快照的应答后，这次Checkpoint就成功了，并且会向实现了CheckpointListener接口的subtask发送notifyCheckpointCompleted消息，从而让每一个subtask知道整个checkpoint完成了，并且可以在该方法中完成一些逻辑 !



# 9.状态编程

## 状态的作用

Flink实时程序在计算过程中，为了保证任务出现异常可以容错，要将计算的中间结果在内存中维护并定期存储到相应的存储系统里，这些中间数据就叫做state（状态）。

## 状态的种类

Flink中有两种基本的状态：<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Keyed State 和 Operator State。</span>例如Flink实时WordCount程序中，数据源源不断的被写入到Kafka消息中间件中，FlinkKafkaConsumer（Source）会从Kafka中消费数据，经过计算将结果输出。为了可以容错，就必须将该程序运行中的状态保存起来。那么这个WordCount程序中都记录哪些状态呢？我们可以很容易的想到，调用keyBy算子将数据按照单词分组后，再调用了sum算子进行聚合计算，在这个sum算子中就保存了各个单词累加的中间结果，一种key对应一个中间结果，这些中间结果，即各个单词对应的次数就是状态，其实这就是Keyed State。除此之外，为了任务出现错误重启后，不重复读取Kafka中的数据，还需要记录Kafka的偏移量。假设从Kafka读取数据的那个topic分区数量为4，运行WordCount程序时指定的并行度也是4，那么FlinkKafkaConsumer（Source）会有4个subtask，一个subtask消费一个Kafka分区，那么一个subtask会记录一个Kafka分区的偏移量，这些偏移量也是状态，其实这就是OperatorState。Flink会定期将这些状态保存到对应的状态存储系统中做检查点，如果任务出现异常重启，可以从状态存储系统中恢复上一次成功做检测点的各个单词的次数了和Kafka各个分区的偏移量。每个有状态的subtask都会从State Backend的快照中读取属于自己的状态数据并重新加载到内存，继续计算就可以了。



## KeyedState

Keyed State与key相关，也叫键控State，仅可以在KeyedStream的算子的Function中使用，由于key相同的数据经过调用keyBy算子后，数据一定会进入到同一个subtask的同一个组内，但是一个subtask中可以有零到多个不同的组，每一个组的数据都是相互独立的，一个subtask就是一个分区（或者叫算子的一个并发），即一个分区中可以有零到多个不同key的组。Keyed State也可以看作一个分区内共享的Operator State，而且每种key仅出现在一个分区内。一个分区中（或者说subtask）可以有多种key，在一个分区中的多个key叫做Key Group。Keyed State会按照Key Group的形式进行管理，即一个Key Group对应一个Keyed State实例，Key Group的数量等于Job的最大并发数，也等于keyed operator对应的subtask的数量。在执行过程中，每个keyed operator会对应到一个或多个Key Group。

总结：我们可以将Keyed State认为是类似HashMap的结果，HashMap的key就是当前数据的key，HashMap的value可以是多种类型的。每个subtask（或者分区）中都有自己的一个HashMap成员变量。一个HashMap中可以存储很多的key-value数据，一个key-value就是一个组，多个key-value就是一个Key Group，所以这个HashMap可以认为是一个Key Group。那么Keyed State就相当于一个subtask中的一个HashMap实例，只不过HashMap不能容错，而Keyed State可以容错而已。

Flink支持多种类型的Keyed State，可以根据实际情况选择不同类型的Keyed State存储不同类型的数据。

### ValueState

* <span style="color: rgb(36,91,219); background-color: inherit">ValueState&lt;T&gt;</span>：将当前key与一个单值的状态数据进行绑定，是最简单的状态了。需要在使用之前（通常是在open方法中）先调用RuntimeContext的getState(ValueStateDescriptor\<T>)方法获取此状态。在getState方法中传入一个已经定义的状态描述器ValueStateDescriptor，用于指定状态的名称和存储状态数据的类型。ValueState可以通过update方法更新状态值，通过value()方法获取状态值。



在HeapValueState的value方法中，调用了StateTable的get方法，在StateTable的get方法中，通过调用keyContext的getCurrentKey获取当前的key，还有当前KeyGroupIndex。

> **原理深入**：ValueState是Keyed State的一种，可以用来存储key-value的数据，通过分析以上源代码后可以发现：底层用于存储key-value数据的StateMap其实也是一个Map，只不过是Flink自己实现的CopyOnWriteStateMap，在多线程情况下，即可以保证线程安全又比较高效的Map。那内存中的的状态数据是如何同步到StateBackend中的呢？Keyed State对用户透明的，只要声明了Keyed State就可以了，不需要用户写代码控制创建快照和同步到StateBackend中。如果使用MemoryStateBackend和FsStateBackend，在checkpoint时，KeyedState是由HeapKeyedStateBackend来创建快照并和同步到StateBackend中的，成功后并向JobManager发送checkpoint成功的消息。



### ListState



<span style="color: rgb(36,91,219); background-color: inherit">ListState&lt;T&gt;</span>：将当前key与一个List集合类型的状态数据进行绑定。需要在使用之前先调用RuntimeContext的getListState(ListStateDescriptor\<T>)方法获取此状态。可以通过ListState的add方法往列表中附加值；也可以通过get()方法返回一个Iterable\<T>来遍历状态值。



下面的代码是自定义的ProcessFunction，里面使用了ListState保存用户的行为事件。

### MapState



<span style="color: rgb(36,91,219); background-color: inherit">MapState&lt;UK, UV&gt;</span>：将当前key与一个Map类型的状态数据进行绑定。需要在使用之前先调用RuntimeContext的getMapState(MapStateDescriptor\<UK, UV>)方法获取此状态，通过调用MapState的put或putAll方法添加元素。





##

## State TTL

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Flink中的KeyedState默认情况下，状态数据会一直保存，但是有一些特殊的场景，数据处理完了，状态不再变化也不再使用了，如果还在状态保证保存，会一直暂用资源，那么久可以给状态设置一个超时时间，超过了指定时间，状态数据会自动清除，优点就是可以节省资源！</span>

任何类型的Keyed State都可以设置一个有效时间（TTL即Time-To-Live），如果一个Keyed State设置了有效时间并且已经超时，存储的状态数据将被清除。存储在Keyed State中的每一条状态数据都可以单独设置自己的有效时间，各个状态数据的有效时间是相互独立的。

在使用状态的TTL前，需要先构建一个StateTtlConfig配置对象。然后把配置传递到state descriptor中启用TTL功能。

### ValueState TTL



<span style="color: inherit; background-color: rgba(255,246,122,0.8)">ValueState的TTL是绑定在keyBy的key上的，即为每一个key和value都设置了超时时间，每一个key和value的超时时间都是相互独立的。</span>

TTLConfig两个重要参数

* setUpdateType  设置最后使用时间更新方式

* setStateVisibility 设置状态状态的可见性

###

### MapState TTL

MapState设置的TTL，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">是为MapState&lt;k, v&gt;中的的每个小k设置的TT</span>L，即每个小k,v都有自己的TTL，并且是相互独立的。



### ListState TTL

ListState设置TTL<span style="color: inherit; background-color: rgba(255,246,122,0.8)">是为ListState&lt;v&gt;中的每一个元素设置单独的TTL</span>，如果ListState中的某个元素的TTL超时了，会将这个元素单独清除。

下面的例子是将保存同一个用户最近的分钟的行为事件，要求将同一个用户的行为事件按照先后顺序保存起来，如果数据超过10分钟，就移除超时的数据，





## OperatorState

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Operator State是一种Non-Keyed State，与并行的算子的实例一一绑定，与数据中的key无关</span>。如果算子中使用了Operator State，那么该算子对应的Task会根据Job实际的并行度有多个实例，即每个subtask中都持有自己独享的状态，subtask和subtask之间的状态数据相互独立的。例如FlinkKafkaConsumer从kafka中消费数据，为了任务出现错误重启后，不重复读取Kafka中的数据，需要记录Kafka的偏移量。Job启动后，会根据实际的并行度启动多个Source实例，一个Source实例就是一个subtask，一个subtask就是一个Kafka的消费者。从Kafka中消费数据，理想情况下，一个消费者对应Kafka的一个分区，每个消费者都拉取自己分区的数据并将维护自己的偏移量，即每一个subtask都维护自己的偏移量，这个偏移量就是Operator State。在checkpoint时，会将每个subtask中的Operator State同步到StateBackend中。在Job失败重启后，Source算子对应的每一个subtask都会从StateBackend中最近一次成功的checkpoint读取属于自己的状态数据并重新加载到内存，这样就可以接着以前的偏移量继续消费Kafka中的数据了。

在Flink中，Managed Operator State只有一种形式，即ListState。为了使用Operator State，需要实现<span style="color: inherit; background-color: rgba(255,246,122,0.8)">CheckpointedFunctio</span>n或~~ListCheckpointed~~接口，实现对应的方法，在checkpoint时就会自动将Operator State同步到StateBackend中。



* **CheckpointedFunction接口**

该接口需要实现两个方法，分别是initializeState方法和snapshotState方法，下面是这两个方法的详细说明：

**initializeState()**：该方的执行顺序依次是：initializeState()、open()、run()，在该方法中需要定义一到多个状态描述器，第一次用来初始化operator state。当任务出现异常重启后，每一个有operator state状态的subtask都会调用该方法从state backend中恢复各自的状态数据。

**snapshotState()**：checkpoint时每个subtask都会调用该方法，在该方法中，首先调用ListState的clear方法，清除上一次checkpoint保存的状态数据，然后添加新的operator state状态数据，该方法调用完成后，operator state就被同步到state backend中了。



## **BroadcastState**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">在实时计算领域中，经常会有一些场景需要在处理数据时关联一些维度数据或字典数据等。</span>常见的做法有以下三种方式：第一种方式是在每个要关联数据的subtask的open方法中将数据加载到内存，当处理的数据要关联维度数据或字典数据就到事先准备好的内存中进行查找，这种方式的特点是关联数据比较高效，但是当业务系统的维度数据或字典数据发生变化，内存中的数据不能更新，可能造成关联不到数据或关联到的数据不是最新的。第二种方式是每处理一条数据都查询一下数据库进行关联。例如根据指定的条件到MySQL或Redis中查询对应的维度数据或字典数据，这种方式虽然可以关联到最新的数据，但是频繁的查询数据库，对数据库的压力会比较大，最重要的是关联数据的效率比较低，程序的延迟会变高。最后一种方式是让每个subtask在open方法中都通过查询数据库，将维度数据或字典数据全部加载到内存，然后再启动一个定时器，定期查询数据库将发生变化的查询出来在更新到内存中，这样就可以弥补前两种方式的缺点了。但是定时器执行也需要一个周期时间，周期太长，数据会更新不及时；周期太短，对数据库压力会变大，况且直接查库耦合度太高，会对业务数据库造成一定的影响。

在DataStream API中，有一种特殊的Operator State叫Broadcast State。一个数据流可以调用<span style="color: inherit; background-color: rgba(255,246,122,0.8)">connect</span>方法连接另一个广播后的数据流（这个广播的数据流事先要调用broadcast方法进行广播）。第二个数据流中的数据可以被广播到第一个数据流指定operator的所有并发实例中，通常是将一些规则信息、配置信息、字典数据、维度数据进广播，这些数据会在下游指定operator的每一个subtask的内存中存储。这样第一个数据流就可以在内存中直接访问到广播的数据进行关联了。并且Broadcast State支持实时更新，只要变化的规则信息、配置信息、字典数据、维度数据可以被Source实时的接入进来，Broadcast State中的数据就可以立即更新。这样就可以实现高效、动态地数据关联了。

下面来看一看DataStream中broadcast方法和connect方法的声明：





Broadcast State与Operator State是有区别的，主要有以下三种区别：

1. Broadcast State存储的数据格式必须是map类型。一个数据流调用broadcast方法，需要传入一到多个MapStateDescriptor，说明Broadcast State保存的数据本质就是Map类型。

2. 必须有一个广播的数据流和一个非广播的数据流，然后在非广播的数据流中获取Broadcast State，并进行数据关联。

3. 由于调用broadcast方法，可以出传入一到多个MapStateDescriptor，那么关联后的operator就可以有一到多个Broadcast State，在实际使用时，可以根据MapStateDescriptor的变量名获取指定的Broadcast State。

在Flink DataStream中，提供了两种操作Broadcast State的API，一种是BroadcastProcessFunction，另外一种是 KeyedBroadcastProcessFunction，下面就分别详细介绍BroadcastProcessFunction和KeyedBroadcastProcessFunction。



> 什么样的场景不适合使用BroadcastState
>
> 1.要广播的数据量非常大
>
> 2.无法获取要广播的全部维度数据



# 10.FlinkSQL

## **基本原理和架构**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">flink sql是架构于flink core之上用sql语义方便快捷地进行结构化数据处理的上层库；（非常类似sparksql和sparkcore的关系）。</span>

## **&#x20;整体架构和工作流程**

核心工作原理如下：

* 将源数据流（数据集），绑定元数据（schema）后，注册成catalog中的表（table、view）；

* 然后由用户通过table Api或者 table sql来表达计算逻辑；

* 由table-planner利用apache calcite进行sql语法解析，绑定元数据得到逻辑执行计划；

* 再用Optimizer进行优化后，得到物理执行计划

* 物理计划经过代码生成器生成代码，得到Transformation Tree

* Transformation Tree 转成JobGraph后提交到flink集群执行



![](images/一文搞定Flink-image-7.png)



## 动态表特性

与spark、hive等组件中的“表”的最大不同之处：<span style="color: inherit; background-color: rgb(255,233,40)">FlinkSQL中的表是</span>**<span style="color: inherit; background-color: rgb(255,233,40)">动态表</span>**<span style="color: inherit; background-color: rgb(255,233,40)">！</span>这是因为：<span style="color: inherit; background-color: rgba(186,206,253,0.7)">flink对数据的核心抽象是“无界（或有界）的数据流”，对数据处理过程的核心抽象是“流式持续处理”。</span> <span style="color: inherit; background-color: rgb(255,233,40)">因此，FlinkSQL对“源表（动态表）”的计算及输出结果（结果表），也是流式、动态、持续的；</span>动态表的有以下特点：

* 数据源的数据&#x662F;**<span style="color: rgb(216,57,49); background-color: inherit">持续输入</span>**

* 查询过程&#x662F;**<span style="color: rgb(216,57,49); background-color: inherit">持续计算</span>**

* 查询结果&#x662F;**<span style="color: rgb(216,57,49); background-color: inherit">持续输出</span>**



如下图所示：“源表clicks”是流式动态的；“聚合查询的输出结果表”，也是流式动态的。

![](images/一文搞定Flink-image-6.png)

这其中&#x7684;**<span style="color: rgb(216,57,49); background-color: inherit">动态</span>**，不仅体现在“数据追加”，对于输出结果表来说，“动态”还包含对“前序输出结果”的“撤回（删除）”、“更新”等模式；

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">那么FlinkSQL是如何将这种对于“前序输出的修正”表达给下游呢？</span>

它&#x7684;**<span style="color: rgb(100,37,208); background-color: inherit">核心设计</span>**&#x662F;在底层的数据流中为每条数据添加<span style="color: inherit; background-color: rgb(255,233,40)">“ChangeMode（修正模式）标记”</span>，而添加了这种ChangeMode标记的底层数据流，取名为<span style="color: inherit; background-color: rgb(255,233,40)">changelogStream</span>



在flink1.12之前，动态表所对应的底层stream，有3种分别是：<span style="color: inherit; background-color: rgb(255,233,40)">Append-only stream</span>、<span style="color: inherit; background-color: rgb(255,233,40)">Retract stream </span>和 <span style="color: inherit; background-color: rgb(255,233,40)">Upsert stream，现在，统称为changelog stream</span>



