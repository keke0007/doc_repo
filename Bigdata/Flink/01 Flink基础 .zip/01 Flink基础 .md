# 1.快速认识flink

## **1.1 离线批计算与实时流式计算**



<u><span style="color: inherit; background-color: rgba(186,206,253,0.7)">批计算与流式计算，本质上就是对有界流和无界流的计算</span></u>



![](<images/01 Flink基础 -image-11.png>)



* **批计算**

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">针对有界流；</span>由于在产出计算结果前可以看到整个（完整）数据集，因而如下计算都可以实现：对数据排序，计算全局统计值，对输入数据的整体产出最终汇总聚合报表；

&#x20;

* **流计算**

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">针对无界流；</span>由于永远无法看到输入数据的整体（数据的输入永远无法结束），只能每逢数据到达就进行计算，并输出"当时"的计算结果（<u><span style="color: inherit; background-color: rgba(186,206,253,0.7)">因而计算结果也不会是一个一次性的最终结果，而是源源不断的无界的结果流</span></u>）；

&#x20;

## **1.2 Flink基本概念**



**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 一个分布式、</span> <span style="color: inherit; background-color: rgb(247,105,100)">有状态</span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)">的实时流式处理系统（编程框架）</span>**

![](<images/01 Flink基础 -image-12.png>)

&#x20;

*<span style="color: inherit; background-color: rgba(186,206,253,0.7)">flink，主要使用java语言开发而成，同时对用户提供了java、scala、python编程api</span>*

*<span style="color: inherit; background-color: rgba(186,206,253,0.7)">flink，以流处理方式作为基础的世界观，并通过引入有界流来实现批计算，从而实现流批一体</span>*

*&#x20;*

## **1.3 Flink的发展历史**



早在 2008 年，Flink 的前身已经是柏林理工大学一个研究性项目， 在 2014 被 Apache 孵化器所接受，然后迅速地成为了 ASF（Apache Software Foundation）的顶级项目之一

&#x20;

Flink的商业公司 Data Artisans，位于柏林的，公司成立于2014年，共获得两轮融资共计650万欧。该公司旨在为企业提供大规模数据处理解决方案，使企业可以管理和部署实时数据，实时反馈数据，做更快、更精准的商业决策。目前，ING, Netflix 和 Uber 等企业都通过 Data Artisans 的 Apache Flink 平台部署大规模分布式应用，如实时数据分析、机器学习、搜索、排序推荐和欺诈风险等。

<span style="color: rgb(100,37,208); background-color: inherit">2019年1月8日，阿里巴巴以 9000 万欧元收购该公司</span>

![](<images/01 Flink基础 -image-13.png>)



## **1.4 Flink的运行时架构**



**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 核心架构角色</span>**



![](<images/01 Flink基础 -image.png>)



Flink 集群采取 Master - Slave 架构：

* Master 的角色为 JobManager，负责集群和作业管理，并且接收客户端提交的任务；

* Slave 的角色是 TaskManager，负责执行计算任务；

* 客户端 Client 负责管理集群和提交任务，JobManager 和 TaskManager 是集群的进程；

&#x20;

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 各角色主要职责说明</span>**

* Client

Flink 客户端是 F1ink 提供的 CLI 命令行工具，用来提交 Flink 作业到 Flink 集群，在客户端中负责 StreamGraph (流图)和 Job Graph (作业图)的构建。

* JobManager

JobManager根据并行度将Flink客户端提交的Flink应用分解为子任务，从资源管理器 ResourceManager 申请所需的计算资源，资源具备之后，开始分发任务到TaskManager 执行 Task，并负责应用容错，跟踪作业的执行状态，发现异常则恢复作业等。

* TaskManager

TaskManager 接收 JobManage 分发的子任务，根据自身的资源情况 管理子任务的启动、 停止、销毁、异常恢复等生命周期阶段。Flink 程序中必须有一个TaskManager。

&#x20;

## &#x20;1.5 **Flink的特点**

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span> <u><span style="color: inherit; background-color: rgba(222,224,227,0.8)">适用于几乎所有的流式数据处理场景</span></u>**

* 事件驱动型应用

* 流、批数据分析

* 数据管道及ETL

&#x20;

![](<images/01 Flink基础 -image-1.png>)

&#x20;

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span> <u><span style="color: inherit; background-color: rgba(222,224,227,0.8)">自带状态管理机制</span></u>**

![](<images/01 Flink基础 -image-2.png>)

&#x20;

&#x20;

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span> <u><span style="color: inherit; background-color: rgba(222,224,227,0.8)">强大的准确性保证</span></u>**

* exactly-once 状态一致性

* 事件时间处理

* 专业的迟到数据处理

&#x20;

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span> <u><span style="color: inherit; background-color: rgba(222,224,227,0.8)">灵活丰富的多层api</span></u>**

* 流、批数据之上的SQL查询

* 流、批数据之上的TableApi

* datastream流处理算子api 、 dataset批处理算子api

* 精细可控的processFunction



![](<images/01 Flink基础 -image-3.png>)

**&#x20;**



**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span> <u><span style="color: inherit; background-color: rgba(222,224,227,0.8)">规模弹性扩展</span></u>**

* 可扩展的分布式架构（集群级别的资源规模灵活配置，算子粒度的独立并行度灵活配置）

* 支持超大状态管理

* 增量checkpoint机制

![](<images/01 Flink基础 -image-4.png>)

**<span style="color: rgb(216,57,49); background-color: rgba(222,224,227,0.8)">算子粒度的独立并行度灵活配置（集群槽位资源可扩展，算子任务实例可扩展）</span>**

&#x20;

**<span style="color: rgb(216,57,49); background-color: inherit"> </span>**

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span> <u><span style="color: inherit; background-color: rgba(222,224,227,0.8)">强大的运维能力</span></u>**

* 弹性实施部署机制

* 高可用配置

* 保存点恢复机制

&#x20;

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span> <u><span style="color: inherit; background-color: rgba(222,224,227,0.8)">优秀的性能</span></u>**

* 低延迟

* 高吞吐

* 内存计算



# 2.**Flink环境准备和编程入门**

## **2.1 standalone集群模式搭建**

standalone模式是Flink自带的分布式集群模式，不依赖其他的资源调度框架

![](<images/01 Flink基础 -image-5.png>)

&#x20;

### **2.1.1 搭建步骤**

① 下载flink安装包，下载地址：[<u><span style="color: rgb(100,37,208); background-color: inherit">https://flink.apache.org/downloads.html</span></u>](https://flink.apache.org/downloads.html)

② 上传flink安装包到Linux服务器上

③ 解压flink安装包到指定的目录

```shell
tar -xvf flink-1.17.2-bin-scala_2.12.tgz -C /opt/apps/
```

④ 修改conf目录下的flink-conf.yaml配置文件

```yaml
#指定jobmanager的地址
jobmanager.rpc.address: node-1.51doit.cn
#jobManager绑定的网段地址
jobmanager.bind-host: 0.0.0.0

#指定taskmanager的可用槽位的数量
taskmanager.numberOfTaskSlots: 2

#taskManager绑定的网段地址
taskmanager.bind-host: 0.0.0.0
# taskmanager的地址，不同的TaskManager要指定不同的主机名后ip地址，不然job运行时，传输数据会出错
# 如果当前机器是node-2.51doit.cn就写当前机器的主机名或ip地址
# 如果当前机器是node-3.51doit.cn就写当前机器的主机名或ip地址
taskmanager.host: node-2.51doit.cn
#rest请求（http请求）的端口号
# rest.port: 8081
# 指定jobManager的地址
rest.address: node-1.51doit.cn
#指定jobManager webui(rest，即http请求)绑定网段地址
rest.bind-address: 0.0.0.0
```

⑤ 修改conf目录下的workers配置文件，指定taskmanager的所在节点

```plain&#x20;text
 node-2.51doit.cn
 node-3.51doit.cn
 node-4.51doit.cn
```

⑥ 将配置好的Flink拷贝到其他节点

```shell
for i in {2..4}; do scp -r flink-1.17.2/ node-$i.51doit.cn:$PWD; done
```

### **2.1.2 启动flink集群和检测**

① 执行启动脚本（只在jobManager所在的机器上执行一次即可）

```shell
bin/start-cluster.sh
```

② 执行jps命令查看Java进程

```shell
jps
```

在ndoe-1上可用看见StandaloneSessionClusterEntrypoint进程即JobManager，在其他的节点上可用看见到TaskManagerRunner 即TaskManager



> 注意：如果TaskManager没有启动，可以查看TaskManager的日志，如发现 Error: VM option 'UseG1GC' is experimental and must be enabled via -XX:+UnlockExperimentalVMOptions.
>
> <span style="color: rgb(143,149,158); background-color: rgba(255,246,122,0.8)">需要修改 taskmanager.sh 脚本，删除 </span> <span style="color: rgb(143,149,158); background-color: rgb(247,105,100)">-XX:+UseG1GC</span>



③ 访问JobManager的web管理界面，端口8081

&#x20;

### **2.1.3 提交Flink任务**

第一种方式：通过web页面提交

&#x20;

![](<images/01 Flink基础 -image-6.png>)

&#x20;

![](<images/01 Flink基础 -image-7.png>)



![](<images/01 Flink基础 -image-8.png>)



第二种方式：使用命令行提交

```shell
bin/flink run -m node-1.51doit.cn:8081 -p 4 -c org.apache.flink.streaming.examples.socket.SocketWindowWordCount examples/streaming/SocketWindowWordCount.jar  --hostname node-1.51doit.cn --port 8888
```

参数说明：

```plain&#x20;text
-m 指定主机名后面的端口为JobManager的REST的端口8081，而不是RPC的端口,RPC通信端口是6123
-p 指定是并行度
-c 指定main方法的全类名
```



## 2.2 初始化Flink工程模板

### 2.2.1 **准备工作**

要求安装Maven 3.0.4 及以上版本和JDK 8以上版本

### 2.2.2 创建java项目模板

执行maven命令，如果maven本地仓库没有依赖的jar，需要连接网络下载

```shell
mvn archetype:generate \
 -DarchetypeGroupId=org.apache.flink \
 -DarchetypeArtifactId=flink-quickstart-java \
 -DarchetypeVersion=1.17.2 \
 -DgroupId=cn.doitedu.flink \
 -DartifactId=flink-java \
 -Dversion=1.0 \
 -Dpackage=cn.doitedu.flink \
 -DinteractiveMode=false
```



### 2.2.3 创建sacal项目模板

```shell
mvn archetype:generate \
 -DarchetypeGroupId=org.apache.flink \
 -DarchetypeArtifactId=flink-quickstart-scala \
 -DarchetypeVersion=1.16.2 \
 -DgroupId=cn.doitedu.flink \
 -DartifactId=flink-scala \
 -Dversion=1.0 \
 -Dpackage=cn.doitedu.flink \
 -DinteractiveMode=false
```



### 2.2.4 手动创建IDEA工程

1. 使用IDA手动创建Maven工程

2. 将下面的内容粘贴到pom.xml

3. 刷新工程下载依赖

```xml
<!--
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

  http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing,
software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, either express or implied.  See the License for the
specific language governing permissions and limitations
under the License.
-->
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
        <modelVersion>4.0.0</modelVersion>

        <groupId>cn.doitedu.flink</groupId>
        <artifactId>flink-in-action</artifactId>
        <version>1.0</version>
        <packaging>jar</packaging>

        <name>Flink Quickstart Job</name>

        <properties>
                <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
                <flink.version>1.15.2</flink.version>
                <target.java.version>1.8</target.java.version>
                <scala.binary.version>2.12</scala.binary.version>
                <maven.compiler.source>${target.java.version}</maven.compiler.source>
                <maven.compiler.target>${target.java.version}</maven.compiler.target>
                <log4j.version>2.17.1</log4j.version>
        </properties>

        <repositories>
                <repository>
                        <id>apache.snapshots</id>
                        <name>Apache Development Snapshot Repository</name>
                        <url>https://repository.apache.org/content/repositories/snapshots/</url>
                        <releases>
                                <enabled>false</enabled>
                        </releases>
                        <snapshots>
                                <enabled>true</enabled>
                        </snapshots>
                </repository>
        </repositories>

        <dependencies>
                <!-- Apache Flink dependencies -->
                <!-- These dependencies are provided, because they should not be packaged into the JAR file. -->
                <dependency>
                        <groupId>org.apache.flink</groupId>
                        <artifactId>flink-streaming-java</artifactId>
                        <version>${flink.version}</version>
                        <scope>provided</scope>
                </dependency>
                <dependency>
                        <groupId>org.apache.flink</groupId>
                        <artifactId>flink-clients</artifactId>
                        <version>${flink.version}</version>
                        <scope>provided</scope>
                </dependency>

                <!-- Add connector dependencies here. They must be in the default scope (compile). -->

                <!-- Example:

                <dependency>
                        <groupId>org.apache.flink</groupId>
                        <artifactId>flink-connector-kafka</artifactId>
                        <version>${flink.version}</version>
                </dependency>
                -->

                <!-- Add logging framework, to produce console output when running in the IDE. -->
                <!-- These dependencies are excluded from the application JAR by default. -->
                <dependency>
                        <groupId>org.apache.logging.log4j</groupId>
                        <artifactId>log4j-slf4j-impl</artifactId>
                        <version>${log4j.version}</version>
                        <scope>runtime</scope>
                </dependency>
                <dependency>
                        <groupId>org.apache.logging.log4j</groupId>
                        <artifactId>log4j-api</artifactId>
                        <version>${log4j.version}</version>
                        <scope>runtime</scope>
                </dependency>
                <dependency>
                        <groupId>org.apache.logging.log4j</groupId>
                        <artifactId>log4j-core</artifactId>
                        <version>${log4j.version}</version>
                        <scope>runtime</scope>
                </dependency>
        </dependencies>

        <build>
                <plugins>

                        <!-- Java Compiler -->
                        <plugin>
                                <groupId>org.apache.maven.plugins</groupId>
                                <artifactId>maven-compiler-plugin</artifactId>
                                <version>3.1</version>
                                <configuration>
                                        <source>${target.java.version}</source>
                                        <target>${target.java.version}</target>
                                </configuration>
                        </plugin>

                        <!-- We use the maven-shade plugin to create a fat jar that contains all necessary dependencies. -->
                        <!-- Change the value of <mainClass>...</mainClass> if your program entry point changes. -->
                        <plugin>
                                <groupId>org.apache.maven.plugins</groupId>
                                <artifactId>maven-shade-plugin</artifactId>
                                <version>3.1.1</version>
                                <executions>
                                        <!-- Run shade goal on package phase -->
                                        <execution>
                                                <phase>package</phase>
                                                <goals>
                                                        <goal>shade</goal>
                                                </goals>
                                                <configuration>
                                                        <artifactSet>
                                                                <excludes>
                                                                        <exclude>org.apache.flink:flink-shaded-force-shading</exclude>
                                                                        <exclude>com.google.code.findbugs:jsr305</exclude>
                                                                        <exclude>org.slf4j:*</exclude>
                                                                        <exclude>org.apache.logging.log4j:*</exclude>
                                                                </excludes>
                                                        </artifactSet>
                                                        <filters>
                                                                <filter>
                                                                        <!-- Do not copy the signatures in the META-INF folder.
                                                                        Otherwise, this might cause SecurityExceptions when using the JAR. -->
                                                                        <artifact>*:*</artifact>
                                                                        <excludes>
                                                                                <exclude>META-INF/*.SF</exclude>
                                                                                <exclude>META-INF/*.DSA</exclude>
                                                                                <exclude>META-INF/*.RSA</exclude>
                                                                        </excludes>
                                                                </filter>
                                                        </filters>
                                                        <transformers>
                                                                <transformer implementation="org.apache.maven.plugins.shade.resource.ServicesResourceTransformer"/>
                                                                <transformer implementation="org.apache.maven.plugins.shade.resource.ManifestResourceTransformer">
                                                                        <mainClass>cn.doitedu.flink.DataStreamJob</mainClass>
                                                                </transformer>
                                                        </transformers>
                                                </configuration>
                                        </execution>
                                </executions>
                        </plugin>
                </plugins>

        </build>
</project>

```



## 2.3 Flink编程模型简介



![](<images/01 Flink基础 -image-9.png>)



Flink提供了不同级别的编程抽象，通过调用抽象的数据集调用算子构建DataFlow就可以实现对分布式的数据进行流式计算和离线计算，**DataSet是批处理的抽象数据集，DataStream是流式计算的抽象数据集**，他们的方法都分别&#x4E3A;**<span style="color: rgb(216,57,49); background-color: inherit">Source、Transformation、Sink</span>**

&#x20;

* **Source**主要负责数据的读取

* **Transformation**主要负责对数据的转换操作

* **Sink**负责最终计算好的结果数据输出。

&#x20;

## &#x20;2.4 第一个入门程序

### **2.4.1 实时WordCount**

```java
public class StreamingWordCount {

    public static void main(String[] args) throws Exception {
        //创建流式计算的ExecutionEnvironment
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //调用Source，指定Socket地址和端口
        DataStream<String> lines = env.socketTextStream(args[0], Integer.parseInt(args[1]));
        //切分压平并将单词和一放入元组中
        DataStream<Tuple2<String, Integer>> words = lines.
                flatMap(new FlatMapFunction<String, Tuple2<String, Integer>>() {
                    @Override
                    public void flatMap(String line, Collector<Tuple2<String, Integer>> collector)
                            throws Exception {
                        String[] words = line.split(" ");
                        for (String word : words) {
                            collector.collect(Tuple2.of(word, 1));
                        }
                    }
                });
        //按照key分组并聚合
        DataStream<Tuple2<String, Integer>> result = words.keyBy(0).sum(1);
        //将结果打印到控制台
        result.print();
        //执行
        env.execute("StreamingWordCount");
    }
}
```

注意：运行该程序前，先启动一个socket服务端产生数据，可以使用如下目录启动

```shell
nc -lk 8888
```

如果没有该命令，可以在linux使用下面的命令安装

```shell
yum install -y nc
```



### 2.4.2 离线WordCount

```java
public class BatchWordCount {
    public static void main(String[] args) throws Exception {
        //创建离线的ExecutionEnvironment
        ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
        //指定Source
        DataSet<String> lines = env.readTextFile(args[0]);
        //对数据切分压平
        DataSet<Tuple2<String, Integer>> result = lines
                .flatMap(new FlatMapFunction<String, Tuple2<String, Integer>>() {
                    @Override
                    public void flatMap(String line, Collector<Tuple2<String, Integer>> collector)
                            throws Exception {
                        //使用分隔符切分
                        String[] words = line.split(" ");
                        //循环遍历切分后的数组
                        for (String word : words) {
                            //将单词使用collector收集
                            collector.collect(Tuple2.of(word, 1));
                        }
                    }
                })
                .groupBy(0) //分组
                .sum(1); //聚合
        //保存结果
        result.writeAsText(args[1]);
        //执行
        env.execute("BatchWordCount");
    }
}
```



### 2.5 添加本地运行web ui的服务

在开发测试时，为了方便，通常在IDEA中使用本地模式运行，并且还想通过使用浏览器访问本地模式Flink的web管理界面，查看job的相关信息，需要加入以下依赖

```xml
<!-- 本地运行，WebUI服务的依赖 -->
<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-runtime-web</artifactId>
    <version>${flink.version}</version>
    <scope>provided</scope>
</dependency>
```



在程序中，还可以指定本地模式的web服务的端口号

```java
Configuration conf = new Configuration();
conf.setInteger("rest.port", 8081); //指定本地webUI服务的端口
//createLocalEnvironmentWithWebUI创建本地执行环境，并指定相关配置
//StreamExecutionEnvironment env = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment(conf);
```



启动程序后，访问 http://localhost:8081 即可查看job执行计划图和运行时的相关信息了



![](<images/01 Flink基础 -image-10.png>)



# **3.DataStream编程基础**



在分布式计算框架中，需要处理分散在多台机器上的海量数据，对于大数据开发人员面临最大的挑战就是代码的编写、部署、调度、容错等。<span style="color: rgb(100,37,208); background-color: inherit">Flink在实时计算方面，提供流一个抽象的集即DataStream，开发者只要调用统一的编程API，传入具体的计算逻辑，不必太多关心底层的细节，就可以完成各种复杂的计算了，并且可以实现快速部署、资源调度、任务容错等，大大的提高了开发效率</span>。

> DataStream是Flink流式计算编程的抽象数据集（与Spark的RDD是类似的），抽象数据集里面不装要真正要计算的数据，而是记录一些描述信息，例如从哪里读取数据，调用了什么方法，传入了什么计算逻辑，通过调用DataStream Transformation(s)和Sink后，构建成执行计划图DataFlow Graph（类似Spark的DAG），然后生成Task提交到集群中执行真正的计算逻辑。



在开发Flink实时计算程序，首先学要创建StreamExecutionEnvironment，然后调用相应的Source算子创建原始的DataStream，再调用零到多次Transformation（转换算子），每调用一次Transformation都会生成一个新的DataStream，最后调用Sink，我们写的程序就形成一个Data Flow Graph（数据流图），然后提交给JobManager，经过优化后生成包含有具体计算逻辑的Task实例，然后调度到TaskManager的slot中开始计算。这个过程非常复杂，在原理深入章节会进行深入的讲解。

&#x20;

## **3.1 Data Source数据源**

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">在实时计算DataStream API中，Source是用来获取外部数据源的操作</span>，按照获取数据的方式，可以分为：基于集合的Source、基于Socket网络端口的Source、基于文件的Source、第三方Connector Source和自定义Source五种。前三种Source是Flink已经封装好的方法，这些Source只要调用StreamExecutionEnvironment的对应方法就可以创建DataStream了，使用起来比较简单，我们在学习和测试的时候会经常用到。如果以后生产环境想要从一些分布式、高可用的消息中间件中读取数据，可以使用第三方Connector Source，比如Apache Kafka Source、AWS Kinesis Source、Google Cloud PubSub Source等（国内公司使用比较多的是Kafka这个消息中间件作为数据源），使用这些第三方的Source，需要额外引入对应消息中间件的依赖jar包。于此同时Flink允许开发者根据自己的需求，自定义各种Source，只要实现SourceFunction这个接口，然后将该实现类的实例作为参数传入到StreamExecutionEnvironment的addSource方法就可以了，这样大大的提高了Flink与外部数据源交互的灵活性。

从并行度的角度，<span style="color: rgb(100,37,208); background-color: inherit">Source又可以分为</span> <span style="color: rgb(100,37,208); background-color: rgba(255,246,122,0.8)">非并行的Source</span> <span style="color: rgb(100,37,208); background-color: inherit">和</span> <span style="color: rgb(100,37,208); background-color: rgba(255,246,122,0.8)">并行的Source</span>。非并行的Source它的并行度只能为1，即用来读取外部数据源的Source只有一个实例，在读取大量数据时效率比较低，通常是用来做一些实验或测试，例如Flink的Socket网络端口读取数据的Source就是一个非并行的Source；并行的Source它的并行度可以是1到多个，即用来读取外部数据源的Source可以有一个到多个实例（在分布式计算中，并行度是影响吞吐量一个非常重要的因素，在计算资源足够的前提下，并行度越大，效率越高）。例如Kafka Source就是并行的Source。

### 1. **基于集合的Source**

基于集合的Source是将一个普通的Java集合、迭代器或者可变参数转换成一个分布式数据集DataStreamSource，它是DataStream的子类，所以也可以使用DataStream类型来引用。得到DataStream后就可以调用Transformation或Sink度数据进行处理了。



* **fromElements**

fromElements(T ...) 方法是一个非并行的Source，可以将一到多个数据作为可变参数传入到该方法中，返回DataStreamSource。<span style="color: rgb(31,35,41); background-color: rgb(255,233,40)">该方法返回的DataStream是一个有限数据流，数据读完后，程序退出，通常用于开发测试</span>。

```java
public class FromElementDemo {
    public static void main(String[] args) throws Exception {
        //创建流计算执行上下文环境
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //指定多个相同类型的数据创建DataStream
        DataStreamSource<String> words = env.fromElements("flink", "hadoop", "flink");
        //调用Sink将数据在控制台打印
        words.print();
        //执行
        env.execute("FromElementDemo");
    }
 }
```

&#x20;

* **fromCollection**

fromCollection可以从一个结合读取数据，返回DataStream，该方法返回的DataStream是一个有限数据流，数据读完后，程序退出，通常用于开发测试。

```java
//创建一个List
List<String> wordList = Arrays.asList("flink", "spark", "hadoop", "flink");
//将List并行化成DataStream
DataStreamSource<String> words = env.fromCollection(wordList);
```



* **fromParallelCollection**



fromParallelCollection(SplittableIterator, Class) 方法是一个并行的Source（并行度可以使用env的setParallelism来设置），该方法需要传入两个参数，第一个是继承SplittableIterator的实现类的迭代器，第二个是迭代器中数据的类型。该方法返回的DataStream是一个有限数据流，数据读完后，程序退出，通常用于开发测试。



```java
//Source是多个并行的
DataStreamSource<LongValue> nums = env.fromParallelCollection(
 new LongValueSequenceIterator(1, 10), LongValue.class
);
```



* **generateSequence**

generateSequence(long from, long to) 方法是一个并行的Source（并行度也可以通过调用该方法后，再调用setParallelism来设置）该方法需要传入两个long类型的参数，第一个是起始值，第二个是结束值，返回一个DataStreamSource。该方法返回的DataStream是一个有限数据流，数据读完后，程序退出，通常用于开发测试。

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
env.setParallelism(3); //设置并行度为3
//调用env的fromParallelCollection创建并行的生成数据的DataStreamSource
DataStreamSource<Long> numbers = env.fromParallelCollection(
        new NumberSequenceIterator(1L, 10L), // 生成数组的range
        Long.class //输出数据的类型
);
```



### 2. **基于Socket的Source**

socketTextStream(String hostname, int port) 方法是一个非并行的Source，该方法需要传入两个参数，第一个是指定的IP地址或主机名，第二个是端口号，即从指定的Socket读取数据创建DataStream。该方法还有多个重载的方法，其中一个是socketTextStream(String hostname, int port, String delimiter, long maxRetry)，这个重载的方法可以指定行分隔符和最大重新连接次数。这两个参数，默认行分隔符是"\n"，最大重新连接次数为0。

```java
//调用env的socketTextStream方法，从指定的Socket地址和端口创建DataStream
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);
```



> 提示：如果使用socketTextStream读取数据，<span style="color: rgb(36,91,219); background-color: inherit">在启动Flink程序之前，必须先启动一个Socket服务</span>，为了方便，Mac或Linux用户可以在命令行终端输入nc -lk 8888启动一个Socket服务并在命令行中向该Socket服务发送数据。Windows用户可以在百度中搜索windows安装netcat命令。

&#x20;

### 3. **基于文件的Source**

基于文件的Source，本质上就是使用指定的FileInputFormat格式读取数据，可以指定TextInputFormat、CsvInputFormat、BinaryInputFormat等格式，基于文件的Source底层都是ContinuousFileMonitoringFunction，这个类继承了RichSourceFunction，它们都是非并行的Source。

&#x20;

* ~~**readFile**~~

readFile(FileInputFormat inputFormat, String filePath) 方法可以指定读取文件的FileInputFormat 格式，其中一个重载的方法readFile(FileInputFormat inputFormat, String filePath, FileProcessingMode watchType, long interval) 可以指定FileProcessingMode，它有两个枚举类型分别是PROCESS\_ONCE和PROCESS\_CONTINUOUSLY模式，PROCESS\_ONCE模式Source只读取文件中的数据一次，读取完成后，程序退出。PROCESS\_CONTINUOUSLY模式Source会一直监听指定的文件，如果使用该模式，需要指定检测该文件是否发生变化的时间间隔，但是使用这种模式，文件的内容发生变化后，会将以前的内容和新的内容全部都读取出来，进而造成数据重复读取。

```java
String path = "file:///Users/xing/Desktop/a.txt";
//PROCESS_CONTINUOUSLY模式是一直监听指定的文件或目录，2秒钟检测一次文件是否发生变化
DataStreamSource<String> lines = env.readFile(new TextInputFormat(null), path,
        FileProcessingMode.PROCESS_CONTINUOUSLY, 2000);
```

* ~~**readTextFile**~~

readTextFile(String filePath) 可以从指定的目录或文件读取数据，默认使用的是TextInputFormat格式读取数据，还有一个重载的方法readTextFile(String filePath, String charsetName)可以传入读取文件指定的字符集，默认是UTF-8编码。该方法是一个有限的数据源，数据读完后，程序就会退出，不能一直运行。该方法底层调用的是readFile方法，FileProcessingMode为PROCESS\_ONCE

```java
 DataStreamSource<String> lines = env.readTextFile(path);
```



### 4. **第三方Connector Source**

在现实生产环境中，为了保证flink可以高效地读取数据源中的数据，通常是跟一些分布式消息中件结合使用，例如Apache Kafka。Kafka的特点是分布式、多副本、高可用、高吞吐、可以记录偏移量等。Flink和Kafka整合可以高效的读取数据，并且可以保证Exactly Once（精确一次性语义）。

&#x20;

* **Kafka Consumer**

首先在maven项目的pom.xml文件中导入Flink跟Kafka整合的依赖

```xml
<!-- Flink跟Kafka整合的依赖 -->
<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-connector-kafka</artifactId>
    <version>1.17.2</version>
</dependency>
```

&#x20;

* **老版本的API**

在代码中，创建一个Properties对象，然后设置Kafka的地址和端口、读取偏移量的策略、消费者组ID、并且设置Source读取完Kafka的数据后，定期更新偏移量。然后new FlinkKafkaConsumer，指定三个参数，第一个参数是topic名称；第二个参数是读取文件的反序列化Schema，SimpleStringSchema指的是读取Kafka中的数据反序列化成String格式；第三个参数是传入事先new 好的Properties实例。然后调用env的addSource方法将FlinkKafkaConsumer的实例传入，这样就创建好了一个DataSteamSource。

```java
//设置Kafka相关参数
Properties properties = new Properties();
//设置Kafka的地址和端口
properties.setProperty("bootstrap.servers", "node-1.:9092,node-2:9092,node-3:9092");
//读取偏移量策略：如果没有记录偏移量，就从头读，如果记录过偏移量，就接着读
properties.setProperty("auto.offset.reset", "earliest");
//设置消费者组ID
properties.setProperty("group.id", "g1");
//没有开启checkpoint，让flink提交偏移量的消费者定期自动提交偏移量
properties.setProperty("enable.auto.commit", "true");
//创建FlinkKafkaConsumer并传入相关参数
FlinkKafkaConsumer<String> kafkaConsumer = new FlinkKafkaConsumer<>(
       "test", //要读取数据的Topic名称
       new SimpleStringSchema(), //读取文件的反序列化Schema
       properties //传入Kafka的参数
);
//使用addSource添加kafkaConsumer
DataStreamSource<String> lines = env.addSource(kafkaConsumer);
```

> 注意：目前这种方式无法保证Exactly Once，Flink的Source消费完数据后，将偏移量定期的写入到Kafka的一个特殊的topic中，这个topic就是\_\_consumer\_offset，这种方式虽然可以记录偏移量，但是无法保证Exactly Once，后面学完了State后，再实现Exactly Once功能。



* 新版本API

```java
String brokerList = "node-1.51doit.cn:9092,node-2.51doit.cn:9092,node-3.51doit.cn:9092";
KafkaSource<String> source = KafkaSource.<String>builder() //泛型指定是读取出的数据的类型
        //指定Kafka的Broker的地址
        .setBootstrapServers(brokerList)
        //指定读取的topic，可以是一个或多个
        .setTopics("wc")
        //指定的消费者组ID
        .setGroupId("group01") //默认请情况，会在checkpoint是，将Kafka的偏移量保存到Kafka特殊的topic中（__consumer_offsets）
        //消费者读取数据的偏移量的位置
        //从状态中读取以已经提交的偏移量,如果状态装没有，会到Kafka特殊的topic中读取数据
        .setStartingOffsets(OffsetsInitializer.committedOffsets(OffsetResetStrategy.EARLIEST))
        //checkpoint成功后，自动提交偏移量到kafka特殊的topic中
        .setProperty("commit.offsets.on.checkpoint","false")
        //指定读取数据的反序列化方式
        .setValueOnlyDeserializer(new SimpleStringSchema())
        .build();
//新的API不调用AddSource，而是调用fromSource方法
DataStreamSource<String> lines = env.fromSource(source, WatermarkStrategy.noWatermarks(), "Kafka Source");
```

新版本API开启Checkpoint，可以实现AtLeastOnce和ExactlyOnce语义，具体原理在后面学完Checkpoint和状态后再深入学习！



### 5. **自定义Source**



Flink的DataStream API可以让开发者根据实际需要，灵活的自定义Source，本质上就是定义一个类，实现SourceFunction这个接口，实现run方法和cancel方法。run方法中实现的就是获取数据的逻辑，然后调用SourceContext的collect方法，将获取的数据收集起来，这样就返回了一个新的DataStreamSource，但是如果只实现这个接口，该Source只能是一个非并行的Source。在生产环境，通常是希望Source可以并行的读取数据，这样读取数据的速度才更快，所以最好的方式是实现ParallelSourceFunction接口或继承RichParallelSourceFunction这个抽象类，同样实现实现run方法和cancel方法，这样该Source就是一个可以并行的Source了。其实所有的Source底层都是调用该的方法。下面是一个简单的并行的Source，后面学习了State和Checkpoint，再定义一个可以实现Exactly Once的并行的Source。

```java
 public class MyParallelSource extends RichParallelSourceFunction<String> {
    private int i = 1; //定义一个int类型的变量，从1开始
    private boolean flag = true; //定义一个flag标标志
    //run方法就是用来读取外部的数据或产生数据的逻辑
    @Override
    public void run(SourceContext<String> ctx) throws Exception {
        //满足while循环的条件，就将数据通过SourceContext收集起来
        while (i <= 10 && flag) {
            Thread.sleep(1000); //为避免太快，睡眠1秒
            ctx.collect("data：" + i++); //将数据通过SourceContext收集起来
        }
    }
    //cancel方法就是让Source停止
    @Override
    public void cancel() {
        //将flag设置成false，即停止Source
        flag = false;
    }
}
```



## **3.2 Transformation转换算子**



Transformation翻译成中文意为转换，是将一个或多个DataStream调用某个转换算子，生成一个新的DataStream，原来的DataStream不变。Flink程序可以将多个Transformation生成的DataStream组合成一个复杂的DataFlow拓扑。这里所提到的转换算子，其实就是DataStream的转换方法，调用转换算子后，一定会生成一个新的DataStream。

我们前面的内容提到过，DataStream其实是一个抽象的数据集，调用了DataStream的转换算子，并不会立即触发任务的执行，对于Flink程序而言，仅是记录了调用了哪个方法，传入了具体什么处理逻辑，这些转换操作会生成多个有着依赖关系和先后顺序的DataStream，这些DataStream组成了DataFlow拓扑（类似Spark的DAG有向无环图），这个DataFlow其实就是一个任务的逻辑执行计划，Flink最终会将这个逻辑计划转成真正的物理计划，最后提交到集群中运行，该部分内容会在后面的章节进行深入的讲解。

###

### 1. **map映射（DataStream → DataStream）**

该方法是将一个DataStream调用map方法返回一个新的DataStream。本质是将该DataStream中<span style="color: inherit; background-color: rgba(255,246,122,0.8)">对应</span>的每一条数据依次迭代出来，应用map方法传入的计算逻辑，返回一个新的DataStream。原来的DataStream中对应的每一条数据，与新生成的DataStream中数据是一一对应的，也可以说是存在着映射关系的。



[map.mp4](<files/01 Flink基础 -map.mp4>)





下面的例子是通过fromElements这个Source将多个单词生成的DataStreamSource，然后调用map方法，传入的计算逻辑是一个匿名内部类，即new MapFunction\<String, String>,重写map方法。这里需要说明的是MapFunction要指定两个泛型，第一个String类型指的是输入的数据的类型（输入的是小写的单词），第二个String类型指的是map处理完后返回的数据类型（将小写单词转换成大写后返回的单词）。map方法中的参数代表每一个输入的单词，即每一个输入的数据都有调用一次map方法，map方法中就是实现具体的计算逻辑，每一个输入数据处理后的都要有一个返回。

```java
public class MapDemo {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        //调用env的fromElements创建一个非并行的DataStreamSource
        DataStreamSource<String> words = env.fromElements(
                "hadoop","spark","flink","hbase","flink","spark"
        );
        //在map方法中传入MapFunction实现类实例，重写map方法
        DataStream<String> upperWords = words.map(new MapFunction<String, String>() {
                @Override
                public String map(String value) throws Exception {
                    //将每一个单词转成大写
                    return value.toUpperCase();
                }
        });
        //调用Sink将数据打印在控制台
        upperWords.print();
        env.execute("MapDemo");
    }
}
```

&#x20;

DataStream的map方法，不但可以传入一个匿名内部类，还可以传入Lambda表达式，下面的例子是将输入为long类型的每一个数字乘以10，得到一个新的DataStream。

```java
//使用并行Source生成数据
DataStreamSource<Long> numbers = env.generateSequence(1, 9);
//调用map并传入Lambda表达式，将每一个数字乘以10，得到一个新的DataStream
DataStream<Long> multiple = numbers.map(i -> i * 10);
```

&#x20;

### 2. **flatMap扁平化映射（DataStream → DataStream）**

该方法是将一个DataStream调用flatMap方法返回一个新的DataStream，本质上是将该DataStream中的对应的每一条数据依次迭代出来，应用flatMap方法传入的计算逻辑，返回一个新的DataStream。原来的DataStream中输入的一条数据经过flatMap方法传入的计算逻辑后，会返回零到多条数据。所谓的扁平化即将原来的数据压平，返回多条数据。



[flatMap.mp4](<files/01 Flink基础 -flatMap.mp4>)





下面的例子是比较经典的WordCount中的一部分，是将一行字符串按照空格切分，返回多个单词，首先通过fromElements这个Source创建DataStreamSource，然后调用flatMap方法，传入的计算逻辑是一个匿名内部类，即new FlatMapFunction\<String, String>,重写flatMap方法。这里需要说明的是FlatMapFunction要指定两个泛型，第一个String类型指的是输入的数据的类型，第二个String类型指的是flatMap处理完后返回的数据类型。flatMap方法需要输入两个参数，第一个参数代表输入的数据，第二个是一个Collector，该方法不需要返回，但是要讲切分完的数据循环，收集到Collector中，由于切分完的单词也是字符串类型，所以Collector的泛型也是String。在输出之前也可以实一些其他的处理逻辑，比如这里进行判断，符合条件后将单词转成小写，在收集到Collector输出。

```java
DataStreamSource<String> lines = env.fromElements(
        "Hadoop spark flink", "Spark hadoop spark", "error error"
);
DataStream<String> words = lines.flatMap(new FlatMapFunction<String, String>() {
        @Override
        public void flatMap(String line, Collector<String> out) throws Exception {
            //将一行字符串按空格切分成一个字符串数组
            String[] arr = line.split(" ");
            //循环切分后的字符串数组
            for (String word : arr) {
                //将过滤后的单词转成小写收集到Collector中
                if(!word.equals("error")) {
                    out.collect(word.toLowerCase());
                }
            }
        }
});
```

&#x20;

下面的例子是将一行字符串切分压平，并且将单词和1组合在一起放入到Tuple2中在flatMap方法中同时完成了。

```java
 DataStream<Tuple2<String, Integer>> wordAndOne = lines.flatMap(
        new FlatMapFunction<String, Tuple2<String, Integer>>() {
            @Override
            public void flatMap(String line, Collector<Tuple2<String, Integer>> out) throws Exception {
                //将一行字符串按空格切分成一个字符串数组
                String[] arr = line.split(" ");
                for (String word : arr) {
                    //将单词转成小写放入到Collector中
                    out.collect(Tuple2.of(word.toLowerCase(), 1));
                }
            }
        }
);
```

&#x20;

如果是调用flatMap方法时传入Lambda表达式，需要在调用flatMap方法后，在调用returns方法指定返回的数据的类型。不然Flink无法自动推断出返回的数据类型，会出现异常。

```java
 DataStream<Tuple2<String, Integer>> wAndOne = lines.flatMap(
        (String line, Collector<Tuple2<String, Integer>> out) -> {
            Arrays.asList(line.split("\\W+")).forEach(word -> {
                out.collect(Tuple2.of(word.toLowerCase(), 1));
            });
        }
).returns(Types.TUPLE(Types.STRING, Types.INT));  //使用returns指定返回数据的类型
```



### 3. **filter过滤（DataStream → DataStream）**

该方法是将一个DataStream调用filter方法返回一个新的DataStream，本质上是将该DataStream中的对应的每一条输入数据依次迭代出来，应用filter方法传入的过滤逻辑，返回一个新的DataStream。原来的DataStream中输入的一条数据经过fliter方法传入的过滤逻辑后，返回true就会保留这条数据，返回false就会过滤掉该数据。



[filter.mp4](<files/01 Flink基础 -filter.mp4>)





下面的例子是过滤掉1到10中的偶数，调用filter方法，传入的计算逻辑是一个匿名内部类，即new FilterFunction\<Integer>,重写filter方法。这里需要说明的是FilterFunction要指定一个泛型，该泛型指的是输入数据的类型。重写的filter方法中的参数为输入的数据，并且在该方法中实现过滤逻辑，此方法必须返回boolean类型。

```java
DataStreamSource<Integer> numbers = env.fromElements(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
//过滤掉奇数，保留偶数
DataStream<Integer> even = numbers.filter(new FilterFunction<Integer>() {
        @Override
        public boolean filter(Integer value) throws Exception {
            return value % 2 == 0; //过滤掉返回false的数组
        }
});
```

&#x20;

下面例子是使用Lambda表达式的方式过滤掉不是以h开头的单词。

```java
DataStreamSource<String> words = env.fromElements("hbase", "hadoop", "flink");
//过滤掉不是h开头的单词
DataStream<String> filtered = words.filter(w -> w.startsWith("h"));
```

&#x20;

### 4. **keyBy按key分区（DataStream → KeyedStream）**

该方法是将一个DataStream调用keyBy方法返回一个新的KeyedStream，本质上是将该DataStream中的每一条按照指定<span style="color: inherit; background-color: rgba(255,246,122,0.8)">的key进行分区</span>，返回一个新的KeyedStream。key相同的数据一定会分到同一个区内，一个区的数据一定是在一个TaskManager的一个subtask中，但是一个subtask中可以有零到多个不同的key的数据。在分布式计算中，如果key相同的数据分散在不同的机器中，需要通过网络将key相同的数据传输到同一台机器的同一个组内，这就是所谓的redistribute(类似spark的shuffle)。一个单词到底会被shuffle到哪一个组，跟key的hashcode值和该任务的并行度相关，但并不是key的hashcode值模除以下游DataStream的并行数这么简单，具体原理会在原理深入章节进行详细的讲解。

下面的例子是将一行字符串进行flatMap切分成多个单词，然后将单词和1放入到Tuple2中，Tuple2中的第一个元素是单词，第二个元素的数字1。经过flatMap处理后，返回一个新的DataStream\<Tuple2\<String, Integer>>，然后调用keyBy算子，传入的是单词在Tuple2中对应的下标值，因为单词是在第0个位置，所以keyBy传入的值为0，分完组后，将key相同的即在同一个组内的次数进行sum，因为次数在Tuple2的下标值为1，所以传入的值为1。

&#x20;

```java
//使用fromElements模拟生成的数据
DataStreamSource<String> lines = env.fromElements(
        "flink spark hadoop hbase hive", "spark flink hadoop hue hbase"
);
//将一行数据切分后得到的每一个单词和1组合放入到Tuple2中
DataStream<Tuple2<String, Integer>> wordAndOne = lines.flatMap(
        new FlatMapFunction<String, Tuple2<String, Integer>>() {
            @Override
            public void flatMap(String line, Collector<Tuple2<String, Integer>> out) throws Exception {
                String[] words = line.split("\\W+");
                for (String word : words) {
                    out.collect(Tuple2.of(word, 1));
                }
            }
        }
);
//按照Tuple2中的第0个位置进行分组，分组后得到KeyedStream
KeyedStream<Tuple2<String, Integer>, Tuple> keyed = wordAndOne.keyBy(0);
```

提示：Java中没有元组这种数据类型，在Flink的Java API中，为了方便封装数据，特别定义了Tulpe类型，Tuple是一个抽象类，有Tuple0到Tuple25共26个实现类，例如Tuple3可以存放3个元素，类型可以不一样，下标分别是0，1，2。

&#x20;

只有一个DataStream中数据是Tuple类型，调用keyBy算子时可传入参数为分组字段对应的下标值。来开一下keyBy方法的方法签名：KeyedStream\<T, Tuple> keyBy(int... fields)，keyBy方法的参数是一个可变参数，说明可以按照一到多个字段进行分组，就类似数据库SQL语句group by后面可以跟一到多个分组条件一样。需求说明的是，KeyedStream\<T, Tuple>中的两个泛型，第一个代表数据分组之前的类型，第二个类型为Tuple，即分组的key，由于keyBy可以按照一到多个字段分组，如果是按照一个字段就是Tuple1，按照两个字段分组就是Tuple2，为了可以通用，所以使用父类型Tuple。

&#x20;

如果DataStream中的数据类型不是Tuple，比如是一个自定义的JavaBean，例如下面定义的一个CountBean，里面有两个public的成员变量，分别是String类型的word，还有一个是Integer类型的count，分别代表单词和次数。

&#x20;

<span style="color: inherit; background-color: rgba(186,206,253,0.7)">提示</span>：在Flink开发中，如果定义一个JavaBean来封装数据，通常定义成public的成员变量，这是为了以后赋值和反射更加方便，如果定义了有参的构造方法，那么一定要再定义一个无参的构造方法，不然运行时会出现异常。并且最好定义一个静态的of方法用来赋值，这样更加方便。可以查看一下Flink中Tuple的源代码也是这么实现的。



```java
  public class CountBean {
    public String word;
    public Integer count;
    public CountBean(){}
    public CountBean(String word, Integer count) {
        this.word = word;
        this.count = count;
    }
    public static CountBean of(String word, Integer count) {
        return new CountBean(word, 1);
    }
    @Override
    public String toString() {
        return "CountBean{" + "word='" + word + '\'' + ", count=" + count + '}';
    }
    @Override
    public int hashCode() {
       return word.hashCode();
    }
}
```

下面的例子是将一个DataSteam调用flatMap时，切分压平后将单词和1封装到CountBean中，得到一个新的DataStream\<CountBean>，然后在调用keyBy进行分组，这个时候keyBy方法就不能传入数字了，可以传入要分组的字段名称，并且也可以按照多个指定分组，传入多个字段名称即可。

```java
//将一行数据切分后得到的每一个单词和1组合放入到自定义的bean实例中
DataStream<CountBean> wordAndOne = lines.flatMap(
        new FlatMapFunction<String, CountBean>() {
            @Override
            public void flatMap(String line,Collector<CountBean> out) throws Exception {
                String[] words = line.split("\\W+");
                for (String word : words) {
                    //将切分后的但是循环放入到bean中
                    out.collect(CountBean.of(word, 1));
                }
            }
        }
);
//按照Bean中的属性名word进行分组
KeyedStream<CountBean, Tuple> keyed = wordAndOne.keyBy("word");
```

> &#x20;注意：
>
> &#x20;1.如果是Bean(POJO)本身作为可以，必须重新该Bean的HashCode方法
>
> 2.数组不能作为keyBy的key

![](<images/01 Flink基础 -keyBy的原理.png>)



### 5. **aggregates聚合（KeyedStream → DataStream）**

aggregates并不是一个算子，而是多个聚合算子的统称，其中有sum、min、minBy、max、maxBy这些算子。一个KeyedStream调用其中一个aggregates方法返回一个新的DataStream。本质上是将该KeyedStream一个组内持续输入的数据按照对应的聚合逻辑进行实时滚动地聚合，生成一个新的DataStream。

&#x20;

* **sum**

该算子实现实时滚动相加的功能，即新输入的数据和历史数据进行相加。只有KeyedStream才可以调用sum方法，如果Tuple类型数据，可以传入一个要聚合的字段对应Tuple的下标（数字）。

```java
//按照Tuple2中的第0个位置进行分组，分组后得到KeyedStream
KeyedStream<Tuple2<String, Integer>, Tuple> keyed = wordAndOne.keyBy(0);
//将分组后的数据进行sum运算
DataStream<Tuple2<String, Integer>> result = keyed.sum(1);
```

&#x20;

如果是自定义的POJO类型数据，可以传入一个要聚合的字段名称。

```java
//按照Bean中的属性名word进行分组
KeyedStream<CountBean, Tuple> keyed = wordAndOne.keyBy("word");
//按照Bean中的属性名count进行sum聚合
DataStream<CountBean> result = keyed.sum("count");
```

&#x20;

* **min、minBy**

这两个算子都是实现滚动比较最小值的功能，只有KeyedStream才可以调用min、minBy方法，如果Tuple类型数据，可以传入一个要比较的字段对应Tuple的下标（数字），如果是自定义的POJO类型数据，可以传入一个要聚合的字段名称。

<span style="color: rgb(31,35,41); background-color: rgb(255,233,40)">min和minBy的区别在于，min返回的是参与分组的字段和要比较字段的最小值，如果数据中还有其他字段，其他字段的值是总是第一次输入的数据的值。而minBy返回的是要比较的最小值对应的全部数据。</span>

```java
//使用fromElements模拟生成的数据
DataStreamSource<Tuple3<String, String, Integer>> wordAndCount = env.fromElements(
        Tuple3.of("佩奇", "女", 5), Tuple3.of("瑞贝卡", "女", 6), Tuple3.of("苏西", "女", 4),
        Tuple3.of("乔治", "男", 5), Tuple3.of("理查德", "男", 4), Tuple3.of("丹尼", "男", 5)
);
KeyedStream<Tuple3<String, String, Integer>, Tuple> keyedStream = wordAndCount.keyBy(1);
//将分组后的数据进行调用min、minBy
DataStream<Tuple3<String, String, Integer>> min1 = keyedStream.min(2);
DataStream<Tuple3<String, String, Integer>> min2 = keyedStream.minBy(2);
DataStream<Tuple3<String, String, Integer>> min3 = keyedStream.minBy(2, false);
//调用print sink打印结果
min1.print("min ");
min2.print("minBy ");
min3.print("minBy last ");
```

&#x20;

上面min方法返回最终的结果是：(佩奇,女,4) 和 (乔治,男,3)。可以看出参与分组的性别和参与比较的年龄是正确的，但是第一个名称不正确，而是第一次出现的数据。

上面minBy方法返回最终的结果是：(瑞贝卡,女,4) 和 (乔治,男,3)。可以看出参与分组的性别和参与比较的年龄是正确的，还有姓名也是分组后最小值对应的名称，说明minBy返回的是最小值对应的那一条整体数据。另外该方法还可以传入一个Boolean值，默认是true，即如果要比较的值相等，true就是返回最先出现的最小值，false返回最后出现的最小值。

* **max、maxBy&#x20;**

这两个算子都是实现滚动比较最大值的功能，用法和min、minBy相同。

### 6. **reduce归约（KeyedStream → DataStream）**

该方法是将一个KeyedStream调用reduce方法返回一个新的DataStream，本质上是将该KeyedStream同一个分区一个组内持续输入的数据按照传入的聚合逻辑进行<span style="color: rgb(31,35,41); background-color: rgb(255,233,40)">实时滚动</span>地聚合，生成一个新的DataStream。

下面的例子是keyBy分组后，将相同单词的次数进行聚合，这里调用的是KeyedStream的reduce方法，传入的聚合逻辑是一个匿名内部类，即new RduceFunction\<Tuple2\<String, Integer>>,重写reduce方法，传入的一个泛型为表示输入和聚合后返回的数据类型都是Tuple2\<String, Integer>，该方法的实现就是将输入的数据，将单词相同的次数和历史值进行累加。如果是实现聚合相加的功能，该方法使用起来会比sum方法复杂，但是redcue方法更灵活实现可以实现更加丰富的归约功能。

```java
//按照Tuple2中的第0个位置进行分组，分组后得到KeyedStream
KeyedStream<Tuple2<String, Integer>, Tuple> keyed = wordAndOne.keyBy(0);
//将分组后的数据进行reduce
DataStream<Tuple2<String, Integer>> reduced = keyed.reduce(new ReduceFunction<Tuple2<String, Integer>>() {
        @Override
        public Tuple2<String, Integer> reduce(Tuple2<String, Integer> t1, Tuple2<String, Integer> t2) throws Exception {
                t1.f1 += t2.f1; //将元组对应的次数进行累加
                return t1; //返回累加后的元组
            }
        }
);
```



### 7. **union 合并（DataStream \* → DataStream）**

该方法可以将两个或者多个<span style="color: inherit; background-color: rgba(255,246,122,0.8)">数据类型一致的DataStream</span>合并成一个DataStream。DataStream\<T> union(DataStream\<T>... streams)可以看出DataStream的union方法的参数为可变参数，即可以合并两个或多个数据类型一致的DataStream。

下面的例子是使用fromElements生成两个DataStream，一个是基数的，一个是偶数的，然后将两个DataStream合并成一个DataStream。

```java
//使用fromElements创建两个DataStream
DataStreamSource<Integer> odd = env.fromElements(1,3,5,7,9);
DataStreamSource<Integer> even = env.fromElements(2,4,6,8,10);
//将两个DataStream合并到一起
DataStream<Integer> result = odd.union(even);
```

> &#x20;如果一个数据流，自己union自己，即将相同的数据进行复制了，输出两份



### 8. **connect连接（DataStream,DataStream→ConnectedStreams）**

connect翻译成中文意为连接，可以将两个数据类型一样也可以类型不一样DataStream连接成一个新的ConnectedStreams。需要注意的是，<span style="color: rgb(31,35,41); background-color: rgb(255,233,40)">connect方法与union方法不同，虽然调用connect方法将两个流连接成一个新的ConnectedStreams，但是里面的两个流依然是相互独立的，</span> <span style="color: rgb(31,35,41); background-color: rgb(247,105,100)">这个方法最大的好处是可以让两个流共享State状态</span> <span style="color: rgb(31,35,41); background-color: rgb(255,233,40)">，</span>状态相关的内容在后面章节讲解

```java
//使用fromElements创建两个DataStream
DataStreamSource<String> word = env.fromElements("a","b","c","d");
DataStreamSource<Integer> num = env.fromElements(1,3,5,7,9);
//将两个DataStream连接到一起
ConnectedStreams<String, Integer> connected = word.connect(num);
```

&#x20;

### 9. **coMap（ConnectedStreams → DataStream）**

coMap并不是一个方法，而是对ConnectedStreams调用map方法。调用map方法，传入的计算逻辑是一个匿名内部类，new CoMapFunction\<String, Integer, String>()，需要输入三个泛型：第一个String类型代表第一个DataStream输入的数据类型；第二个Integer类型代表第二个DataStream输入的数据类型；第三个String类型代返回DataStream的数据类型。这个匿名类要重写两个方法，一个是map1方法，是对第一个流进行map的处理逻辑。另一个是map2方法，是对二个流进行map的处理逻辑，这两个方法都必须返回String类型。最终返回一个新的DataStream中的数据是String。

```java
//将两个DataStream连接到一起
ConnectedStreams<String, Integer> wordAndNum = word.connect(num);
//对ConnectedStreams中两个流分别调用个不同逻辑的map方法
DataStream<String> result = wordAndNum.map(new CoMapFunction<String, Integer, String>() {
    @Override
    public String map1(String value) throws Exception {
        return value.toUpperCase(); //第一个map方法是将第一个流的字符变大写
    }
    @Override
    public String map2(Integer value) throws Exception {
        return String.valueOf(value * 10); //第二个map方将是第二个流的数字乘以10并转成String
    }
});
```

### 10. **coFlatMap（ConnectedStreams → DataStream）**

coFlatMap并不是一个方法，而是对ConnectedStreams调用flatMap方法。调用flatMap方法，传入的计算逻辑是一个匿名内部类，new CoFlatMapFunction\<String, String, String>()，需要指定三个泛型：第一个String类型代表第一个DataStream输入的数据类型；第二个String类型代表第二个DataStream输入的数据类型；第三个String类型代返回DataStream的数据类型。这个匿名类要重写两个方法，一个是flatMap1方法，是对第一个流进行flatMap的处理逻辑。另一个是flatMap2方法，是对二个流进行flatMap的处理逻辑，这两个方法都必须返回String都要通过各自的Collector收集，最终返回一个新的DataStream中的数据是String。

```java
//使用fromElements创建两个DataStream
DataStreamSource<String> word = env.fromElements("a b c", "d e f");
DataStreamSource<String> num = env.fromElements("1,2,3", "4,5,6");
//将两个DataStream连接到一起
ConnectedStreams<String, String> connected = word.connect(num);
//对ConnectedStreams中两个流分别调用个不同逻辑的flatMap方法
DataStream<String> result = connected.flatMap(new CoFlatMapFunction<String, String, String>() {
    @Override
    public void flatMap1(String value, Collector<String> out) throws Exception {
        String[] words = value.split(" ");
        for (String w : words) {
            out.collect(w);
        }
    }
    @Override
    public void flatMap2(String value, Collector<String> out) throws Exception {
        String[] nums = value.split(",");
        for (String n : nums) {
            out.collect(n);
        }
    }
});
```

&#x20;&#x20;

### 11. **project 投影（DataStream → DataStream）**

该方法只能是DataStream中的数据为Tuple类型是才可以使用该方法，project方法的功能和map方法类似，project 方法必须传入数字类型的可变参数，选择出Tuple对应下标的一到多个数据返回一个新的DataStream，该方法只有Java的API有，Scala的API没此方法。

下面的例子是将Tuple3中的下标为0，2对应的数据，即名称和年龄选取出来返回一个新的DataStream。

```java
//使用fromElements生成数据，数据为Tuple3类型，分别代表姓名、性别、年龄
DataStreamSource<Tuple3<String, String, Integer>> users = env.fromElements(
        Tuple3.of("佩奇", "女", 5), Tuple3.of("乔治", "男", 3)
);
//投影方法只可以用于类型为Tuple的DataStream，返回的数据只要姓名和年龄
DataStream<Tuple> result = users.project(0, 2);
```

&#x20;

### 12. **iterate迭代（DataStream → IterativeStream → DataStream）**

该方法用于迭代节点，即将一个流输出的数据，先应用更新模型（即map方法，每次减1），然后判断输入的数据是否需要继续迭代，如果仍需要得等，就会将数据再次作为输入，然后再次应用更新模型；如果不满足继续迭代的条件，并且满足输出的条件，就会将结果输出

```java
DataStreamSource<String> strs = env.socketTextStream("localhost", 8888);
DataStream<Long> numbers = strs.map(Long::parseLong);
//对Nums进行迭代
IterativeStream<Long> iteration = numbers.iterate();
DataStream<Long> iterationBody = iteration.map(new MapFunction<Long, Long>() {
    @Override
    public Long map(Long value) throws Exception {
        System.out.println("iterate input =>" + value);
        return value-=1;
    }
});
//只要满足value > 0的条件，就会形成一个回路，重新的迭代
DataStream<Long> feedback = iterationBody.filter(new FilterFunction<Long>(){
    @Override
    public boolean filter(Long value) throws Exception {
        return value > 0;
    }
});
iteration.closeWith(feedback);
//
DataStream<Long> output = iterationBody.filter(new FilterFunction<Long>(){
    @Override
    public boolean filter(Long value) throws Exception {
        return value <= 0;
    }
});
```



![](<images/01 Flink基础 -image-14.png>)





## **3.3 Data Sink 数据输出**

经过一系列Transformation转换操作后，最后一定要调用Sink操作，才会形成一个完整的DataFlow拓扑。只有调用了Sink操作，才会产生最终的计算结果，这些数据可以写入到的文件、输出到指定的网络端口、消息中间件、外部的文件系统或者是打印到控制台。

### 1. **print 打印**

打印是最简单的一个Sink，通常是用来做实验和测试时使用。如果想让一个DataStream输出打印的结果，直接可以在该DataStream调用print方法。另外，该方法还有一个重载的方法，可以传入一个字符，指定一个Sink的标识名称，如果有多个打印的Sink，用来区分到底是哪一个Sink的输出。

```java
DataStream<Tuple2<String, Integer>> result = wordAndOne.keyBy(0).sum(1);
result.print();
```

&#x20;

下面的结果是WordCount例子中调用print Sink输出在控制台的结果，细心的读者会发现，在输出的单词和次数之前，有一个数字前缀，我这里是1\~4，这个数字是该Sink所在subtask的Index + 1。有的读者运行的结果数字前缀是1\~8，该数字前缀其实是与任务的并行度相关的，由于该任务是以local模式运行，默认的并行度是所在机器可用的逻辑核数即线程数，我的电脑是2核4线程的，所以subtask的Index范围是0\~3，将Index + 1，显示的数字前缀就是1\~4了。这里在来仔细的观察一下运行的结果发现：相同的单词输出结果的数字前缀一定相同，即经过keyBy之后，相同的单词会被shuffle到同一个subtask中，并且在同一个subtask的同一个组内进行聚合。一个subtask中是可能有零到多个组的，如果是有多个组，每一个组是相互独立的，累加的结果不会相互干扰。

```plain&#x20;text
2> (hbase,1)
3> (hue,1)
4> (hadoop,1)
1> (spark,1)
2> (hbase,2)
1> (spark,2)
1> (spark,3)
1> (spark,4)
4> (hadoop,2)
4> (flink,1)
4> (flink,2)
4> (flink,3)
4> (hadoop,3)
```

&#x20;

### 2. **~~writerAsText~~ 以文本格式输出**

该方法是将数据以文本格式实时的写入到指定的目录中，本质上使用的是TextOutputFormat格式写入的。每输出一个元素，在该内容后面同时追加一个换行符，最终以字符的形式写入到文件中，目录中的文件名称是该Sink所在subtask的Index + 1。该方法还有一个重载的方法，可以额外指定一个枚举类型的参数writeMode，默认是WriteMode.NO\_OVERWRITE，如果指定相同输出目录下有相同的名称文件存在，就会出现异常。如果是WriteMode.OVERWRITE，会将以前的文件覆盖。

```java
DataStream<Tuple2<String, Integer>> result = wordAndOne.keyBy(0).sum(1);
result.writeAsText("file:///Users/xing/Desktop/text");
//result.writeAsText("file:///Users/xing/Desktop/text", FileSystem.WriteMode.OVERWRITE); 
```

###

### 3. **~~writeUsingOutputFormat~~ 以指定的格式输出**

该方法是将数据已指定的格式写入到指定目录中，该方法要传入一个OutputFormat接口的实现类，该接口有很多已经实现好了的实现类，并且可以根据需求自己实现，所以该方法更加灵活。writeAsText和writeAsCsv方法底层都是调用了writeUsingOutputFormat方法。

```java
DataStream<Tuple2<String, Integer>> result = wordAndOne.keyBy(0).sum(1);
result.writeUsingOutputFormat(new TextOutputFormat<>(new Path("file:///Users/xing/Desktop/format"));
```

&#x20;

### 4. **writeToSocket 输出到网络端口**

该方法是将数据输出到指定的Socket网络地址端口。该方法需要传入三个参数：第一个为ip地址或主机名，第二个为端口号，第三个为数据输出的序列化格式SerializationSchema。输出之前，指定的网络端口服务必须已经启动。

该方式使用的比较少，数据量比较大的时候，会导致Socket服务崩溃，通常往Kafka中写

```java
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);
lines.writeToSocket("localhost", 9999, new SimpleStringSchema());
```

&#x20;

### 5. **RedisSink**

该方法是将数据输出到Redis数据库中，<span style="color: rgb(31,35,41); background-color: rgb(247,105,100)">Redis是一个基于内存、性能极高的NoSQL数据库</span>，数据还可以持久化到磁盘，读写速度快，适合存储key-value类型的数据。Redis不仅仅支持简单的key-value类型的数据，同时还提供list，set，zset，hash等数据结构的存储。Flink实时计算出的结果，需要快速的输出存储起来，要求写入的存储系统的速度要快，这个才不会造成数据积压。Redis就是一个非常不错的选择。

首先在maven项目中的pom.xml中添加Redis Sink的依赖。

```xml
<!-- flink写入到Redis的Sink依赖 -->
<dependency>
   <groupId>org.apache.bahir</groupId>
   <artifactId>flink-connector-redis_2.12</artifactId>
   <version>1.1.0</version>
</dependency>
```

接下来就是定义一个类（或者静态内部类）实现RedisMapper即可，需要指定一个泛型，这里是Tuple2\<String, Integer>，即写入到Redis中的数据的类型，并实现三个方法。第一个方法是getCommandDescription方法，返回RedisCommandDescription实例，在该构造方法中可以指定写入到Redis的方法类型为HSET，和Redis的additionalKey即value为HASH类型外面key的值；第二个方法getKeyFromData是指定value为HASH类型对应key的值；第三个方法geVauleFromData是指定value为HASH类型对应value的值。

```java
public static class RedisWordCountMapper implements RedisMapper<Tuple2<String, Integer>> {
    @Override
    public RedisCommandDescription getCommandDescription() {
        //写入Redis的方法，value使用HASH类型，并指定外面key的值得名称
        return new RedisCommandDescription(RedisCommand.HSET, "WORD_COUNT");
    }
    @Override
    public String getKeyFromData(Tuple2<String, Integer> data) {
        return data.f0; //指定写入Redis的value里面key的值
    }
    @Override
    public String getValueFromData(Tuple2<String, Integer> data) {
        return data.f1.toString(); //指定写入value里面value的值
    }
} 
```

在使用之前，先new FlinkJedisPoolConfig，设置Redis的ip地址或主机名、端口号、密码等。然后new RedisSink将准备好的conf和RedisWordCountMapper实例传入到其构造方法中，最后调用DataStream的addSink方法，将new好的RedisSink作为参数传入。&#x20;

```java
DataStream<Tuple2<String, Integer>> result = wordAndOne.keyBy(0).sum(1);
//设置Redis的参数，如地址、端口号等
FlinkJedisPoolConfig conf = new FlinkJedisPoolConfig.Builder().setHost("localhost").setPassword("123456").build();
//将数据写入Redis
result.addSink(new RedisSink<>(conf, new RedisWordCountMapper()));
```

&#x20;

### 6. **KafkaSink**

在实际的生产环境中，经常会有一些场景，需要将Flink处理后的数据快速地写入到一个分布式、高吞吐、高可用、可用保证Exactly Once的消息中间件中，供其他的应用消费处理后的数据。Kafka就是Flink最好的黄金搭档，Flink不但可以从Kafka中消费数据，还可以将处理后的数据写入到Kafka，并且吞吐量高、数据安全、可以保证Exactly Once等。



* ~~以过时的API~~

```java
Properties properties = new Properties();
//Kafka的Broker地址
properties.setProperty("bootstrap.servers", "node-1.51doit.cn:9092,node-2.51doit.cn:9092,node-3.51doit.cn:9092");
//指定要写入数据的Kafka的topic
String topic = "tp-out";
//SimpleStringSchema为写入Kafka是数据的序列化方式
FlinkKafkaProducer kafkaProducer = new FlinkKafkaProducer(
        topic, new SimpleStringSchema(), properties
);
lines.addSink(kafkaProducer); 
```

然后将Kafka相关的参数设置到Properties中，再new FlinkKafkaProducer，将要写入的topic名称、Kafka序列化Schema、Properties和作为FlinkKafkaProducer构造方法参数传入。最后调用addSink方法将FlinkKafkaProducer的引用传入到该方法中。虽然下面的代码指定了EXACTLY\_ONCE语义，但是没有开启Checkpointing，是没法实现的。具有怎样实现Exactly Once，会在后面原理深入的章节进行讲解。



* 新版本API

```java
 Properties properties = new Properties();
//KafkaSink的新API
properties.setProperty("transaction.timeout.ms", "600000"); //broker默认值是为15分钟
//使用新的API将数写入到Kafka中
KafkaSink<String> sink = KafkaSink.<String>builder()
        //指定写入的Kafka的Topic
        .setBootstrapServers(brokerList)
        .setKafkaProducerConfig(properties) //设置Kafka相关参数
        //读取Kafka的topic的相关参数
        .setRecordSerializer(KafkaRecordSerializationSchema.builder()
                .setTopic("kafka-out") //值的的topic
                .setValueSerializationSchema(new SimpleStringSchema()) //写入的数据的序列化方式
                .build()
        )
        //实现的一致性语义，需要开启checkpoint
        .setDeliverGuarantee(DeliveryGuarantee.EXACTLY_ONCE)
        .build();
//不是调用addSink方法，而是调用SinkTo方法
lines.sinkTo(sink);
```

&#x20;新版本API写入Kafka，开启Checkpoint，可以支持AtLeastOnce和ExactlyOnce，保证数据的一致性，具有原理等后面学完Checkpoint和状态后在深入学习



### 7. JDBCSink



写入到JDBC有两种方式，追加和更新



* 追加

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

//o01,图书,300
//o02,电脑,2000
//o03,手机,4003
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);

SingleOutputStreamOperator<Tuple3<String, String, Double>> tpStream = lines.map(new MapFunction<String, Tuple3<String, String, Double>>() {
    @Override
    public Tuple3<String, String, Double> map(String value) throws Exception {
        String[] fields = value.split(",");
        return Tuple3.of(fields[0], fields[1], Double.parseDouble(fields[2]));
    }
});

/**
 * 第一个参数：指定sql
 * 第二个参数：将输入的数据与preparedStatement进行绑定，accept方法每来一条数据调用一次
 * 第三个参数：执行参数选项
 * 第四个参数：数据库连接参数
 */
SinkFunction<Tuple3<String, String, Double>> jdbcSink = JdbcSink.sink(
        //tb_orders2表要么是自增主键，要么没有主键
        "insert into tb_orders2 (oid, category, money) values (?, ?, ?)",
        new JdbcStatementBuilder<Tuple3<String, String, Double>>() {
            @Override
            public void accept(PreparedStatement preparedStatement, Tuple3<String, String, Double> tp) throws SQLException {
                preparedStatement.setString(1, tp.f0); //绑定参数
                preparedStatement.setString(2, tp.f1);
                preparedStatement.setDouble(3, tp.f2);
            }
        },
        JdbcExecutionOptions.builder()
                .withBatchIntervalMs(2000)  //数据2秒钟写一次，默认是0秒（来一条写入一条，这样不好）
                .withBatchSize(100)        //数据达到多少条写一次，默认是5000条，如果时间和数量条件都指定了，满足其一即可
                .withMaxRetries(5)         // 写入失败重试次数5次默认是3次
                .build()
        ,
        new JdbcConnectionOptions.JdbcConnectionOptionsBuilder()
                .withUrl("jdbc:mysql://node-1.51doit.cn:3306/doit?characterEncoding=utf-8")
                .withDriverName("com.mysql.cj.jdbc.Driver")
                .withUsername("root")
                .withPassword("123456")
                .build()
);
tpStream.addSink(jdbcSink);

env.execute();
```



* 更新

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

//o01,图书,300
//o02,电脑,2000
//o03,手机,4003
DataStreamSource<String> lines = env.socketTextStream("localhost", 8888);

SingleOutputStreamOperator<Tuple3<String, String, Double>> tpStream = lines.map(new MapFunction<String, Tuple3<String, String, Double>>() {
    @Override
    public Tuple3<String, String, Double> map(String value) throws Exception {
        String[] fields = value.split(",");
        return Tuple3.of(fields[0], fields[1], Double.parseDouble(fields[2]));
    }
});

/**
 * 第一个参数：指定sql
 * 第二个参数：将输入的数据与preparedStatement进行绑定，accept方法每来一条数据调用一次
 * 第三个参数：执行参数选项
 * 第四个参数：数据库连接参数
 */
SinkFunction<Tuple3<String, String, Double>> jdbcSink = JdbcSink.sink(
        //tb_orders要有主键
        "insert into tb_orders values (?, ?, ?) on duplicate key update category = ?, money = ?",
        new JdbcStatementBuilder<Tuple3<String, String, Double>>() {
            @Override
            public void accept(PreparedStatement preparedStatement, Tuple3<String, String, Double> tp) throws SQLException {
                preparedStatement.setString(1, tp.f0); //绑定参数
                preparedStatement.setString(2, tp.f1);
                preparedStatement.setDouble(3, tp.f2);
                preparedStatement.setString(4, tp.f1);
                preparedStatement.setDouble(5, tp.f2);
            }
        },
        JdbcExecutionOptions.builder()
                .withBatchIntervalMs(2000)  //数据2秒钟写一次，默认是0秒（来一条写入一条，这样不好）
                .withBatchSize(100)        //数据达到多少条写一次，默认是5000条，如果时间和数量条件都指定了，满足其一即可
                .withMaxRetries(5)         // 写入失败重试次数5次默认是3次
                .build()
        ,
        new JdbcConnectionOptions.JdbcConnectionOptionsBuilder()
                .withUrl("jdbc:mysql://node-1.51doit.cn:3306/doit?characterEncoding=utf-8")
                .withDriverName("com.mysql.cj.jdbc.Driver")
                .withUsername("root")
                .withPassword("123456")
                .build()
);

tpStream.addSink(jdbcSink);

env.execute();
```



## 3.4 物理分区



与其他的流式计算框架一样，Flink DataStream同样提供了一些底层的算子来精准控制数据在重分区时数据流向下游具体哪个分区，这些方法都属于Transformation转换算子。本质是决定数据进入具体哪一个或哪几个Channel（通道），每个Channel都有自己的Index，并与下游的subtask存在对应关系。这些用来控制数据流向的Transformation算子也称为物理分区方法。这些物理分区方法内部都有对应的流分区器，会在原理深入章节再详细讲解这些流分区器的底层实现。



### 1. **rebalance轮询**

DataStream调用rebalance方法后会生成一个新的DataStream，该方法的功能是将上游产生的数据轮询地发送给下游的subtask，内部使用的是RebalancePartitioner，这个分区器实现了一个轮询分区算法，数据经过该分区器的算法计算后，会返回一个Channel Index，然后将数据放入到对应Index的Chennel中，下游的subtask会通过网络到对应的Channel中拉取数据。



![](<images/01 Flink基础 -diagram.png>)

```java
//将上游的数据使用轮询（round-robin）的方式给下游的一个task
DataStream<String> result = words.rebalance();
```



### 2. **shuffle随机**

DataStream调用shuffle方法后会生成一个新的DataStream，该方法的功能是将上游产生的数据随机地发送给下游的subtask，内部使用的是ShufflePartitioner，数据经过该分区器的算法计算后，会随机返回一个Channel Index。

![](<images/01 Flink基础 -diagram-1.png>)



```java
//将上游的数据使用随机的方式给下游的一个task
DataStream<String> broadcastStream = words.shuffle();
```

&#x20;

提示：rebalance和shuffle是有区别的，shuffle是将上游的数据随机发给下游的subtask，而rebalance将上游的数据以循环方式依次发给下游的subtask。由于shuffle随机的，数据可能会分布不均。

&#x20;

### 3. **rescale在一个TashManager中轮询**

与rebalance相比，减少了网络传输，同时可以在同一个TaskManager进行轮询，<span style="color: inherit; background-color: rgba(255,246,122,0.8)">可以一定程度上缓解数据倾斜的问题，极端情况也有数据倾斜</span>。

重缩放分区和轮询分区非常类似，当调用resacle()方法时，底层调用的其实就是Round-Robin算法进行轮询。不同的是，rescale重缩放分区会将上游不同的数据来源分为不同的“团体”，在下游的同一团体内，对所有slot进行轮询分发。

从底层实现上看，rebalance 和 rescale 的根本区别在于任务之间的连接机制不同。rebalance 将会针对所有上游任务（发送数据方）和所有下游任务（接收数据方）之间建立通信通道，这是一个笛卡尔积的关系；而 rescale 仅仅针对每一个任务和下游对应的部分任务之间建立通信通道，节省了很多资源。



![](<images/01 Flink基础 -diagram-2.png>)



```java
//将上游的数据在一个TaskManager的多个TaskSlot中进行轮询，低配版Rebalance, 更加节省资源
DataStream<String> rescaled = upperDataStream.rescale();
```

### 4. **forward直传**

上下游并行度一致，调用了一下特殊的方法，union，startNewChain、disableChaining端口算子链，那么就会分区策略为直传，即上游的0号分区的subtask将数据传输给下游的0号分区的subtask



下面的图为union时，两个流并行度不一致的情况



```java
DataStreamSource<String> lines1 = env.socketTextStream("localhost", 8888);
SingleOutputStreamOperator<Integer> nums1 = lines1.map(Integer::parseInt);
DataStreamSource<String> lines2 = env.socketTextStream("localhost", 9999);
SingleOutputStreamOperator<Integer> nums2 = lines2.map(Integer::parseInt).setParallelism(3);
DataStream<Integer> union = nums1.union(nums2);
SingleOutputStreamOperator<Integer> res = union.map(e -> e * 10); //并行度为4
res.print(); //print的并行度为4
```

![](<images/01 Flink基础 -QQ20221125-103609@2x.png>)



下面是调用disableChaining是对应的执行计划图

```java
SingleOutputStreamOperator<String> leadStream = lines.map(new RichMapFunction<String, String>() {

    @Override
    public String map(String value) throws Exception {
        //获取当前map算子对应的subtask的分区编号
        int indexOfThisSubtask = getRuntimeContext().getIndexOfThisSubtask();
        //拼字符串的目的，是为了指定数据是从上游哪个subtask产生的
        return value + " -> " + indexOfThisSubtask;
    }
}).setParallelism(4);

leadStream.disableChaining(); //强行断开算子链

leadStream.addSink(new RichSinkFunction<String>() {
    @Override
    public void invoke(String value, Context context) throws Exception {
        //获取当前sink算子对应的subtask的分区编号
        int indexOfThisSubtask = getRuntimeContext().getIndexOfThisSubtask();
        //拼字符串的目的，是为了知道数据进入了哪个subtask
        String res = value + " -> " + indexOfThisSubtask;
        System.out.println(res);
    }
}); //没有指定sink的并行度，sink的并行度与执行环境的并行度保存一致
```

![](<images/01 Flink基础 -QQ20221125-104602@2x.png>)







### 5. **broadcast广播**

DataStream调用broadcast方法后会生成一个新的DataStream，该方法的功能是将上游产生的数据发送给下游的所有的subtask，内部使用的是BroadcastPartitioner，数据经过该分区器的计算后，会随机返下游所有的Channel Index。

![](<images/01 Flink基础 -diagram-3.png>)

```java
//将上游的数据广播到该任务下游的每一个task
DataStream<String> broadcastStream = words.broadcast();
```

### 6. **partitionCustom自定义分区规则**

DataStream的API运行用户根据自己的需求，自定义分区规则。这个方法就是partitionCustom，调用该方法会返回一个新的DataStream。

下面的例子是根据输入的字符串，将key为java的分配到1号分区，key为scala的分配到2号分区，key为其他的值分配到0号分区。首先要定义一个类，实现Partitioner接口，指定的泛型为输入key的类型，并重写partition方法。partition方法的第一个参数为输入数据的key，第二个位下游DataStream的并行度的数量。在该方法中，可以使用if判断或switch等逻辑，根据传入的参数计算返回一个int类型的分区编号。

```java
public class MyPartitioner1 implements Partitioner<String> {
    @Override
    public int partition(String key, int numPartitions) {
        if(key.equals("java")) {
            return 1;
        } else if(key.equals("scala")) {
            return 2;
        } else {
            return 0;
        }
    }
}
```

接下来在调用DataStream的partitionCustom，将自定义分区器类的实例作为第一个参数传入到到该方法中，第二个参数为key对应的下标或名称。

```java
DataStream<Tuple2<String, Integer>> wordAndOne = words.map(w -> Tuple2.of(w, 1))
        .returns(Types.TUPLE(Types.STRING, Types.INT));
DataStream<Tuple2<String, Integer>> result = wordAndOne.partitionCustom(
   new MyPartitioner1(), //自定义的分区器
   t -> t.f0 //提取key的方法
);
```

### 7. keyBy

按照key的hashcode值进行分区(使用了murmurhash，这种hash方式散列更彻底，并且可以避免负的hashcode值)，前面已经讲过了，不再赘述了。



### 8. global

将数据直接分给0号分区



## **3.5 算子链和资源组**

### 1. Task和SubTask的区别

在Flink中，Task和SubTask的概念模糊不清，经常被混淆；<span style="color: inherit; background-color: rgba(255,246,122,0.8)">SubTask是Flink中最小的任务执行单元，即是Flink创建的类的实例对象，里面封装着描述信息和运算逻辑。一个Task中可以有一到多个SubTask，同一个Task中的多个SubTask的运算逻辑相同，仅是计算的数据不同而已。</span>

下面是一个简单的实时程序，执行环境的并行度设置为2。先从Kafka中读取数据，数据的格式为String类型的单词，然后调用map将单词和1组合，再调用keyBy进行分区，keyBy后再将次数进行sum，然后调用print sink，并且设置sink的并行度为1。

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment(conf);
env.setParallelism(2);
//KakfaSource
KafkaSource<String> source = KafkaSource.<String>builder()
        .setBootstrapServers("node-1.51doit.cn:9092,node-2.51doit.cn:9092,node-3.51doit.cn:9092")
        .setTopics("wordcount") //topic
        .setGroupId("g01") //组ID
        .setStartingOffsets(OffsetsInitializer.earliest()) //从头读
        .setValueOnlyDeserializer(new SimpleStringSchema()) //反序列化实现类
        .build();
DataStreamSource<String> lines = env.fromSource(source, WatermarkStrategy.noWatermarks(), "KafkaSource");
//先map，在keyBy，然后按照单词聚合
SingleOutputStreamOperator<Tuple2<String, Integer>> summed = lines
        .map(w -> Tuple2.of(w, 1)).returns(Types.TUPLE(Types.STRING, Types.INT))
        .keyBy(t -> t.f0)
        .sum(1);
//调用sink，并且将并行度设置为1
summed.print().setParallelism(1);
env.execute();
```



程序运行后，查询web管理界面，该job的执行计划图如下：

![](<images/01 Flink基础 -QQ20221121-141225@2x.png>)

可以看出，该job有3个Task，5个SubTask；第一个Task和第二个Task中间是一个调用了keyBy进行了分区，第二个和第三个Task是因为并行度发送变化（最后Sink算子对应的DataStream并行度这设置为1了）。

![](<images/01 Flink基础 -diagram-4.png>)



<span style="color: inherit; background-color: rgba(255,246,122,0.8)">从宏观的角度来看，多个Task连接在一起，形成了DataFlow Graph（数据流图）</span>，从微观的角度，即将Task展开，每个Task中又可以有一到多个SubTask，一个SubTask对应一个线程。



![](<images/01 Flink基础 -QQ20221121-135325@2x.png>)



### 2. **算子链简介**

DataStream经过一系列的Transformation转换后，最后调用Sink，形成一个完整的DataFlow Graph，这个任务在生成JobGraph阶段，会将代码中相邻的两个或两个以上的算子<span style="color: inherit; background-color: rgba(255,246,122,0.8)">优化</span>成一个算子链（Operator Chains）以放到一个subtask（一个subtask对应一个线程）中执行，<span style="color: rgb(31,35,41); background-color: rgb(247,105,100)">这样以减少线程之间的切换和数据缓冲的开销，从而提高整体的吞吐量和降低延迟。</span>



下面经典的WordCount例子，在没有调用startNewChain、disableChaining之前只有三个Task。

```java
DataStream<String> lines = env.socketTextStream("localhost", 8888);
//过滤数据
DataStream<String> filtered = lines.filter(line -> !line.startsWith("ERROR"));
//对数据进行切分
DataStream<String> words = filtered.flatMap(new FlatMapFunction<String, String>() {
    @Override
    public void flatMap(String line, Collector<String> out) throws Exception {
        Arrays.stream(line.split(" ")).forEach(out::collect);
    }
});
//将单词和1组合到元组中
DataStream<Tuple2<String, Integer>> wordAndOne = words.map(w -> Tuple2.of(w, 1))
        .returns(Types.TUPLE(Types.STRING, Types.INT));
//分组、聚合
DataStream<Tuple2<String, Integer>> summed = wordAndOne
        .keyBy(t -> t.f0) 
        .sum(1);
//打印
summed.print();
```

![](<images/01 Flink基础 -image-15.png>)



### 3. 全局禁用算子链

flink默认情况，会自动优化，算子链能连在一起的尽量连在一起，可以节省资源，提高效率，也可以调用env的方法全局禁用算子链（但是不推荐使用）

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

//禁用全部算子链，不建议使用
env.disableOperatorChaining();

DataStream<String> lines = env.socketTextStream("localhost", 8888);
//过滤数据
DataStream<String> filtered = lines.filter(line -> line.startsWith("ERROR"));
//对数据进行切分
DataStream<String> words = filtered.flatMap(new FlatMapFunction<String, String>() {
    @Override
    public void flatMap(String line, Collector<String> out) throws Exception {
        Arrays.stream(line.split(" ")).forEach(out::collect);
    }
});
//将单词和1组合到元组中
DataStream<Tuple2<String, Integer>> wordAndOne = words.map(w -> Tuple2.of(w, 1))
        .returns(Types.TUPLE(Types.STRING, Types.INT));
//分组、聚合
DataStream<Tuple2<String, Integer>> summed = wordAndOne
        .keyBy(t -> t.f0)
        .sum(1);
//打印
summed.print();

env.execute();
```

![](<images/01 Flink基础 -QQ20230131-093133@2x.png>)



### 4. **startNewChain**

在上一个WordCount例子的基础上，在调用flatMap方法后，再调用startNewChain方法，然后重新运行。会发现多出来一个Task。startNewChain方法的功能是将原来存在operator chain的两个算子，从调用startNewChain这个算子开始，强制的开启一个新链。这样就将原来合并在一个subtask中的算子拆分开了。

```java
 DataStream<String> words = filtered.flatMap(new FlatMapFunction<String, String>() {
    @Override
    public void flatMap(String line, Collector<String> out) throws Exception {
        Arrays.stream(line.split(" ")).forEach(out::collect);
    }
}).startNewChain(); //从该算子开始，开启一个新链
```

![](<images/01 Flink基础 -图片1.png>)

&#x20;

### 5. **disableChaining**

还在上一个WordCount例子的基础上，在调用flatMap方法后，再调用disableChaining方法，然后重新运行。会发现多出来2个Task。disableChaining方法的功能从调用startNewChain这个算子开始，将该算子前面和后面存在的operator chain都强制端口，即将该算子单独独立出来。

```java
 DataStream<String> words = filtered.flatMap(new FlatMapFunction<String, String>() {
    @Override
    public void flatMap(String line, Collector<String> out) throws Exception {
        Arrays.stream(line.split(" ")).forEach(out::collect);
    }
}).disableChaining(); //从该算子的前面的链和后面的链都断开
```



![](<images/01 Flink基础 -图片2.png>)

&#x20;

### 6.  Task槽和资源

![](<images/01 Flink基础 -image-16.png>)



每个 worker（TaskManager）都是一个 *JVM 进程*，可以在单独的线程中执行一个或多个 subtask。为了控制一个 TaskManager 中接受多少个 subtask，就有了所谓的 **task slots**（一个TaskManager中至少要有一个slot）。

**<span style="color: inherit; background-color: rgba(255,246,122,0.8)">每个 </span>*<span style="color: inherit; background-color: rgba(255,246,122,0.8)">task slot</span>*<span style="color: inherit; background-color: rgba(255,246,122,0.8)"> 代表 TaskManager 中资源的固定子集</span>**。例如，一个TaskManager中 有3 个 slot  ，会将其托管内存平均分配给每个 slot。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">分配资源意味着当前job的 对应的subtask 不会与其他job的 对应的subtask 竞争托管内存</span>，而是具有一定数量的保留托管内存。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">注意slot计算对托管内存进行隔离，并没有对 CPU进行隔离</span>。

通过调整 task slot 的数量，用户可以定义 subtask 如何互相隔离。每个 TaskManager 有一个 slot，这意味着一个slot中的多个subtask 都在单独的 JVM 中运行（例如，可以在单独的容器中启动）。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">具有多个 slot 意味着更多 subtask 共享同一 JVM</span>。同一 JVM 中的 subtask 共享 TCP 连接（通过多路复用）和心跳信息。它们还可以共享数据集和数据结构(static)，从而减少了每个subtask 的开销。



默认情况下，<span style="color: inherit; background-color: rgb(98,210,86)">Flink 允许来自于同一job，不同Task的subtask 共享同一个 slot。</span>结果就是一个 slot 运行多个subtask，形成一个持有整个作业管道（pipeline）。允许 *slot 共享*有两个主要优点：

![](<images/01 Flink基础 -QQ20221121-135325@2x-1.png>)

* Flink 集群所需的 task slot 和作业中使用的最大并行度恰好一样。无需计算程序总共包含多少个 task（具有不同并行度）。

* 容易获得更好的资源利用。如果没有 slot 共享，非密集 subtask（*source/map()*）将阻塞和密集型 subtask（*window*） 一样多的资源。通过 slot 共享，我们示例中的基本并行度从 2 增加到 6，可以充分利用分配的资源，同时确保繁重的 subtask 在 TaskManager 之间公平分配。



<span style="color: inherit; background-color: rgb(98,210,86)">下面的图是没有共享资源槽</span>

![](<images/01 Flink基础 -QQ20221121-140852@2x.png>)

例如上面的程序，如果没有共享资源槽，只能运行2并行，但是允许共享资源槽，可以运行6个并行，<span style="color: inherit; background-color: rgb(98,210,86)">提高了资源利用率并增大了吞吐量</span>。



<span style="color: inherit; background-color: rgb(98,210,86)">下面的图使用共享资源槽的情况（默认的）</span>

![](<images/01 Flink基础 -QQ20221121-195526@2x.png>)

### 7. 设置资源槽组名称



<span style="color: inherit; background-color: rgba(255,246,122,0.8)">为了可以灵活的将一个或多个subtask调度到指定名称的TaskSlot中，Flink提供了设置共享资源槽组名称的功能</span>。在默认情况下，Flink允许将来自于同一个Job且不同Task的多个subtask共享同一个Slot，这样可以提高资源的利用率。但是有些场景，比如一个算子是计算密集型的，它需要更多的内存资源，就可以调用DataStream的resource group API，可以用来避免不必要的slot sharing，即将资源密集型的一个或多个subtask单独调度到指定名称的Slot中，让它独享一个资源槽。<span style="color: inherit; background-color: rgba(255,246,122,0.8)">DataStream有一个slotSharingGroup方法，可以设置共享资源组的名称，如果不设置，默认的名称为“defalut”。</span>一但某一个算子调用了slotSharingGroup方法指定了共享资源组的名称，后面的算子的共享资源组的名称都就近跟随着上一次设置的名称。

```java
//过滤数据
DataStream<String> filtered = lines.filter(line -> line.startsWith("error"))
        .slotSharingGroup("myGroup"); //设置槽共享资源组名称为myGroup
```



<span style="color: inherit; background-color: rgba(255,246,122,0.8)">不修改共享资源槽组名称，默认都是default</span>

```java

StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
DataStreamSource<String> lines = env.socketTextStream(args[0], Integer.parseInt(args[1]));
SingleOutputStreamOperator<String> words = lines.flatMap(new FlatMapFunction<String, String>() {
    @Override
    public void flatMap(String e, Collector<String> collector) throws Exception {
        //切分数据
        String[] words = e.split(" ");
        //循环
        for (String word : words) {
            //使用Collector输出数据
            collector.collect(word);
        }
    }
});
//假设，filter算子对应的运算逻辑，是计算密集型的算子（需要大量的资源）
//将大量的规则数据缓存的到filter算子对应的subtask
SingleOutputStreamOperator<String> filteredStream = words
        .filter(w -> !w.startsWith("error"))
        .disableChaining(); //将filter前后的链都断开
//将单词和1组合在一起
SingleOutputStreamOperator<Tuple2<String, Integer>> wordAndOne = filteredStream.map(new MapFunction<String, Tuple2<String, Integer>>() {
    @Override
    public Tuple2<String, Integer> map(String e) throws Exception {
        return Tuple2.of(e, 1);
    }
});
//将数据按照单词进行分区
KeyedStream<Tuple2<String, Integer>, String> keyedStream = wordAndOne.keyBy(new KeySelector<Tuple2<String, Integer>, String>() {
    @Override
    public String getKey(Tuple2<String, Integer> tp) throws Exception {
        return tp.f0;
    }
});
SingleOutputStreamOperator<Tuple2<String, Integer>> sum = keyedStream.sum(1);//将同一个组呢的次数进行sum
sum.print();
env.execute("StreamWordCount");
```



![](<images/01 Flink基础 -diagram-5.png>)

资源密集型的subtask中缓存的大量过滤规则数据，内存占用过大，导致程序无法运行。



下面设置filter的共享资源槽组的名称为doit，并且将其后面算子的名称改成default



```java

StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
DataStreamSource<String> lines = env.socketTextStream(args[0], Integer.parseInt(args[1]));
SingleOutputStreamOperator<String> words = lines.flatMap(new FlatMapFunction<String, String>() {
    @Override
    public void flatMap(String e, Collector<String> collector) throws Exception {
        //切分数据
        String[] words = e.split(" ");
        //循环
        for (String word : words) {
            //使用Collector输出数据
            collector.collect(word);
        }
    }
});
//假设，filter算子对应的运算逻辑，是计算密集型的算子（需要大量的资源）
//将大量的规则数据缓存的到filter算子对应的subtask
SingleOutputStreamOperator<String> filteredStream = words
        .filter(w -> !w.startsWith("error"))
        .disableChaining()
        .slotSharingGroup("doit"); //设置槽共享组名称（如果不设置，默认共享资源槽组的名称为default）
        //就是将该算子的共享资源槽的名称修改后，后面的所有算子共享资源槽的名称都跟着改变了
//将单词和1组合在一起
SingleOutputStreamOperator<Tuple2<String, Integer>> wordAndOne = filteredStream.map(new MapFunction<String, Tuple2<String, Integer>>() {
    @Override
    public Tuple2<String, Integer> map(String e) throws Exception {
        return Tuple2.of(e, 1);
    }
}).slotSharingGroup("default");
//将数据按照单词进行分区
KeyedStream<Tuple2<String, Integer>, String> keyedStream = wordAndOne.keyBy(new KeySelector<Tuple2<String, Integer>, String>() {
    @Override
    public String getKey(Tuple2<String, Integer> tp) throws Exception {
        return tp.f0;
    }
});
SingleOutputStreamOperator<Tuple2<String, Integer>> sum = keyedStream.sum(1);//将同一个组呢的次数进行sum
sum.print();
env.execute("StreamWordCount");
```

![](<images/01 Flink基础 -diagram-6.png>)



提交到集群中运行，集群中有4个槽，该程序的并行度最多只能设置为2.
