make stream processing easier!!!

> 一个神奇的框架,让流处理更简单



# 1 StreamPark简介

## 1.1 什么是StreamPark

实时即未来,在实时处理流域 `Apache Spark` 和 `Apache Flink` 是一个伟大的进步,尤其是`Apache Flink`被普遍认为是下一代大数据流计算引擎, 我们在使用 `Flink` & `Spark` 时发现从编程模型, 启动配置到运维管理都有很多可以抽象共用的地方, 我们将一些好的经验固化下来并结合业内的最佳实践, 通过不断努力终于诞生了今天的框架 —— `StreamPark`, 项目的初衷是 —— 让流处理更简单, 使用`StreamPark`开发,可以极大降低学习成本和开发门槛, 让开发者只用关心最核心的业务,`StreamPark` 规范了项目的配置,鼓励函数式编程,定义了最佳的编程方式,提供了一系列开箱即用的`Connectors`,标准化了配置、开发、测试、部署、监控、运维的整个过程, 提供了`scala`和`java`两套api, 其最终目的是打造一个一站式大数据平台,流批一体,湖仓一体的解决方案。



## 1.2 StreamPark的Features



* 开发脚手架

* 多版本Flink支持(1.11、1.12、1.13、1.14、1.15)

* 一系列开箱即用的connectors

* 支持项目编译功能(maven 编译)

* 在线参数配置

* 支持`Application` 模式, `Yarn-Per-Job`模式启动

* 快捷的日常操作(任务`启动`、`停止`、`savepoint`以及从`savepoint`恢复)

* 支持火焰图

* 支持`notebook`(在线任务开发)

* 项目配置和依赖版本化管理

* 支持任务备份、回滚(配置回滚)

* 在线管理依赖(maven pom)和自定义jar

* 自定义udf、连接器等支持

* Flink SQL WebIDE

* 支持catalog、hive

* 任务运行失败发送告警邮件（支持钉钉、微信、邮件、飞书等）

* 支持失败重启重试

* 从任务`开发`阶段到`部署管理`全链路支持



## 1.3 StreamPark的组成部分和架构



`StreamPark`有三部分组成,分别是`streampark-core`,`streampark-pump` 和 `streampark-console`



![](<images/07 StreamPark-streampark_archite-8cf7c6f5a116c753f8d9bb546eef06fa.png>)



### 1️⃣ streampark-core

`streampark-core` 定位是一个开发时框架,关注编码开发,规范了配置文件,按照约定优于配置的方式进行开发,提供了一个开发时 `RunTime Content`和一系列开箱即用的`Connector`,扩展了`DataStream`相关的方法,融合了`DataStream`和`Flink sql` api,简化繁琐的操作,聚焦业务本身,提高开发效率和开发体验

### 2️⃣ streampark-pump

`pump` 是抽水机,水泵的意思,`streampark-pump`的定位是一个数据抽取的组件,类似于`flinkx`,基于`streampark-core`中提供的各种`connector`开发,目的是打造一个方便快捷,开箱即用的大数据实时数据抽取和迁移组件,并且集成到`streampark-console`中,解决实时数据源获取问题,目前在规划中

### 3️⃣ streampark-console

`streampark-console` 是一个综合实时数据平台,低代码(`Low Code`)平台,可以较好的管理`Flink`任务,集成了项目编译、发布、参数配置、启动、`savepoint`,火焰图(`flame graph`),`Flink SQL`, 监控等诸多功能于一体,大大简化了`Flink`任务的日常操作和维护,融合了诸多最佳实践。旧时王谢堂前燕,飞入寻常百姓家,让大公司有能力研发使用的项目,现在人人可以使用, 其最终目标是打造成一个实时数仓,流批一体的一站式大数据解决方案,该平台使用但不仅限以下技术:

* [<span style="color: inherit; background-color: rgb(187,191,196)">Apache Flink</span>](http://flink.apache.org/)

* [<span style="color: inherit; background-color: rgb(187,191,196)">Apache YARN</span>](http://hadoop.apache.org/)

* [<span style="color: inherit; background-color: rgb(187,191,196)">Spring Boot</span>](https://spring.io/projects/spring-boot/)

* [<span style="color: inherit; background-color: rgb(187,191,196)">Mybatis</span>](http://www.mybatis.org/)

* [<span style="color: inherit; background-color: rgb(187,191,196)">Mybatis-Plus</span>](http://mp.baomidou.com/)

* [<span style="color: inherit; background-color: rgb(187,191,196)">Flame Graph</span>](http://www.brendangregg.com/FlameGraphs)

* [<span style="color: inherit; background-color: rgb(187,191,196)">JVM-Profiler</span>](https://github.com/uber-common/jvm-profiler)

* [<span style="color: inherit; background-color: rgb(187,191,196)">Vue</span>](https://cn.vuejs.org/)

* [<span style="color: inherit; background-color: rgb(187,191,196)">VuePress</span>](https://vuepress.vuejs.org/)

* [<span style="color: inherit; background-color: rgb(187,191,196)">Ant Design of Vue</span>](https://antdv.com/)

* [<span style="color: inherit; background-color: rgb(187,191,196)">ANTD PRO VUE</span>](https://pro.antdv/)

* [<span style="color: inherit; background-color: rgb(187,191,196)">xterm.js</span>](https://xtermjs.org/)

* [<span style="color: inherit; background-color: rgb(187,191,196)">Monaco Editor</span>](https://microsoft.github.io/monaco-editor/)



# 2 StreamPark的安装部署



## 2.1 环境要求

> 注意 StreamPark 1.2.2之前(包含)的版本,只支持`scala 2.11`,切忌使用`flink`时要检查对应的`scala`版本 1.2.3之后(包含)的版本,支持 `scala 2.11` 和 `scala 2.12` 两个版本
>
> 目前 StreamPark 对 Flink 的任务发布，同时支持 `Flink on YARN` 和 `Flink on Kubernetes` 两种模式。



* Hadoop

使用 `Flink on YARN`，需要部署的集群安装并配置 Hadoop的相关环境变量，如你是基于 CDH 安装的 hadoop 环境， 相关环境变量可以参考如下配置:

```shell
export HADOOP_HOME=/opt/apps/hadoop-3.2.1
export HADOOP_CONF_DIR=/etc/hadoop/conf
export HIVE_HOME=$HADOOP_HOME/../hive
export HBASE_HOME=$HADOOP_HOME/../hbase
export HADOOP_HDFS_HOME=$HADOOP_HOME/../hadoop-hdfs
export HADOOP_MAPRED_HOME=$HADOOP_HOME/../hadoop-mapreduce
export HADOOP_YARN_HOME=$HADOOP_HOME/../hadoop-yarn
```



## 2.2 部署后端

### 2.2.1 下载安装包

下载地址：https://github.com/apache/incubator-streampark/releases

下载最新StreamPark的安装包streamx-console-service\_2.12-1.2.3.tar.gz ,解包后安装目录如下：

```shell
streampark-console-service-1.2.1
├── bin
│    ├── flame-graph
│    ├──   └── *.py                           //火焰图相关功能脚本 ( 内部使用，用户无需关注 )
│    ├── startup.sh                           //启动脚本
│    ├── setclasspath.sh                      //java 环境变量相关的脚本 ( 内部使用，用户无需关注 )
│    ├── shutdown.sh                          //停止脚本
│    ├── yaml.sh                              //内部使用解析 yaml 参数的脚本 ( 内部使用，用户无需关注 )
├── conf
│    ├── application.yaml                     //项目的配置文件 ( 注意不要改动名称 )
│    ├── flink-application.template           //flink 配置模板 ( 内部使用，用户无需关注 )
│    ├── logback-spring.xml                   //logback
│    └── ...
├── lib
│    └── *.jar                                //项目的 jar 包
├── plugins
│    ├── streampark-jvm-profiler-1.0.0.jar       //jvm-profiler,火焰图相关功能 ( 内部使用，用户无需关注 )
│    └── streampark-flink-sqlclient-1.0.0.jar    //Flink SQl 提交相关功能 ( 内部使用，用户无需关注 )
├── script
│     ├── schema                               // 完整的ddl建表sql
│     ├── data                               // 完整的dml插入数据sql
│     ├── upgrade                             // 每个版本升级部分的sql(只记录从上个版本到本次版本的sql变化)
├── logs                                      //程序 log 目录

├── temp                                      //内部使用到的临时路径，不要删除
```



### 2.2.2 初始化数据库

StreamPark需要将一些数据保存到外部的数据库中，通常使用MySQL，所以先要在MySQL中窗口对应的DataBase并初始化相应的表。



①创建DataBase

使用root用户登录mysql，并执行下面的命令

```sql
create database if not exists `streampark` character set utf8mb4 collate utf8mb4_general_ci;
```



②创建用户并复用权限（也可以直接使用root用户）



```sql
create user 'streampark'@'%' IDENTIFIED WITH mysql_native_password by 'streampark';
grant ALL PRIVILEGES ON streampark.* to 'streampark'@'%';
flush privileges;
```

如果创建用户时，密码有安全要求，可以增加密码的复杂度，或执行下面的命令修改密码安全级别

```sql
set global validate_password_policy=LOW;
set global validate_password_length=6;
```



③ 初始化StreamPark的表结构(在mysql中执行)

```sql
use streampark;
source /opt/apps/streampark-2.1.4/script/schema/mysql-schema.sql
source /opt/apps/streampark-2.1.4/script/data/mysql-data.sql
```



### 2.2.3 修改配置文件

修改安装包下conf目录的config.yml

```yaml
#
# Licensed to the Apache Software Foundation (ASF) under one or more
# contributor license agreements.  See the NOTICE file distributed with
# this work for additional information regarding copyright ownership.
# The ASF licenses this file to You under the Apache License, Version 2.0
# (the "License"); you may not use this file except in compliance with
# the License.  You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

logging:
  level:
    root: info

server:
  port: 10000
  session:
    # The user's login session has a validity period. If it exceeds this time, the user will be automatically logout
    # unit: s|m|h|d, s: second, m:minute, h:hour, d: day
    ttl: 2h # unit[s|m|h|d], e.g: 24h, 2d....
  undertow: # see: https://github.com/undertow-io/undertow/blob/master/core/src/main/java/io/undertow/Undertow.java
    buffer-size: 1024
    direct-buffers: true
    threads:
      io: 16
      worker: 256

# system database, default h2, mysql|pgsql|h2
datasource:
  dialect: mysql  #h2, mysql, pgsql
  # if datasource.dialect is mysql or pgsql, you need to configure the following connection information
  # mysql/postgresql connect user
  username: streampark
  # mysql/postgresql connect password
  password: streampark
  # mysql/postgresql connect jdbcURL
  url: jdbc:mysql://linux01:3306/streampark?useUnicode=true&characterEncoding=UTF-8&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=GMT%2B8
  # postgresql example: jdbc:postgresql://localhost:5432/streampark?stringtype=unspecified
  

streampark:
  workspace:
    # Local workspace, storage directory of clone projects and compiled projects,Do not set under $APP_HOME. Set it to a directory outside of $APP_HOME.
    local: /tmp/streampark
    # The root hdfs path of the jars, Same as yarn.provided.lib.dirs for flink on yarn-application and Same as --jars for spark on yarn
    remote: hdfs://linux01:8020/streampark/
  proxy:
    # lark proxy address, default https://open.feishu.cn
    lark-url:
    # hadoop yarn proxy path, e.g: knox process address https://streampark.com:8443/proxy/yarn
    yarn-url:
  yarn:
    # flink on yarn or spark on yarn, monitoring job status from yarn, it is necessary to set hadoop.http.authentication.type
    http-auth: 'simple'  # default simple, or kerberos
  # flink on yarn or spark on yarn, HADOOP_USER_NAME
  hadoop-user-name: hdfs
  project:
    # Number of projects allowed to be running at the same time , If there is no limit, -1 can be configured
    max-build: 16

# flink on yarn or spark on yarn, when the hadoop cluster enable kerberos authentication, it is necessary to set Kerberos authentication parameters.
security:
  kerberos:
    login:
      debug: false
      enable: false
      keytab:
      krb5:
      principal:
    ttl: 2h # unit [s|m|h|d]

# sign streampark with ldap.
ldap:
  base-dn: dc=streampark,dc=com  # Login Account
  enable: false  # ldap enabled'
  username: cn=Manager,dc=streampark,dc=com
  password: streampark
  urls: ldap://99.99.99.99:389 #AD server IP, default port 389
  user:
    email-attribute: mail
    identity-attribute: uid

```



### 2.2.4 启动StreamPark服务

进入到StreamPark的安装包内，执行startup.sh

```sql
 bin/startup.sh 
```

> 如果启动失败，可以查看logs目录下的error.yyyy-MM-dd.log
>
> 如果使用的是mysql8.x，通常会报如下的错误：
>
> Caused by: java.sql.SQLNonTransientConnectionException: Public Key Retrieval is not allowed
>
> 需要修改安装包下conf目录的application.yml的数据库连接驱动
>
> <span style="color: rgb(143,149,158); background-color: inherit">&amp;</span>**<span style="color: rgb(143,149,158); background-color: inherit">allowPublicKeyRetrieval=true</span>**
>
>





### 2.2.5 使用浏览器登录

StreamPark安装节点的主机名后ip，端口默认是10000



![](<images/07 StreamPark-QQ20221210-132552@2x.png>)



用户名：admin

密    码：<span style="color: inherit; background-color: rgb(255,233,40)">streamx</span>



![](<images/07 StreamPark-QQ20221210-132619@2x.png>)



# 3 部署运行flink程序

## 3.1 添加FlinkHome

![](<images/07 StreamPark-QQ20221210-133832@2x.png>)



## 3.2 设置Maven参数

建议在安装StreamPark的机器上先安装maven，最好是maven的版本是3.6，并配置阿里云maven的镜像，即在setings.xml的<span style="color: inherit; background-color: rgb(255,233,40)">mirrors</span>标签下添加如下内容：

```xml
<mirror>
  <id>alimaven</id>
  <name>aliyun maven</name>
  <url>http://maven.aliyun.com/nexus/content/groups/public/</url>
  <mirrorOf>central</mirrorOf>
</mirror>
```



## 3.3 新建项目工程

![](<images/07 StreamPark-QQ20221210-135051@2x.png>)



添加项目相关的参数

![](<images/07 StreamPark-QQ20221210-141208@2x.png>)







## 3.4 新建Flink Application



![](<images/07 StreamPark-QQ20221210-135548@2x.png>)



```shell
hdfs dfs -mkdir /streampark
hdfs dfs -chown -R hdfs:supergroup /streampark
```
