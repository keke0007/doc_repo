```scala
在工作中,数据的处理场景 , 一种是离线处理 ,一种是实施处理!
- 离线(数据)处理 : 数据已经产生且持久化到磁盘 , 对数据进行分析, 会得到一个具体的确定的结果
- 实时(数据)处理 : 数据源源不断的产生, 即席对数据进行计算 , 结算的结果仅是此时的结果 ,随着时间的推移会有新的数据产生,会计算出新的结果
```

# 1. <span style="color: rgb(31,35,41); background-color: inherit">快速认识flink</span>

Apache Flink是一个分布式计算引擎(框架)，<span style="color: inherit; background-color: rgba(183,237,177,0.8)">用于无界(实时)和有界数据流(批)的有</span>**<span style="color: rgb(216,57,49); background-color: rgba(183,237,177,0.8)">状态</span>**<span style="color: inherit; background-color: rgba(183,237,177,0.8)">计算</span>。Flink被设计成可以在所有常见的集群环境中运行 , 基于内存的分布式计算引擎  ,适用于任何数据规模的(实时)计算场景。

## 1.1 <span style="color: rgb(31,35,41); background-color: inherit">离线(批)计算与实时(流)式计算</span>

<span style="color: rgb(31,35,41); background-color: rgb(98,210,86)"> </span> <u><span style="color: rgb(31,35,41); background-color: inherit">批计算与流式计算，本质上就是对有界流和无界流的计算</span></u>

**无界流**有一个开始但没有定义的结束。它们不会在数据生成时终止并提供数据。无界流必须连续处理，即事件必须在摄取(ingest)后立即处理。不可能等待所有输入数据到达，因为输入是无界的，不会在任何时间点完成(结果实时更新)。处理无限数据通常需要按特定顺序摄取事件，例如事件发生的顺序，以便能够推断结果的完整性。

**有界流**有定义的开始和结束。可以通过在执行任何计算之前摄取所有数据来处理有界流。处理有界流不需要有序摄取，因为有界数据集总是可以排序的。有界流的处理也称为批处理。

![](images/[多易教育]-Flink-1.16.1文档-image3.png)

* **<span style="color: rgb(31,35,41); background-color: inherit">批计算</span>**

<span style="color: rgb(31,35,41); background-color: rgba(222,224,227,0.8)">针对有界流；</span> <span style="color: rgb(31,35,41); background-color: inherit">由于在产出计算结果前可以看到整个（完整）数据集，因而如下计算都可以实现：对数据排序，计算全局统计值，对输入数据的整体产出最终汇总聚合报表；</span>

* **<span style="color: rgb(31,35,41); background-color: inherit">流计算</span>**

<span style="color: rgb(31,35,41); background-color: rgba(222,224,227,0.8)">针对无界流；</span> <span style="color: rgb(31,35,41); background-color: inherit">由于永远无法看到输入数据的整体（数据的输入永远无法结束），只能每逢数据到达就进行计算，并输出&quot;当时&quot;的计算结果（</span> <u><span style="color: rgb(31,35,41); background-color: inherit">因而计算结果也不会是一个一次性的最终结果，而是源源不断的无界的结果流</span></u> <span style="color: rgb(31,35,41); background-color: inherit">）；</span>

## 1.2 <span style="color: rgb(31,35,41); background-color: inherit">Flink基本概念</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 一个分布式、有状态的实时流式处理系统（编程框架）</span>**

![](images/[多易教育]-Flink-1.16.1文档-image4.png)

*<span style="color: rgb(31,35,41); background-color: inherit">Flink 主要使用</span>**<span style="color: rgb(31,35,41); background-color: inherit">java</span>**<span style="color: rgb(31,35,41); background-color: inherit">语言开发而成，但对用户提供了</span>**<span style="color: rgb(31,35,41); background-color: inherit">java</span>**<span style="color: rgb(31,35,41); background-color: inherit">、scala、python编程api ,建议使用java语言开发 ;</span>*

*<span style="color: rgb(31,35,41); background-color: inherit">Flink 以流处理方式作为基础的世界观，并通过引入有界流来实现批计算，从而实现</span>**<span style="color: rgb(31,35,41); background-color: inherit">流批一体 ;</span>***

## 1.3 <span style="color: rgb(31,35,41); background-color: inherit">Flink的运行时架构</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 核心架构角色</span>**

![](images/[多易教育]-Flink-1.16.1文档-image5.png)

<span style="color: rgb(31,35,41); background-color: inherit">Flink 集群采取 Master - Slave 架构：</span>

* <span style="color: rgb(31,35,41); background-color: inherit">Master 的角色为 JobManager，负责集群和作业管理；  </span>

* <span style="color: rgb(31,35,41); background-color: inherit">Slave 的角色是 TaskManager，负责执行计算任务；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">客户端 Client 负责作业初始化和提交Job，</span>

* <span style="color: rgb(31,35,41); background-color: inherit">JobManager 和 TaskManager 是集群的进程；</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 各角色主要职责说明</span>**

<span style="color: rgb(31,35,41); background-color: inherit">（1）Client</span>

<span style="color: rgb(31,35,41); background-color: inherit">Flink 客户端是 F1ink 提供的 CLI 命令行工具，用来提交 Flink 作业到 Flink 集群，在客户端中负责 StreamGraph (流图)和 Job Graph (作业图)的构建。 (代码编程 , 提交job , (工作图))</span>

<span style="color: rgb(31,35,41); background-color: inherit">（2）JobManager</span>

<span style="color: rgb(31,35,41); background-color: inherit">JobManager根据并行度将Flink客户端提交的Flink应用分解为子任务，从资源管理器 ResourceManager 申请所需的计算资源，资源具备之后，开始分发任务到TaskManager 执行 SubTask，并负责应用容错，跟踪作业的执行状态，发现异常则恢复作业等。</span>

<span style="color: rgb(31,35,41); background-color: inherit">（3）TaskManager</span>

<span style="color: rgb(31,35,41); background-color: inherit">TaskManager 接收 JobManager 分发的</span>**<span style="color: rgb(31,35,41); background-color: inherit">子任务</span>**<span style="color: rgb(31,35,41); background-color: inherit">，根据自身的资源情况 管理子任务的启动,状态、 停止、销毁、异常恢复等生命周期阶段。Flink 程序中必须有一个TaskManager。</span>

## 1.4 <span style="color: rgb(31,35,41); background-color: inherit">Flink的特性</span>

![](images/[多易教育]-Flink-1.16.1文档-image.png)

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span> <u><span style="color: rgb(31,35,41); background-color: inherit">适用于几乎所有的流式数据处理场景</span></u>**

事件驱动的应用程序是一种有状态的应用程序，它从一个或多个事件流中摄取事件，并通过触发计算、状态更新或外部操作来对传入的事件做出反应。

事件驱动的应用程序是传统应用程序设计的演变，具有分离的计算和数据存储层。在此体系结构中，应用程序从远程事务数据库读取数据并将数据保存到远程事务数据库。

相反，事件驱动的应用程序是基于有状态的流处理应用程序。在此设计中，数据和计算位于同一位置，从而产生本地（内存或磁盘）数据访问。容错是通过定期将检查点写入远程持久存储来实现的。下图描述了传统应用程序架构和事件驱动应用程序之间的区别。

![](images/[多易教育]-Flink-1.16.1文档-image-1.png)

![](images/[多易教育]-Flink-1.16.1文档-image-2.png)

提取-转换-加载 (ETL) 是一种在存储系统之间转换和移动数据的常用方法。通常会定期触发 ETL 作业，将数据从事务数据库系统复制到分析数据库或数据仓库。

数据管道的用途与 ETL 作业类似。它们转换和丰富数据，并将其从一个存储系统移动到另一个存储系统。然而，它们以连续流模式运行，而不是定期触发。因此，他们能够从不断产生数据的源读取记录，并将其以低延迟移动到目的地。例如，数据管道可能会监视文件系统目录中的新文件并将其数据写入事件日志。另一个应用程序可能会将事件流具体化到数据库或逐步构建和细化搜索索引。

![](images/[多易教育]-Flink-1.16.1文档-image-3.png)

**<span style="color: inherit; background-color: rgba(98,210,86,1)">  </span> <u><span style="color: inherit; background-color: rgba(98,210,86,1)">自带状态管理机制</span></u>**

![](images/[多易教育]-Flink-1.16.1文档-image7.png)



**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span> <u><span style="color: rgb(31,35,41); background-color: inherit">强大的准确性保证</span></u>**

* <span style="color: rgb(31,35,41); background-color: inherit">exactly-once 状态一致性</span>

* <span style="color: rgb(31,35,41); background-color: inherit">事件时间处理</span>

* <span style="color: rgb(31,35,41); background-color: inherit">专业的迟到数据处理</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span> <u><span style="color: rgb(31,35,41); background-color: inherit">灵活丰富的多层api</span></u>**

* <span style="color: rgb(31,35,41); background-color: inherit">流、批数据之上的SQL查询</span>

* <span style="color: rgb(31,35,41); background-color: inherit">流、批数据之上的TableApi</span>

* <span style="color: rgb(31,35,41); background-color: inherit">datastream流处理算子api , dataset批处理算子api</span>

* <span style="color: rgb(31,35,41); background-color: inherit">精细可控的processFunction</span>

![](images/[多易教育]-Flink-1.16.1文档-image-4.png)

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span> <u><span style="color: rgb(31,35,41); background-color: inherit">规模弹性扩展</span></u>**

* <span style="color: rgb(31,35,41); background-color: inherit">可扩展的分布式架构（集群级别的资源规模灵活配置，算子粒度的独立并行度灵活配置）</span>

* <span style="color: rgb(31,35,41); background-color: inherit">支持超大状态管理</span>

* <span style="color: rgb(31,35,41); background-color: inherit">增量checkpoint机制</span>

![](images/[多易教育]-Flink-1.16.1文档-image9.png)

**<span style="color: rgb(216,57,49); background-color: inherit">算子粒度的独立并行度灵活配置（集群槽位资源可扩展，算子任务实例可扩展）</span>**

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span> <u><span style="color: rgb(31,35,41); background-color: inherit">强大的运维能力</span></u>**

* <span style="color: rgb(31,35,41); background-color: inherit">弹性实施部署机制</span>

* <span style="color: rgb(31,35,41); background-color: inherit">高可用配置</span>

* <span style="color: rgb(31,35,41); background-color: inherit">保存点恢复机制</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span> <u><span style="color: rgb(31,35,41); background-color: inherit">优秀的性能</span></u>**

* <span style="color: rgb(216,57,49); background-color: inherit">低延迟</span>

* <span style="color: rgb(216,57,49); background-color: inherit">高吞吐</span>

* <span style="color: rgb(31,35,41); background-color: inherit">内存计算</span>

有状态 Flink 应用程序针对本地状态访问进行了优化。任务状态始终保存在内存中，或者，如果状态大小超过可用内存，则保存在访问高效的磁盘数据结构中。因此，任务通过访问本地（通常是内存中的）状态来执行所有计算，从而产生非常低的处理延迟。Flink 通过定期和异步地将本地状态检查点到持久存储来保证在发生故障时恰好一次的状态一致性。

## 1.5 <span style="color: rgb(31,35,41); background-color: inherit">flink的编程抽象  DataStream</span>

DataStream是flink编程的核心抽象 , 将数据流转换成<span style="color: rgb(31,35,41); background-color: inherit">DataStream , 后续的可以在DS上调用方法对数据进行编程 , 底层可以分布式运行 ! [计算逻辑,  并行]</span>

* <span style="color: rgb(31,35,41); background-color: inherit">DataStream代表一个数据流，</span> <u><span style="color: rgb(31,35,41); background-color: inherit">它可以是无界的，也可以是有界的</span></u> <span style="color: rgb(31,35,41); background-color: inherit">；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">DataStream类似于spark的rdd，它是不可变的（immutable）；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">无法对一个datastream进行自由的添加或删除或修改元素；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">只能通过算子对datastream中的数据进行转换，将一个datastream转成另一个datastream；</span>

* <span style="color: rgb(216,57,49); background-color: inherit">Datastream可以通过source算子加载</span> <span style="color: rgb(31,35,41); background-color: inherit">、映射外部数据而来；或者从已存在的datastream转换而来</span>

* DataStream是flink实现分布式计算的基础抽象对象

## 1.6 <span style="color: rgb(31,35,41); background-color: inherit">flink编程模板</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 无论简单与复杂，flink程序都由如下几个部分组成</span>**

* <span style="color: rgb(31,35,41); background-color: inherit">获取一个编程、执行入口环境env</span>

* <span style="color: rgb(31,35,41); background-color: inherit">通过数据源组件，加载、创建datastream</span>

* <span style="color: rgb(31,35,41); background-color: inherit">对datastream调用各种处理算子表达计算逻辑</span>

* <span style="color: rgb(31,35,41); background-color: inherit">通过sink算子指定计算结果的输出方式</span>

* <span style="color: rgb(31,35,41); background-color: inherit">在env上触发程序提交运行</span>

### 1.6.1 添加依赖

```xml
<properties>
    <maven.compiler.source>8</maven.compiler.source>
    <maven.compiler.target>8</maven.compiler.target>
    <flink.version>1.16.1</flink.version>
    <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
</properties>

  <dependencies>
        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-java</artifactId>
            <version>${flink.version}</version>
        </dependency>
        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-streaming-java</artifactId>
            <version>${flink.version}</version>
        </dependency>
        <!--flink本地运行时 提供的web功能-->
        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-runtime-web</artifactId>
            <version>${flink.version}</version>
        </dependency>

        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-table-api-java</artifactId>
            <version>${flink.version}</version>
        </dependency>

        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-table-common</artifactId>
            <version>${flink.version}</version>
        </dependency>

        <dependency>
            <groupId>org.apache.commons</groupId>
            <artifactId>commons-compress</artifactId>
            <version>1.21</version>
        </dependency>
        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-table-planner_2.12</artifactId>
            <version>${flink.version}</version>
        </dependency>
        <!-- flinksql本地运行需要的依赖 -->
        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-clients</artifactId>
            <version>${flink.version}</version>
        </dependency>
<!--状态后端管理器-->
        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-statebackend-rocksdb</artifactId>
            <version>${flink.version}</version>
        </dependency>

        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <version>1.18.26</version>
        </dependency>

        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-csv</artifactId>
            <version>${flink.version}</version>
        </dependency>

        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-parquet</artifactId>
            <version>${flink.version}</version>
        </dependency>
        <dependency>
            <groupId>org.apache.parquet</groupId>
            <artifactId>parquet-avro</artifactId>
            <version>1.11.1</version>
        </dependency>

        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-avro</artifactId>
            <version>${flink.version}</version>
        </dependency>
        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-json</artifactId>
            <version>${flink.version}</version>
        </dependency>

        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-connector-kafka</artifactId>
            <version>${flink.version}</version>
        </dependency>

        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-connector-files</artifactId>
            <version>${flink.version}</version>
        </dependency>
        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-connector-hbase-2.2</artifactId>
            <version>${flink.version}</version>
        </dependency>
        <dependency>
            <groupId>org.apache.doris</groupId>
            <artifactId>flink-doris-connector-1.16</artifactId>
            <version>1.3.0</version>
        </dependency>
        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-connector-jdbc</artifactId>
            <version>${flink.version}</version>
        </dependency>
        <dependency>
            <groupId>com.ververica</groupId>
            <artifactId>flink-connector-mysql-cdc</artifactId>
            <version>2.3.0</version>
        </dependency>
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>8.0.30</version>
        </dependency>
        <dependency>
            <groupId>redis.clients</groupId>
            <artifactId>jedis</artifactId>
            <version>4.3.1</version>
        </dependency>
        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-connector-hive_2.12</artifactId>
            <version>1.16.1</version>
        </dependency>
        <dependency>
            <groupId>org.apache.hive</groupId>
            <artifactId>hive-exec</artifactId>
            <version>3.1.0</version>
            <exclusions>
                <exclusion>
                    <artifactId>hadoop-hdfs</artifactId>
                    <groupId>org.apache.hadoop</groupId>
                </exclusion>
            </exclusions>
        </dependency>
        <!--hadoop -->
        <dependency>
            <groupId>org.apache.hadoop</groupId>
            <artifactId>hadoop-common</artifactId>
            <version>3.1.0</version>
        </dependency>

        <dependency>
            <groupId>org.apache.hadoop</groupId>
            <artifactId>hadoop-client</artifactId>
            <version>3.1.0</version>
        </dependency>

        <dependency>
            <groupId>org.apache.hadoop</groupId>
            <artifactId>hadoop-hdfs</artifactId>
            <version>3.1.0</version>
        </dependency>

        <!-- 打印日志的jar包 -->
        <dependency>
            <groupId>org.slf4j</groupId>
            <artifactId>slf4j-log4j12</artifactId>
            <version>1.7.30</version>
        </dependency>

        <dependency>
            <groupId>log4j</groupId>
            <artifactId>log4j</artifactId>
            <version>1.2.16</version>
        </dependency>
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>fastjson</artifactId>
            <version>1.2.83</version>
        </dependency>
        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-cep</artifactId>
            <version>${flink.version}</version>
        </dependency>

        <dependency>
            <groupId>org.apache.flink</groupId>
            <artifactId>flink-sql-gateway-api</artifactId>
            <version>${flink.version}</version>
        </dependency>
    </dependencies>
```

### 1.6.2 入门示例

加载网络数据流 , 累计统计单词出现的次数

```java
package com.doit.day01;


import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

/**
 * @Date: 2023/6/23
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 * flink可以流式处理数据
 *    源源不断地接收网络流数据  , 统计数据中每个单词出现的次数
 *    实时打印结果在控制台
 */
public class StreamWordCount {
    public static void main(String[] args) throws Exception {
        // 1 获取flink的编程环境
        //  可以做到  流批一体的处理方案
        StreamExecutionEnvironment see = StreamExecutionEnvironment.getExecutionEnvironment();
        // 2 获取网络数据流    DataStream  (Source)
        //   通过  yum install nc -y 在linux上安装 nc工具    nc -lk 端口号
        // 使用 socket网络流 客户端发送数据   接收数据   在linux上使用 
        // socketTextStream 可以接收指定机器 指定端口发过来的数据
        // 源源不断地接收到数据  一行一行
        DataStreamSource<String> ds = see.socketTextStream("doitedu01", 8899);
        // 3 处理数据   统计单词出现的次数   (Transformation)
        // 3.1  将数据组装成 单词,1  二元组  Tuple2
        SingleOutputStreamOperator<Tuple2<String, Integer>> wrodOne = ds.flatMap(new FlatMapFunction<String, Tuple2<String, Integer>>() {
            // 参数1   一行数据  参数2  收集结果
            @Override
            public void flatMap(String line, Collector<Tuple2<String, Integer>> out) throws Exception {
                String[] words = line.split("\\s+");
                for (String word : words) {
                    // 以后 在使用某个对象的时候 先不new 优先调用一下有没有静态方法
                    Tuple2<String, Integer> tp = Tuple2.of(word, 1);
                    out.collect(tp);
                }
            } // 泛型1   输入的数据类型  泛型2  输出的结果
        });
        // 3.2 按照单词分组
        KeyedStream<Tuple2<String, Integer>, String> keyed = wrodOne.keyBy(new KeySelector<Tuple2<String, Integer>, String>() {
            @Override
            public String getKey(Tuple2<String, Integer> value) throws Exception {
                return value.f0;
            }
        });
        // 3.3 统计单词个数
        SingleOutputStreamOperator<Tuple2<String, Integer>> res = keyed.sum("f1");
        // 4 将结果打印在控制台    (sink)
        res.print() ;
        // 5 出发程序执行
        see.execute("流式单词统计") ;

    }
}
```

使用<span style="color: inherit; background-color: rgba(255,246,122,0.8)">lambda</span>表达式实现

```java
package com.doit.day01;


import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

/**
 * @Date: 2023/9/2
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: 数据流上调用算子  ,
 * ds1.方法(new  xxxFunction(){})
 * 如果使用 lambda  吧表达式实现抽象方法
 * 注意返回值类型  ,最好使用returns明确返回值的数据类型
 */
public class F02Demo02 {
    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment see = StreamExecutionEnvironment.getExecutionEnvironment();
        DataStreamSource<String> ds1 = see.socketTextStream("doitedu01", 8899);

        //  SingleOutputStreamOperator<String> res = ds1.map(line ->  line.toUpperCase());
        // SingleOutputStreamOperator<String> res = ds1.map(String::toUpperCase);

      /*  ds1.flatMap(( String  line, Collector<String> out)->{
            String[] words = line.split("\\s+");
            for (String word : words) {
                out.collect(word);  // 收集的数据  没有泛型标记
            }
        }).returns(TypeInformation.of(new TypeHint<String>() {}))
           .returns(TypeInformation.of(String.class))
           .returns(new TypeHint<String>() {})
           .returns(String.class) ;  // 底层在编译时  收集数据的数据类型  String会被擦除 , 就不知道收集的数据类型
*/

        // 第一步 ;
     /*   SingleOutputStreamOperator<String> res = ds1.flatMap((String line, Collector<String> out) -> {
            String[] words = line.split("\\s+");
            for (String word : words) {
                out.collect(word);
            }
        }).returns(new TypeHint<String>() {});*/
        // 第二步
        SingleOutputStreamOperator<Tuple2<String, Integer>> resTp2 = ds1.flatMap((String line, Collector<Tuple2<String, Integer>> out) -> {
            String[] words = line.split("\\s+");
            for (String word : words) {
                Tuple2<String, Integer> tp2 = Tuple2.of(word, 1);
                out.collect(tp2);
            }
        }).returns(new TypeHint<Tuple2<String, Integer>>() {
        });

        resTp2.keyBy(tp -> tp.f0).sum("f1").print();

        // resTp2.print() ;
        see.execute();

    }
}
```

# 2. Flink编程基础

## 2.1 <span style="color: rgb(31,35,41); background-color: inherit">flink程序的并行概念</span>

在 Apache Flink 中，"并行度"（<span style="color: rgb(216,57,49); background-color: inherit">Parallelism</span>）是指执行 Flink 作业时并行处理任务的程度或并发度。它决定了作业在 Flink 集群中的资源分配和任务执行的方式。

在 Flink 中，<span style="color: rgb(46,161,33); background-color: inherit">有两种类型的并行度</span>，分别是工作<span style="color: rgb(216,57,49); background-color: inherit">并行度</span>（Task Parallelism）和<span style="color: rgb(216,57,49); background-color: inherit">算子并行度</span>（Operator  \[Task] Parallelism）。

1. 工作并行度（Task Parallelism）：指的是整个 Flink 作业中并行执行的**任务数量**。每个任务会占用集群中的一个任务插槽（Task Slot），这些任务插槽通常由可用的计算资源（CPU、内存等）决定。任务并行度决定了整个作业的并发执行能力。

2. 算子并行度（Operator Parallelism）：指的是作业中每个算子（Operator）实例的并行度。算子是 Flink 作业中数据转换和处理的基本单元。**通过将数据流划分为多个并行的算子实例(subTask)**，可以实现对<span style="color: rgb(216,57,49); background-color: inherit">输入数据的分割和并行处理</span>。算子并行度决定了每个算子在集群中的并行执行能力。

这两种并行度的概念是相关联的，任务并行度是算子并行度的总和。例如，如果作业中有两个算子，并且每个算子的并行度都设置为 4，那么任务并行度将是 8。

![](images/[多易教育]-Flink-1.16.1文档-image-5.png)



> * <span style="color: rgb(31,35,41); background-color: inherit">f</span>**<span style="color: rgb(31,35,41); background-color: inherit">link程序中，每一个算子都可以成为一个独立任务（Task）；ds1 = data.falatMap  Task1[4]    ds2 =  ds.map()   Task2[6]</span>**
>
> * <span style="color: rgb(31,35,41); background-color: inherit">flink程序中，视上下游算子间数据分发规则、并行度、共享槽位设置，可组成算子链成为一个task</span>
>
> * <span style="color: rgb(31,35,41); background-color: inherit">每个任务在运行时都可拥有多个并行的运行实例（subTask）；</span>
>
> * <span style="color: rgb(31,35,41); background-color: inherit">且每个算子任务的并行度都可以在代码中显式设置；</span>

## 2.2 Flink编程入口

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 批处理计算入口</span>**

```java
ExecutionEnvironment env = ExecutionEnvironment.getExecutionEnvironment();
```

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 流式计算入口</span>**

```java
StreamExecutionEnvironment see = StreamExecutionEnvironment.getExecutionEnvironment();
```

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 流批一体入口</span>**

```java
// 批次 ,流式处理数据的环境对象
StreamExecutionEnvironment see = StreamExecutionEnvironment.getExecutionEnvironment();

//see.setRuntimeMode(RuntimeExecutionMode.STREAMING);  // 设置处理模式流
//see.setRuntimeMode(RuntimeExecutionMode.BATCH);

ExecutionConfig config = see.getConfig();
// 流式处理数据
config.setExecutionMode(ExecutionMode.PIPELINED);
// 批处理数据
config.setExecutionMode(ExecutionMode.BATCH); 
```

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 开启webui的本地运行环境</span>**

```java
// 在创建环境对象的时候,可以指定配置对象
// 要加入相应的依赖 : flink-runtime-web
Configuration conf = new Configuration();
conf.setInteger("rest.port" , 8088);
StreamExecutionEnvironment see2 = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf) ;
DataStreamSource<String> data = see2.socketTextStream("doitedu01", 8899);
data.print() ;
see2.execute("编程环境") ;
```

访问WEB界面      http://localhost:8088

![](images/[多易教育]-Flink-1.16.1文档-image-6.png)

## 2.3  基本source算子 (创建DataStream)

<span style="color: rgb(31,35,41); background-color: inherit">source是用来获取外部数据的算子，按照获取数据的方式，可以分为：</span>

* <span style="color: rgb(31,35,41); background-color: inherit">基于集合的Source</span>

* <span style="color: rgb(31,35,41); background-color: inherit">基于</span> <span style="color: rgb(216,57,49); background-color: inherit">Socket</span> <span style="color: rgb(31,35,41); background-color: inherit">网络端口的Source</span>

* <span style="color: rgb(31,35,41); background-color: inherit">基于文件的Source   </span>

* <span style="color: rgb(31,35,41); background-color: inherit">第三方Connector Source  </span> <span style="color: rgb(216,57,49); background-color: inherit">kafka</span>

* <span style="color: rgb(31,35,41); background-color: inherit">自定义Source五种。</span>

<span style="color: rgb(31,35,41); background-color: inherit">从并行度的角度，source又可以分为非并行的source和并行的source。</span>

* <span style="color: rgb(31,35,41); background-color: inherit">非并行source：并行度只能为1，即只有一个运行时实例，在读取大量数据时效率比较低，通常是用来做一些实验或测试，例如Socket Source；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">并行Source：并行度可以是1到多个，在计算资源足够的前提下，并行度越大，效率越高。例如Kafka Source；</span>

### 2.3.1 基于socket的单并行Sourc&#x65;**<span style="color: rgb(31,35,41); background-color: inherit">(单并行)</span>**

<span style="color: rgb(31,35,41); background-color: inherit">非并行的Source，通过socket通信来获取数据得到数据流；</span>

*<span style="color: rgb(31,35,41); background-color: inherit">该方法还有多个重载的方法，如：</span>*

*<span style="color: rgb(31,35,41); background-color: inherit">socketTextStream(String hostname, int port, String delimiter, long maxRetry)</span>*

*<span style="color: rgb(31,35,41); background-color: inherit">可以指定行分隔符和最大重新连接次数。</span>*

```java
package com.doit.day02;


import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * @Date: 2023/6/24
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 *        加载数据流(source)
 */
public class E03Source_Socket {
    public static void main(String[] args) throws Exception {
        // 获取编程环境
        Configuration conf = new Configuration();
        conf.setInteger("rest.port" , 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        /**
         * 获取数据流 : 获取数据流以后  一定要处理
         *   1 网络流  socket  测试使用
         *        -  单并行的数据流  但并行source
         */
        DataStreamSource<String> ds1 = see.socketTextStream("doitedu01", 8899);
        int parallelism = ds1.getParallelism();
        System.out.println("网络数据流的并行度是 :  "+  parallelism);
        // 多并行输出数据到控制台 可以通过 方法设置并行度
        ds1.print().setParallelism(12) ; // 每获取一条数据 打印一次
        see.execute("source") ;
    }
}
```

> <span style="color: rgb(31,35,41); background-color: inherit">提示：socketSource是一个非并行source，如果使用socketTextStream读取数据，在启动Flink程序之前，必须先启动一个Socket服务，为了方便，Mac或Linux用户可以在命令行终端输入nc -lk 8888启动一个Socket服务并在命令行中向该Socket服务发送数据。</span>



### 2.3.2 基于元素或集合的Source

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> fromElements(单并行)</span>**

<span style="color: rgb(31,35,41); background-color: inherit">非并行的Source，可以将一到多个数据作为可变参数传入到该方法中，返回DataStreamSource。</span>

```java
// 获取编程环境
Configuration conf = new Configuration();
conf.setInteger("rest.port" , 8888);
StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
/**
 * 加载元素  测试
 *   单并行
 */
DataStreamSource<Integer> ds1 = see.fromElements(1, 2, 3, 4, 5, 6);
DataStreamSource<String> ds2 = see.fromElements("java" , "scala" , "sql" , "hive");
DataStreamSource<LogBean> ds3 = see.fromElements(
        LogBean.of(1L, "s001", "e001", 10000L),
        LogBean.of(2L, "s002", "e001", 20000L),
        LogBean.of(3L, "s003", "e001", 30000L)
);
```



**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> fromCollection(单并行)</span>**

<span style="color: rgb(31,35,41); background-color: inherit">非并行的Source，可以将一个Collection作为参数传入到该方法中，返回一个DataStreamSource。</span>

```java
/**
 * 集合转换成   DataStream
 *  单并行的  不能修改并行度
 */
List<Integer> numbers = Arrays.asList(1, 2, 3, 4);
List<LogBean> logs = Arrays.asList( LogBean.of(1L, "s001", "e001", 10000L),
        LogBean.of(2L, "s002", "e001", 20000L),
        LogBean.of(3L, "s003", "e001", 30000L));
DataStreamSource<Integer> ds4 = see.fromCollection(numbers);
DataStreamSource<LogBean> ds5 = see.fromCollection(logs);
```

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> f</span> <span style="color: rgb(31,35,41); background-color: rgba(255,255,255,1)">romParallelCollection(多并行)</span>**

<span style="color: rgb(31,35,41); background-color: rgba(255,255,255,1)">fromParallelCollection(SplittableIterator, </span> <span style="color: rgb(46,161,33); background-color: rgba(255,255,255,1)">Class</span> <span style="color: rgb(31,35,41); background-color: rgba(255,255,255,1)">) 方法是一个并行的Source（并行度可以使用env的setParallelism来设置），该方法需要传入两个参数，第一个是继承SplittableIterator的实现类的迭代器，第二个是迭代器中数据的类型。</span>

```java
/**
 * 集合转换成   并行的  DataStream
 *   1   fromParallelCollection
 *   2   fromSequence
 *   默认所有的可用资源
 */
DataStreamSource<Long> ds6 = see.fromParallelCollection(new NumberSequenceIterator(1, 10), Long.class);

DataStreamSource<Long> ds7 = see.fromSequence(1, 8);
System.out.println(ds7.getParallelism());
ds7.print() ;
```

> <span style="color: rgb(31,35,41); background-color: inherit">并行的Source（并行度也可以通过调用该方法后，再调用setParallelism来设置）通过指定的起始值和结束值来生成数据序列流；</span>
>
> 非并行的source后续的不能使用 setParallelism(N)修改并行度

### 2.3.3  基于文件的Source

```java
public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    conf.setInteger("rest.port", 8888);
    StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
    /**
     * 读取文件
     */
   /* DataStreamSource<String> ds = see.readTextFile("data/logs/");
    System.out.println(ds.getParallelism());
    ds.print() ;*/

    Path path = new Path("data/logs");
    TextLineInputFormat inputFormat = new TextLineInputFormat();
    FileSource<String> fileSource = FileSource.forRecordStreamFormat(inputFormat, path).build();
    /**
     * 参数一   数据源对象
     * 参数二  水位线  处理事件时间数据时出现乱序数据后的时间推进标准
     * 参数三  名字
     */
    DataStreamSource<String> ds = see.fromSource(fileSource, WatermarkStrategy.noWatermarks(), "file-source");
    System.out.println(ds.getParallelism());
    ds.print() ;
    see.execute("file  source") ;
}
```

### 2.3.4  基于Kafka的Source

> 回顾kafka基本命令
>
> kafka-topics.sh   --bootstrap-server doitedu01:9092 --list
>
> kafka-topics.sh   --bootstrap-server  doitedu01:9092   --create --topic doe-data  --partitions 3  --replication-factor  3
>
> bin/kafka-topics.sh  <span style="color: rgb(100,37,208); background-color: inherit">--zookeeper</span> linux01:2181 <span style="color: rgb(100,37,208); background-color: inherit">--delete</span> <span style="color: rgb(100,37,208); background-color: inherit">--topic</span> test
>
> kafka-topics.sh        <span style="color: rgb(100,37,208); background-color: inherit">--zookeeper</span> doit01:2181 <span style="color: rgb(100,37,208); background-color: inherit">--alter</span> <span style="color: rgb(100,37,208); background-color: inherit">--topic</span> doitedu-tpc2 <span style="color: rgb(100,37,208); background-color: inherit">--partitions</span> <span style="color: rgb(46,161,33); background-color: inherit">3</span>
>
>
>
> &#x20;kafka-console-producer.sh --broker-list linux01:9092 --topic test01  &#x20;
>
> kafka-console-consumer.sh --bootstrap-server linux01:9092 --topic test01 --from-beginning
>
>



<span style="color: rgb(31,35,41); background-color: inherit">在实际生产环境中，为了保证flink可以高效地读取数据源中的数据，通常是跟一些分布式消息中件结合使用，例如Apache Kafka。Kafka的特点是分布式、多副本、高可用、高吞吐、</span> <span style="color: rgb(31,35,41); background-color: rgb(251,191,188)">可以记录偏移量等</span> <span style="color: rgb(31,35,41); background-color: inherit">。Flink和Kafka整合可以高效的读取数据，并且可以</span>**<span style="color: rgb(31,35,41); background-color: inherit">保证Exactly Once</span>**<span style="color: rgb(31,35,41); background-color: inherit">（精确一次性语义）。</span>

添加依赖 : 在项目搭建的时候已经添加过 ,不需要再次添加&#x20;

```xml
<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-connector-kafka</artifactId>
    <version>${flink.version}</version>
</dependency>
```

示例代码:&#x20;

```java
public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    conf.setInteger("rest.port", 8888);
    StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);

    KafkaSource<String> source = KafkaSource
            .<String>builder()
            .setBootstrapServers("doitedu01:9092 , doitedu02:9092,doitedu03:9092")
            .setTopics("log-01")
            .setGroupId("g1")
            .setStartingOffsets(OffsetsInitializer.earliest())
            .setValueOnlyDeserializer(new SimpleStringSchema())
            .build();
    DataStreamSource<String> ds = see.fromSource(source, WatermarkStrategy.noWatermarks(), "kafka");
    ds.print();
    see.execute("source 测试");
}
```

*<span style="color: rgb(31,35,41); background-color: inherit">新版本API中，flink会把kafka消费者的消费位移记录在算子</span>**<span style="color: rgb(31,35,41); background-color: inherit">状态</span>**<span style="color: rgb(31,35,41); background-color: inherit">中，这样就实现了消费位移状态的容错，从而可以支持端到端的</span>**<span style="color: rgb(31,35,41); background-color: inherit">exactly-once；</span>***

![](images/[多易教育]-Flink-1.16.1文档-diagram.png)

### 2.3.5  自定义Source

<span style="color: rgb(31,35,41); background-color: inherit">Flink的DataStream API可以让开发者根据实际需要，灵活的自定义Source，本质上就是定义一个类，实现SourceFunction或继承RichParallelSourceFunction，实现run方法和cancel方法。</span>

<span style="color: rgb(31,35,41); background-color: inherit">   可以实现   SourceFunction  或者 RichSourceFunction , 这两者都是非并行的source算子</span>

<span style="color: rgb(31,35,41); background-color: inherit">   也可继承   ParallelSourceFunction  或者 RichParallelSourceFunction , 这两者都是可并行的source算子</span>

> <span style="color: rgb(31,35,41); background-color: inherit">带 Rich的，都拥有 open() ,close() ,getRuntimeContext() 方法</span>
>
> <span style="color: rgb(31,35,41); background-color: inherit">带 Parallel的，都可多实例并行执行source</span>

```java
/**
 * 单并行
 */
static class MySource implements SourceFunction<LogBean> {
    boolean flag = true;

    @Override
    public void run(SourceContext<LogBean> ctx) throws Exception {
        while (flag) {
            ctx.collect(LogBean.of("1001", "seesion01", "click", "ts01"));
            Thread.sleep(1000);
        }

    }

    @Override
    public void cancel() {
        flag = false;
    }
}

/**
 * 多并行
 * 且有生命周期方法
 */
static class MySourceParallel extends RichParallelSourceFunction<LogBean> {
    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
    }

    @Override
    public void close() throws Exception {
        super.close();
    }

    @Override
    public void run(SourceContext<LogBean> ctx) throws Exception {

    }

    @Override
    public void cancel() {

    }
}
```

## 2.4 基本transformation算子

### 2.4.1 map**映射（DataStream → DataStream）**

Takes one element and produces one element  ,有返回值 摄入一条数据返回一条结果&#x20;

该方法是将一个DataStream调用map方法返回一个新的DataStream。本质是将该DataStream中对应的每一条数据依次迭代出来，应用map方法传入的计算逻辑，返回一个新的DataStream。原来的DataStream中对应的每一条数据，与新生成的DataStream中数据是一一对应的。

```java
public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    conf.setInteger("rest.port", 8888);
    StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);

    // source
    DataStreamSource<String> ds = see.socketTextStream("doitedu01", 8899);

    SingleOutputStreamOperator<LogBean> res = ds.map(new MapFunction<String, LogBean>() {
        @Override
        public LogBean map(String value) throws Exception {
            LogBean logBean = null;
            try {
                String[] arr = value.split(",");
                logBean = LogBean.of(Long.parseLong(arr[0]), arr[1], arr[2], Long.parseLong(arr[3]));
            } catch (Exception e) {
                logBean = new LogBean();
            }
            return logBean;
        }
    });
    res.getParallelism();
    res.print() ;
    see.execute("map") ;
}

// SingleOutputStreamOperator<String> ds2 = ds.map(String::toUpperCase);
//  SingleOutputStreamOperator<String> ds3 = ds2.map(String::toLowerCase).setParallelism(16);
```

### 2.4.2 flatMap

Takes one element and produces zero, one, or **more** **elements**. A flatmap function that splits sentences to words:

```java
public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    conf.setInteger("rest.port", 8888);
    StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
    see.setParallelism(1) ; //  设置全局并行度为1
    DataStreamSource<String> lines = see.fromElements("学 大数据 到 多易 教育", "找 行哥", "不吃亏");
    SingleOutputStreamOperator<String> res = lines.flatMap(new FlatMapFunction<String, String>() {
        // 每条数据执行一次这个方法
        @Override
        public void flatMap(String value, Collector<String> out) throws Exception {
            String[] words = value.split("\\s+");
            for (String word : words) {
                out.collect(word);
            }
        }
    });
    res.print() ;

    see.execute() ;

}
```

### 2.4.3 filter

针对每个摄入的数据进行条件判断 .符合条件的数据返回

Evaluates a boolean function for each element and retains those for which the function returns true. A filter that filters out zero values:

```java
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1) ; //  设置全局并行度为1
        DataStreamSource<Integer> ds = see.fromElements(1, 2, 3, 4, 5, 6, 7, 8, 9, 10);
       /* SingleOutputStreamOperator<Integer> res = ds.filter(new FilterFunction<Integer>() {
            @Override
            public boolean filter(Integer value) throws Exception {
                // 处理每条数据  将满足条件的数据返回
                return value > 5 && value%2==0;
            }
        });
       */
        SingleOutputStreamOperator<Integer> res = ds.filter(e -> e > 5 && e % 2 == 0);
        res.print();
        see.execute() ;

    }
```

### 2.4.4 keyBy

DataStream → KeyedStream&#x20;

逻辑上将流划分为不相交的分区(一条记录仅且只分到一个组中)。具有相同键的所有记录都分配给同一个分区。在内部，keyBy（）**是通过哈希分区实现的**。有不同的方法来指定键。

> 1. It is a POJO type but does not override the `hashCode()` method and relies on the `Object.hashCode()` implementation.
>
> 2. It is an array of any type.

```java
KeyedStream<String, String> keyedStream = words.keyBy(e -> e);
```

分组原理图:&#x20;

![](images/[多易教育]-Flink-1.16.1文档-diagram-1.png)



订单案例 : *实时统计每个人的订单总金额*

```java
public class Test01Orders {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);

        DataStreamSource<String> lines = see.socketTextStream("doitedu01", 8899);
        SingleOutputStreamOperator<Tuple3<Integer, String, Double>> orders = lines.map(new MapFunction<String, Tuple3<Integer, String, Double>>() {
            @Override
            public Tuple3<Integer, String, Double> map(String value) throws Exception {
                String[] arr = value.split(",");
                return Tuple3.of(Integer.parseInt(arr[0]), arr[1], Double.parseDouble(arr[2]));
            }
        });

        KeyedStream<Tuple3<Integer, String, Double>, Integer> keyed = orders.keyBy(new KeySelector<Tuple3<Integer, String, Double>, Integer>() {
            @Override
            public Integer getKey(Tuple3<Integer, String, Double> value) throws Exception {
                return value.f0;
            }
        });
        // res结果 (分组key , 第一条数据 , 聚合值和)
        SingleOutputStreamOperator<Tuple3<Integer, String, Double>> res = keyed.sum("f2");
        // 再次处理 , 只要结果
        res.map(tp-> Tuple2.of(tp.f0,tp.f2)).returns(new TypeHint<Tuple2<Integer, Double>>() {
         }).print() ;
        see.execute() ;
    }
}
```

### 2.4.5  滚动聚合 (组内计算)

* <span style="color: rgb(31,35,41); background-color: inherit">此处所说的滚动聚合算子，是多个聚合算子的统称</span> <span style="color: inherit; background-color: rgb(251,191,188)">，有sum、min、minBy、max、maxBy；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">这些算子的底层逻辑都是维护一个聚合值，并使用每条流入的数据对聚合值进行滚动更新；</span>

* <u><span style="color: rgb(31,35,41); background-color: inherit">这些算子都只能在KeyedStream上调用（就是必须keyby后调用）；</span></u>

> sum/min/max/minBy/maxBy



MinBy maxBy 返回的是结果的那条数据

Min  max  sum的计算逻辑流程如下 (返回的是第一条数据)

![](images/[多易教育]-Flink-1.16.1文档-diagram-2.png)

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> min、minBy / max maxBy</span>**

<span style="color: rgb(31,35,41); background-color: inherit">这两个算子都是求最小值；min和minBy的区别在于：</span>

* <span style="color: rgb(31,35,41); background-color: inherit">min的返回值，最小值字段以外，其他字段是第一条输入数据的值；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">minBy返回值，就是最小值字段所在的那条数据；</span>

*<span style="color: rgb(31,35,41); background-color: inherit">底层原理：滚动更新时是更新一个字段，还是更新整条数据的区别；</span>*

```java
/**
 * @Date: 2023/6/26
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: min  max  sum  返回第一条输入的数据和结果
 * minBy  maxBy 返回的是那条目标数据
 */
public class E02MinMaxMinByMaxBy {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        DataStreamSource<String> lines = see.socketTextStream("doitedu01", 8899);
        // 接收数据  uid,oid,money
        SingleOutputStreamOperator<Tuple3<Integer, String, Double>> orders = lines.map(new MapFunction<String, Tuple3<Integer, String, Double>>() {
            @Override
            public Tuple3<Integer, String, Double> map(String value) throws Exception {
                String[] arr = value.split(",");
                return Tuple3.of(Integer.parseInt(arr[0]), arr[1], Double.parseDouble(arr[2]));
            }
        });
        // 按照用户分组
        KeyedStream<Tuple3<Integer, String, Double>, Integer> keyed = orders.keyBy(new KeySelector<Tuple3<Integer, String, Double>, Integer>() {
            @Override
            public Integer getKey(Tuple3<Integer, String, Double> value) throws Exception {
                return value.f0;
            }
        });
        // 如果我们将订单数据  封装成OrderBean : uid , oid , money  keyed.max("money")
        // 返回的结果 是原来的数据类型   结果数据更新在计算的属性上
        //  SingleOutputStreamOperator<Tuple3<Integer, String, Double>> res = keyed.max("f2");
        // 返回的是最大那笔订单的信息
        SingleOutputStreamOperator<Tuple3<Integer, String, Double>> res = keyed.maxBy("f2");
        res.print();
        see.execute();
        // keyed.min("f2") ;
        // keyed.sum("f2") ;
    }
}
```

Max min sum maxBy minBy分组后执行,**&#x20;中间结果是一个聚合值 , 滚动计算实时更新中间结果**

### 2.4.6 reduce

DataStream → KeyedStream&#x20;

**键控数据流**(keyBy之后的流)上的"滚动"聚合。将当前元素与上次聚合的值组合并计算出新值输出。

<span style="color: rgb(31,35,41); background-color: inherit">它的滚动聚合逻辑没有写死，而是由用户通过</span>**<span style="color: rgb(31,35,41); background-color: inherit">ReduceFunction</span>**<span style="color: rgb(31,35,41); background-color: inherit">来传入。</span>**<span style="color: rgb(31,35,41); background-color: inherit">返回值必须和输入类型一致</span>**

![](images/[多易教育]-Flink-1.16.1文档-diagram-3.png)

```java
package com.doit.day03;


import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * @Date: 2023/6/26
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: min  max  sum  返回第一条输入的数据和结果
 * minBy  maxBy 返回的是那条目标数据
 */
public class E03Reduce {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        DataStreamSource<String> lines = see.socketTextStream("doitedu01", 8899);
        // 接收数据  uid,oid,money
        SingleOutputStreamOperator<Tuple3<Integer, String, Double>> orders = lines.map(new MapFunction<String, Tuple3<Integer, String, Double>>() {
            @Override
            public Tuple3<Integer, String, Double> map(String value) throws Exception {
                String[] arr = value.split(",");
                return Tuple3.of(Integer.parseInt(arr[0]), arr[1], Double.parseDouble(arr[2]));
            }
        });
        // 按照用户分组
        KeyedStream<Tuple3<Integer, String, Double>, Integer> keyed = orders.keyBy(new KeySelector<Tuple3<Integer, String, Double>, Integer>() {
            @Override
            public Integer getKey(Tuple3<Integer, String, Double> value) throws Exception {
                return value.f0;
            }
        });

        SingleOutputStreamOperator<Tuple3<Integer, String, Double>> res = keyed.reduce(new ReduceFunction<Tuple3<Integer, String, Double>>() {
            /**
             *
             * @param value1 value1  第一条数据 
             * @param value2        新来的数据 从第二条开始
             * @return
             * @throws Exception
             */
            @Override
            public Tuple3<Integer, String, Double> reduce(Tuple3<Integer, String, Double> value1, Tuple3<Integer, String, Double> value2) throws Exception {
                Tuple3.of(value1.f0, "", value1.f2 + value2.f2)
                value2.f2 = value1.f2 + value2.f2;  // 求和  滚动
                // return value2;
                return Tuple3.of(value1.f0, "", value1.f2 + value2.f2);
            }
        });
        res.print();
        see.execute();
    }
}
```



## 2.5 基本sink算子

* <span style="color: rgb(31,35,41); background-color: inherit">sink算子是将计算结果最终输出的算子</span>

* <span style="color: rgb(31,35,41); background-color: inherit">不同的sink算子可以将数据输出到不同的目标，如写入到的文件、输出到指定的网络端口、消息中间件、外部的文件系统或者是打印到控制台。</span>

### 2.5.1 打印

<span style="color: rgb(31,35,41); background-color: inherit">打印是最简单的一个Sink，通常是用来做实验和测试时使用。</span>

```java
DataStream<Tuple2<String, Integer>> result = wordAndOne.keyBy(0).sum(1);
result.print();
//result.print("多易教育> : ");
```

### 2.5.2 文件sink(了解)

<span style="color: rgb(31,35,41); background-color: inherit">该Sink不但可以将数据写入到各种文件系统中，而且整合了</span> <span style="color: rgb(31,35,41); background-color: rgb(247,105,100)">checkpoint</span> <span style="color: rgb(31,35,41); background-color: inherit">机制来保证</span>**<span style="color: rgb(31,35,41); background-color: inherit">Exacly Once</span>**<span style="color: rgb(31,35,41); background-color: inherit">语义，还可以对文件进行分桶存储，还支持以</span>**<span style="color: rgb(31,35,41); background-color: inherit">列式存储的格式</span>**<span style="color: rgb(31,35,41); background-color: inherit">写出，功能更强大。</span>



<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> streamFileSink中输出的文件，其生命周期会经历3中状态：</span>

<span style="color: rgb(31,35,41); background-color: inherit"> - in-progress Files  正在写的文件  不能操作</span>

<span style="color: rgb(31,35,41); background-color: inherit"> - Pending Files   没有来得及修改状态的已完成的文件   不能操作 </span>

<span style="color: rgb(31,35,41); background-color: inherit"> - Finished Files  已经完成的数据文件    后续的可以操作   一般读  </span>

<span style="color: rgb(31,35,41); background-color: inherit"> </span>

![](images/[多易教育]-Flink-1.16.1文档-image12.png)



> 输出普通文件

![](images/[多易教育]-Flink-1.16.1文档-image-7.png)



```java
package com.doit.day03;

import com.alibaba.fastjson.JSON;
import com.doit.beans.LogBean;
import org.apache.flink.api.common.serialization.SimpleStringEncoder;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.connector.file.sink.FileSink;
import org.apache.flink.core.fs.Path;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.filesystem.OutputFileConfig;
import org.apache.flink.streaming.api.functions.sink.filesystem.bucketassigners.DateTimeBucketAssigner;
import org.apache.flink.streaming.api.functions.sink.filesystem.rollingpolicies.DefaultRollingPolicy;

import java.time.Duration;

/**
 * @Date: 2023/6/26
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 * 行式存储  json格式存储
 * 列式存储  parquet
 */
public class E06Sink_File {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
       see.setParallelism(1) ;
        DataStreamSource<LogBean> ds = see.fromElements(
                LogBean.of(1, "session01", "click1", 10000),
                LogBean.of(2, "session02", "click2", 10000),
                LogBean.of(3, "session03", "click3", 10000),
                LogBean.of(4, "session04", "click4", 10000)
        );
        SingleOutputStreamOperator<String> lines = ds.map(JSON::toJSONString);

        Path path = new Path("data/row_res");
        SimpleStringEncoder stringEncoder = new SimpleStringEncoder();
        OutputFileConfig fileConfig = new OutputFileConfig("doe", ".json");
        //将结果保存在文件系统重    行
        /**
         * 参数一  路径  Path
         * 参数二  输出数据的编码器
         */
        FileSink fileSink = FileSink.<String>forRowFormat(path, stringEncoder)
                // 数据输出时 为了更好的管理输出结果  flink可以对数据进行分桶存储 , 设置分桶规则
                .withBucketAssigner(new DateTimeBucketAssigner())
                // 分桶时间间隔
                .withBucketCheckInterval(10000)
                // 底层文件的滚动策略
                .withRollingPolicy(DefaultRollingPolicy.builder().withRolloverInterval(Duration.ofSeconds(10)).build())
                //  .withRollingPolicy(DefaultRollingPolicy.builder().withMaxPartSize(MemorySize.ofMebiBytes(10L)).build())
                .withOutputFileConfig(fileConfig)
                .build();

        lines.sinkTo(fileSink) ;
        see.execute() ;

    }
}
```

> 输出列式格式文件

```java
public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    conf.setInteger("rest.port", 8888);
    StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
    see.setParallelism(1);
    see.enableCheckpointing(3000) ;
   // see.enableCheckpointing(1000)
    DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
    SingleOutputStreamOperator<LogBean> logBeans = data.map(new MapFunction<String, LogBean>() {
        @Override
        public LogBean map(String value) throws Exception {
            String[] arr = value.split(",");
            LogBean logBean = LogBean.of(Long.parseLong(arr[0]), arr[1], arr[2], Long.parseLong(arr[3]));
            return logBean;
        }
    });
    
    OutputFileConfig outputFileConfig = OutputFileConfig.builder()
            .withPartPrefix("doe-")
            .withPartSuffix(".par")
            .build();
    
    ParquetWriterFactory<LogBean> writerFactory = AvroParquetWriters.forReflectRecord(LogBean.class);
    Path path = new Path("data/res1");
    FileSink<LogBean> fileSink = FileSink.forBulkFormat(path,writerFactory)
            .withBucketCheckInterval(1000)
            .withOutputFileConfig(outputFileConfig)
            .withRollingPolicy(OnCheckpointRollingPolicy.build())
            .build();
    logBeans.sinkTo(fileSink) ;
    
    
    see.execute("测试输出") ;
}
```

### 2.5.3 kafka-sink

<span style="color: rgb(31,35,41); background-color: inherit">Flink可以和Kafka多个版本整合，比如0.11.x、1.x、2.x等；</span>

<span style="color: rgb(31,35,41); background-color: inherit">从Flink1.9开始，使用的是kafka 2.2的客户端。</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 核心类</span>**

* <span style="color: rgb(31,35,41); background-color: inherit">KafkaStringSerializationSchema -- 反序列化</span>

* <span style="color: rgb(31,35,41); background-color: inherit">FlinkKafkaProducer -- 生产者（即sink）</span>

```java
public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    conf.setInteger("rest.port", 8888);
    StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
    see.setParallelism(1);

    // see.enableCheckpointing(1000)
    DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);

    KafkaSink<String> kafkaSink = KafkaSink.<String>builder()
            .setBootstrapServers("doitedu01:9092,doitedu02:9092,doitedu03:9092")
            .setRecordSerializer(KafkaRecordSerializationSchema.builder()
                    .setTopic("log-01")
                    .setValueSerializationSchema(new SimpleStringSchema())
                    .build())
            .setDeliveryGuarantee(DeliveryGuarantee.AT_LEAST_ONCE)
            .setTransactionalIdPrefix("elite-")
            .build();
    data.sinkTo(kafkaSink);

    see.execute("测试输出");
}
```

> <span style="color: rgb(36,91,219); background-color: inherit">KafkaSink是能结合Flink的Checkpoint机制，来支持端到端精确一次语义的 ；</span>
>
> <span style="color: rgb(36,91,219); background-color: inherit">（底层，当然是利用了kafka producer的事务机制）</span>
>
>

### 2.5.4 Jdbc-sink

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit">  不保证Exactly-Once的JdbcSink</span>**

```java
public static void main(String[] args) throws Exception {
    Configuration conf = new Configuration();
    conf.setInteger("rest.port", 8888);
    StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
    see.setParallelism(1);

    // see.enableCheckpointing(1000)
    DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
    SingleOutputStreamOperator<LogBean> logBeans = data.map(new MapFunction<String, LogBean>() {
        @Override
        public LogBean map(String value) throws Exception {
            String[] arr = value.split(",");
            LogBean logBean = LogBean.of(Long.parseLong(arr[0]), arr[1], arr[2], Long.parseLong(arr[3]));
            return logBean;
        }
    });

    JdbcStatementBuilder<LogBean> jdbcStatementBuilder = new JdbcStatementBuilder<LogBean>() {
        @Override
        public void accept(PreparedStatement preparedStatement, LogBean logBean) throws SQLException {
            preparedStatement.setLong(1 ,logBean.getGuid());
            preparedStatement.setString(2 , logBean.getSessionId());
            preparedStatement.setString(3 ,logBean.getEventName());
            preparedStatement.setLong(4 , logBean.getTs());
            preparedStatement.setString(5 , logBean.getSessionId());
            preparedStatement.setString(6 ,logBean.getEventName());
            preparedStatement.setLong(7 , logBean.getTs());
        }
    };

    JdbcExecutionOptions jdbcExecutionOptions = JdbcExecutionOptions.builder()
            .withBatchSize(10)
            .withMaxRetries(3)
            .build();
            
    JdbcConnectionOptions connectionOptions = new JdbcConnectionOptions.JdbcConnectionOptionsBuilder()
            .withUrl("")
            .withUsername("")
            .withPassword("")
            .build();

    String  sql = "insert into tb_log values (?,?,?,?) on duplicate key update session_id=?,event_name=?,ts=? " ;
    SinkFunction<LogBean> sink = JdbcSink.sink(sql, jdbcStatementBuilder, jdbcExecutionOptions, connectionOptions);
    logBeans.addSink(sink) ;
    see.execute() ;

}
```

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit">  保证</span>**<span style="color: rgb(31,35,41); background-color: inherit">Exactly-Once</span>**<span style="color: rgb(31,35,41); background-color: inherit">的</span>**<span style="color: rgb(31,35,41); background-color: inherit">JdbcSink</span>

```java
package com.doit.day04;


import com.doit.beans.LogBean;
import com.mysql.cj.jdbc.MysqlXADataSource;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.connector.jdbc.*;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;
import org.apache.flink.util.function.SerializableSupplier;

import javax.sql.XADataSource;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 * @Date: 2023/6/27
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: 接收网络数据
 * 处理
 * sink到mysql
 * <p>
 * sink  不保证精确处理一次
 * exactlySink 保证精确处理一次
 */
public class E01JdbcSink02 {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1); // 设置全局并行度

        see.enableCheckpointing(2000) ;

        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);

        SingleOutputStreamOperator<LogBean> logBeans = data.map(new MapFunction<String, LogBean>() {
            @Override
            public LogBean map(String value) throws Exception {
                String[] arr = value.split(",");
                return LogBean.of(Long.parseLong(arr[0]), arr[1], arr[2], Long.parseLong(arr[3]));
            }
        });
        //sink(String sql, JdbcStatementBuilder<T> statementBuilder, JdbcExecutionOptions executionOptions, JdbcConnectionOptions connectionOptions) {
        //主键相同数据更新
        // 参数一
        String sql = "insert into  tb_log values(?,?,?,?) on duplicate key update  session_id= ? , event_name = ? , ts = ?";
     // 参数二 预编译sql
        JdbcStatementBuilder<LogBean> jdbcStatementBuilder = new JdbcStatementBuilder<LogBean>() {
            @Override
            public void accept(PreparedStatement preparedStatement, LogBean logBean) throws SQLException {
                // 预编译sql
                preparedStatement.setLong(1, logBean.getGuid());
                preparedStatement.setString(2, logBean.getSessionId());
                preparedStatement.setString(3, logBean.getEventName());
                preparedStatement.setLong(4, logBean.getTs());
                preparedStatement.setString(5, logBean.getSessionId());
                preparedStatement.setString(6, logBean.getEventName());
                preparedStatement.setLong(7, logBean.getTs());
            }
        };
        /**
         * 参数三    执行相关参数
         */
        JdbcExecutionOptions jdbcExecutionOptions = JdbcExecutionOptions.builder()
                // 必须设置成 0
                .withMaxRetries(0)  // 连接服务器重试次数
                .withBatchSize(2)   // 批执行
                .withBatchIntervalMs(5000)  // 间隔触发写入
                .build();
        /**
         * 参数四
         * 保证sink端  数据 Exactly once  要有事务加持
         */
        JdbcExactlyOnceOptions exactlyOnceOptions = JdbcExactlyOnceOptions
                .builder()
                // .withAllowOutOfOrderCommits(true)
                // 有些数据库支持  一个连接中多个事务   mysql只支持一个链接中一个事务
                //  mysql连接内部只支持一个事务   mysql必须写true
                .withTransactionPerConnection(true)
              //  .withMaxCommitAttempts(10)  // 事务最大提交次数
                .build();
        /**
         * 参数五  连接数据库相关的参数
         */
        SerializableSupplier<XADataSource> serializableSupplier = new SerializableSupplier<XADataSource>() {
            @Override
            public XADataSource get() {
                MysqlXADataSource mysqlXADataSource = new MysqlXADataSource();
                mysqlXADataSource.setUrl("jdbc:mysql://localhost:3306/doe");
                mysqlXADataSource.setUser("root");
                mysqlXADataSource.setPassword("root");
                return mysqlXADataSource;
            }
        };
        /**
         * 参数一 执行的sql
         * 参数二  Statement
         * 参数三  执行相关参数
         * 参数四  和精确处理一次相关的参数
         * 参数五  和数据库连接相关
         */
        SinkFunction<LogBean> logBeanSinkFunction = JdbcSink.exactlyOnceSink(sql, jdbcStatementBuilder, jdbcExecutionOptions, exactlyOnceOptions, serializableSupplier);
        logBeans.addSink(logBeanSinkFunction) ;
        see.execute();
    }
}
```

**<span style="color: inherit; background-color: rgb(251,191,188)">JDBC sink保障数据的Exactly Once </span>**

* 目标数据源 支持事务

* 目标数据源 支持幂等写入  \[主键相同时 更新/异常处理]

* 两阶段提交事务结合checkpoint快照机制     1) 预写事务   2)提交事务

![](images/[多易教育]-Flink-1.16.1文档-diagram-4.png)

# 3. 并行度概念和API

## 3.1 基础概念

* <span style="color: rgb(31,35,41); background-color: inherit">用户通过算子api所开发的代码，会被flink任务提交客户端</span>**<span style="color: rgb(31,35,41); background-color: inherit">解析成jobGraph</span>**

* <span style="color: rgb(31,35,41); background-color: inherit">然后，jobGraph提交到集群JobManager，转化成</span>**<span style="color: rgb(31,35,41); background-color: inherit">ExecutionGraph</span>**<span style="color: rgb(31,35,41); background-color: inherit">（并行化后的执行图）</span>

* <span style="color: rgb(31,35,41); background-color: inherit">然后，ExecutionGraph中的各个</span>**<span style="color: rgb(31,35,41); background-color: inherit">task会以多并行实例（subTask）部署到taskmanager上执行</span>**<span style="color: rgb(31,35,41); background-color: inherit">；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">subTask运行的位置是taskmanager所提供的</span>**<span style="color: rgb(216,57,49); background-color: inherit">槽位（task slot）</span>**<span style="color: rgb(216,57,49); background-color: inherit">，</span> <span style="color: rgb(31,35,41); background-color: inherit">槽位简单理解就是一台机器的独立资源容器 ,一个Slot如果有多个核 , 可以运行多个不同Task的subtask；</span>

> **<span style="color: rgb(31,35,41); background-color: rgba(247,105,100,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 重要提示</span>**
>
> * <span style="color: rgb(31,35,41); background-color: inherit">一个算子的逻辑，可以封装在一个独立的task中（可以有多个运行时实例：subTask）；</span>
>
> * **<span style="color: rgb(31,35,41); background-color: inherit">也可把多个算子的逻辑</span>**<span style="color: rgb(31,35,41); background-color: inherit">chain</span>**<span style="color: rgb(31,35,41); background-color: inherit">在一起后封装在一个独立的task中</span>**<span style="color: rgb(31,35,41); background-color: inherit">（可以有多个运行时实例：subTask）；</span>
>
> * **<span style="color: rgb(46,161,33); background-color: inherit">一个算子一个Task ,多个算子也可以封装在一个Task中1</span>**
>
> * <span style="color: rgb(216,57,49); background-color: inherit">注意: 一个槽位上是不能运行同一个Task的多个SubTask</span>

![](images/[多易教育]-Flink-1.16.1文档-image25.png)

* <span style="color: rgb(31,35,41); background-color: inherit">同一个task的不同运行实例，必须放在不同的task slot上运行；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">同一个slot，可以运行多个不同task的一个并行实例；</span>

## 3.2 <span style="color: rgb(31,35,41); background-color: inherit">task与算子链（operator chain）</span>

\[一般理解的层面上 ,一个算子就是一个独立的Task  ! 在满足某些条件下, 多个算子会自动的合并成算子链

\-->独立的Task(算子1()-算子2()-算子3)]

Flink（Apache Flink）是一个开源的流处理和批处理框架，它提供了强大的数据流转换和分析能力。Flink的一个核心概念是"任务（Task）"，它是对算子（operator）的实例化和执行。Flink的任务模型允许将多个算子的逻辑链在一起封装在一个独立的任务中，这主要有以下几个原因：

1. 任务图优化：Flink可以在执行之前对任务图进行优化，将具有相同并行度的算子合并到一个任务中。这样可以减少任务之间的通信开销，提高整体性能。

2. 数据流水线：将多个算子链接在一起可以形成一个数据流水线，每个算子处理完数据后直接传递给下一个算子(逻辑)。这种流水线模型可以提高处理的吞吐量，并减少延迟，<span style="color: rgb(143,149,158); background-color: rgba(255,246,122,0.8)">减少数据网络传输 </span>, 因为数据不需要在算子之间进行显式的序列化和反序列化操作。

3. 资源管理：将多个算子封装在一个任务中，可以更有效地管理资源。Flink可以为任务分配适当的计算资源，并在需要时动态调整资源分配，以提供最佳的性能。

4. 状态管理：将多个算子封装在一个任务中还可以简化状态管理。Flink可以将任务的状态集中存储和管理，减少了状态访问和更新的开销。

**\[简化工作流程 , 节省调度资源, 减少数据交互 ,提升计算性能, 优化状态管理. 提升分布式checkpoint成功率]**

综上所述，将多个算子的逻辑链在一起封装在一个独立的任务中可以提高性能、降低延迟，并简化资源和状态管理。这是Flink框架的设计决策之一，旨在提供高效而灵活的数据处理能力。



**<span style="color: rgb(31,35,41); background-color: rgba(247,105,100,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 上下游算子，能否chain在一起，放在一个Task中，取决于如下3个条件：</span>**

* <span style="color: rgb(31,35,41); background-color: inherit">上下游算子实例间是oneToOne数据传输（forward）；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">上下游算子并行度相同；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">上下游算子属于相同的slotSharingGroup（槽位共享组）；</span>

3个条件都满足，才能合并为一个task；否则不能合并成一个task；

> 代码演示&#x20;

```java
package com.doit.day04;


import org.apache.flink.api.common.eventtime.TimestampAssigner;
import org.apache.flink.api.common.eventtime.TimestampAssignerSupplier;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * @Date: 2023/6/27
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: 一个算子可以封装在一个独立的Task中,  如果这个算子时并行的,  并行度为几   就有几个 subtask
 * 多个算子的计算逻辑 可以组织成一个  计算逻辑链 (chain)  封装在一个Task中
 * 多个Task是否可以合并成一个Task的必要条件
 * 1 并行度相同
 * 2 上下游数据必须在分区间一对一传递
 * 3 多个Task在一个共享槽位组内 
 *   所有的Task并行度都是 4
 *   Task1.slotSharingGroup("g1")
 *   Task2.slotSharingGroup("g1")
 *   Task3.slotSharingGroup("g1")   {[][][]}
 *   Task4.slotSharingGroup("g2")  {[]}
 */
public class E02TaskChain03 {
    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
       //{[4][4][4]]
        SingleOutputStreamOperator<Integer> ds1 = data.map(Integer::parseInt).setParallelism(4);
        //{[4][4]}     --  [4]
        ds1.slotSharingGroup("g1") ;
        SingleOutputStreamOperator<Integer> ds2 = ds1.map(e -> e * 10).setParallelism(4);
        ds2.slotSharingGroup("g1") ;
        SingleOutputStreamOperator<Integer> ds3 = ds2.map(e -> e * 10).setParallelism(4);
        // ds3默认组
        ds3.slotSharingGroup("g2");
        ds3.print().setParallelism(6);
        see.execute() ;


    }
}
```

![](images/[多易教育]-Flink-1.16.1文档-image26.png)



<span style="color: inherit; background-color: rgb(251,191,188)">我们可以通过修改算子之间不同的并行度 / 不同的槽位组 , 控制 断开TaskChain</span>

当然，即使满足上述3个条件，也不一定就非要把上下游算子绑定成算子链；

flink提供了相关的api，来让用户可以根据自己的需求，进行灵活的算子链合并或拆分；

* <span style="color: rgb(31,35,41); background-color: rgba(222,224,227,0.8)">setParallelism          设置算子的并行度 </span>

* <span style="color: rgb(31,35,41); background-color: rgba(222,224,227,0.8)">slotSharingGroup     设置算子的槽位共享组</span>

* <span style="color: rgb(31,35,41); background-color: inherit">disableChaining       对算子禁用前后链合并  [当前Task独立出来]</span>

* <span style="color: rgb(31,35,41); background-color: inherit">startNewChain        l对算子开启新链（即禁用算子前链合并）</span>

```plain&#x20;text
* 1  ds.setParallelism(N)  设置数据流的并行度
* 2  整个Job禁用算子合并  see.disableOperatorChaining() ;
* 3  ds.startNewChain()  将当前的算子和前面的算子断开形成一个新的chain , 后面的算子可以合并过来
* 4  ds.disableChaining() , 将ds算子前后独立出来 , 不会影响后面的算子合并
```

```java
//  距禁用算子自动chain    每个Task任务都很重
// see.disableOperatorChaining();
```



```java
  DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
     //{[4][4][4][4]]
      SingleOutputStreamOperator<Integer> ds1 = data.map(Integer::parseInt).setParallelism(4);
      SingleOutputStreamOperator<Integer> ds2 = ds1.map(e->e).setParallelism(4);
      SingleOutputStreamOperator<Integer> ds3 = ds2.map(e -> e * 10).setParallelism(4).disableChaining();
      SingleOutputStreamOperator<Integer> ds4 = ds3.map(e -> e * 10).setParallelism(4);
      ds4.print().setParallelism(4);
```

![](images/[多易教育]-Flink-1.16.1文档-image-18.png)

```java
DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
//{[4][4][4][4]]
SingleOutputStreamOperator<Integer> ds1 = data.map(Integer::parseInt).setParallelism(4);
SingleOutputStreamOperator<Integer> ds2 = ds1.map(e->e).setParallelism(4);
SingleOutputStreamOperator<Integer> ds3 = ds2.map(e -> e * 10).setParallelism(4).startNewChain();
SingleOutputStreamOperator<Integer> ds4 = ds3.map(e -> e * 10).setParallelism(4);
ds4.print().setParallelism(4);
```

![](images/[多易教育]-Flink-1.16.1文档-image-17.png)



## 3.3 <span style="color: rgb(31,35,41); background-color: inherit">分区算子</span>

<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 并行计算: 都有分区的概念  ; 实时流处理数据过程中, 分区规则一般不需要参与 ,不同的算子调用时, 上游下游Task </span>**<span style="color: rgb(31,35,41); background-color: inherit">合理</span>**<span style="color: rgb(31,35,41); background-color: inherit">的划分数据</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span>**<span style="color: rgb(31,35,41); background-color: inherit">分区算子：用于指定上游task的各并行subtask与下游task的subtask之间如何传输数据；</span>



<span style="color: rgb(31,35,41); background-color: inherit">Flink中，对于上下游subTask之间的数据传输控制，由</span>**<span style="color: rgb(31,35,41); background-color: inherit">ChannelSelector</span>**<span style="color: rgb(31,35,41); background-color: inherit">策略来控制，而且Flink内针对各种场景，开发了众多ChannelSelector的具体实现 ; </span>**<span style="color: rgb(31,35,41); background-color: inherit">数据分发规则, 一般不需要我们参与</span>**<span style="color: rgb(31,35,41); background-color: inherit"> ,调用不同的转换算子内部有具体的数据分发规则!</span>

![](images/[多易教育]-Flink-1.16.1文档-image27.png)



**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 设置数据传输策略时，不需要显式指定partitioner，而是调用封装好的算子即可</span>**<span style="color: rgb(31,35,41); background-color: inherit">：</span>

|   | ds.global()                                                                                      | 上游所有Subtask的数据都发往下游Task的第一个Subtask |
| - | ------------------------------------------------------------------------------------------------ | ---------------------------------- |
|   | ds.broadcast()                                                                                   | 上游每个ST的所有数据都会发往下游每个ST              |
|   | ds.forward()                                                                                     | 上下游数据是一对一分发                        |
|   | ds.<span style="color: rgb(216,57,49); background-color: inherit">shuffle</span>()               |  上游数据随机发送到下游                       |
|   | ds.rebalance()                                                                                   | 以ST的数据为单位 轮循发送数据                   |
|   | ds.recale()                                                                                      | 本地轮循发送数据                           |
|   | <span style="color: rgb(216,57,49); background-color: inherit">ds.partitionCustom(自定义分区器)</span> | 自定义数据分发规则                          |
|   | ds.hash()                                                                                        | key的hash值 % X 分配数据                 |

**<span style="color: rgb(31,35,41); background-color: inherit">dataStream.</span> <span style="color: rgb(216,57,49); background-color: inherit">keyBy(KeySelector) </span> <span style="color: rgb(31,35,41); background-color: inherit"> 根据key的hashcode来进行hash分发</span>**

```java
public class TestPartitioner {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        DataStreamSource<String> ds = see.socketTextStream("doitedu01", 8899);
        SingleOutputStreamOperator<String> ds1 = ds.map(String::toLowerCase);  // rebalance
        SingleOutputStreamOperator<String> words = ds1.flatMap(new FlatMapFunction<String, String>() {
            @Override
            public void flatMap(String value, Collector<String> out) throws Exception {
                String[] arr = value.split("\\s+");
                for (String s : arr) {
                    out.collect(s);
                }
            }
        });
        KeyedStream<String, String> ds2 = words.keyBy(e -> e); // Hash
        SingleOutputStreamOperator<String> ds3 = ds2.map(String::toLowerCase);
        ds3.print() ;
        see.execute() ;
    }
}
```

![](images/[多易教育]-Flink-1.16.1文档-image-15.png)

<span style="color: rgb(31,35,41); background-color: inherit">默认情况下，flink会优先使用REBALANCE分发策略</span>

```java
public static void main(String[] args) throws Exception {

    Configuration conf = new Configuration();
    conf.setInteger("rest.port", 8888);
    StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);

    DataStreamSource<String> ds = see.socketTextStream("doitedu01", 8899);

    SingleOutputStreamOperator<String> ds1 = ds.map(String::toLowerCase);  // rebalance
    SingleOutputStreamOperator<String> words = ds1.flatMap(new FlatMapFunction<String, String>() {
        @Override
        public void flatMap(String value, Collector<String> out) throws Exception {
            String[] arr = value.split("\\s+");
            for (String s : arr) {
                out.collect(s);
            }
        }
    });
    DataStream<String> afterDs = words.broadcast();
   // words.rebalance() ;
   // words.forward() ;
   // words.global() ;
   // words.broadcast();
   // words.shuffle() ;
   // words.rescale() ;
    SingleOutputStreamOperator<String> ds3 = afterDs.map(String::toLowerCase);
    ds3.print() ;
    see.execute() ;
}
```

自定义分区器 :&#x20;

```java
package com.doit.day04;


import org.apache.flink.api.common.functions.Partitioner;

/**
 * @Date: 2023/6/27
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 */
public class MyPartitioner implements Partitioner<String> {
// 会自动获取下游算子分分区数
    @Override
    public int partition(String key, int numPartitions) {
        return  ((key.hashCode()) & Integer.MAX_VALUE)  % numPartitions ;
       // return key.hashCode()%4;
    }
}



DataStream<String> ds = data.partitionCustom(new MyPartitioner(), new KeySelector<String, String>() {
    @Override
    public String getKey(String value) throws Exception {
        String key = value.split(",")[0];
        return key;
    }
});
```

# 4. 时间语义和水位线

## 4.1   时间语义概述

在实时数据处理的过程中 ,有两种时间语义!

* 使用现实中的时间为维度计算数据    \[最近10s的订单总额]  此刻 08:01:00   \[08:00:50 \~  08:01:00]   处理时间

* 使用数据产生时间来计算 , 并不是现实中的时间 !  事件事件

两种时间的特点 :&#x20;

&#x20;1\) 现实中的时间:  单调递增   不可回退的一个变化值&#x20;

<span style="color: rgb(216,57,49); background-color: inherit"> 2)</span> 数据时间 <span style="color: rgb(216,57,49); background-color: inherit">:  数据有延迟 , 乱序 ,暂停 , 时间不符合现实中的时间规律</span>



>
>
> * 如果在实时计算中使用现实中的时间计算 (定时器),不需要进行时间的维护 . 时间递增的不后退 , 自动的向前推进 !
>
> * 如果使用数据时间处理需求 ,我们要保证时间符合现实时间的特性 \[单调递增性] , 同时要考虑数据时间<span style="color: rgb(216,57,49); background-color: inherit">推进</span>的过程 ! \[数据乱序, 数据暂停] ;  &#x20;
>
> * **<span style="color: rgb(46,161,33); background-color: inherit">水位线</span> <span style="color: rgb(216,57,49); background-color: inherit">: 在事件时间处理数据的过程中 用于时间推进 !  [事件时间语义下的时间推进标准] , 一般水位线结合时间窗口完成需求!</span>**
>
>

<u><span style="color: rgb(31,35,41); background-color: inherit">在实时流式计算中，&quot;时间&quot;是一个能影响计算结果的非常重要因素！</span></u>

<span style="color: rgb(31,35,41); background-color: inherit">试想场景：每隔1分钟计算一次最近10分钟的活跃用户量：</span>

> <span style="color: rgb(31,35,41); background-color: inherit">①假设此刻的时间是13:10，要计算的活跃用户量时间段为：[ 13:00,13:10 )；</span>
>
> <span style="color: rgb(31,35,41); background-color: inherit">②有一条行为日志中记录的用户的行为时间是12:59，但到达flink计算程序时已是13:02；</span>
>
> <span style="color: rgb(31,35,41); background-color: inherit">那么，这个用户是否要纳入本次计算的结果中呢？看如何定义：</span>
>
> <span style="color: rgb(31,35,41); background-color: inherit">①如果时段 [13:00 , 13:10 ）定义的是用户行为的发生时间（数据中的业务时间），则不应纳入；</span>
>
> <span style="color: rgb(31,35,41); background-color: inherit">②如果时段 [13:00 , 13:10 ）定义的是计算时的时间，则应该纳入；</span>

在事实流数据处理的时候 有两种时间标准

1\) 程序执行的现实时间 , 现实时间是单调递增 , 不断推进的 , 不会倒退

2\) 数据产生的时间 作为时间推进的依据 (有难处)

![](images/[多易教育]-Flink-1.16.1文档-image-16.png)

<span style="color: rgb(31,35,41); background-color: inherit">flink内部为了直观地统一计算时所用的时间标准，特制定了两种时间语义：</span>

* <span style="color: rgb(31,35,41); background-color: inherit">processing time   处理时间</span>

* <span style="color: rgb(31,35,41); background-color: inherit">event time         事件时间</span>

***<span style="color: rgb(31,35,41); background-color: inherit">时间语义主要影响 &quot;窗口计算&quot; ；</span>***

## 4.2 <span style="color: rgb(31,35,41); background-color: inherit">两种时间语义</span>

<span style="color: rgb(31,35,41); background-color: inherit">时间语义</span>**<span style="color: rgb(31,35,41); background-color: inherit">，是flink中用于时间推进和时间判断的机制；</span>**

<span style="color: rgb(31,35,41); background-color: inherit">时间推进和时间判断，以什么为标准，就产出了两种不同的时间语义；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">以 processing time为依据，则叫做</span>**<span style="color: rgb(31,35,41); background-color: inherit">处理时间语义</span>**

* <span style="color: rgb(31,35,41); background-color: inherit">以 event time为依据，则叫做</span>**<span style="color: rgb(31,35,41); background-color: inherit">事件时间语义</span>**

<span style="color: rgb(31,35,41); background-color: inherit">时间语义的设计意义</span>

```java
process(EventLog eventlog){
Long  eventTime  =  eventLog.getTimestamp();
Long  processTime = System.currentMillimise()
      // 用户完全可以自己根据需求中的时间定义来进行相应的计算
}
```

<span style="color: rgb(31,35,41); background-color: inherit">Flink为什么还要搞出一个  “事件时间语义”：时间按数据中的业务时间戳来推进！</span>

<span style="color: rgb(31,35,41); background-color: inherit">主要是，实时流式计算中，有大量跟时间相关的统计需求，比如：</span> <u><span style="color: rgb(31,35,41); background-color: inherit">时间窗口计算</span></u> <span style="color: rgb(31,35,41); background-color: inherit">，</span> <u><span style="color: rgb(31,35,41); background-color: inherit">定时器</span></u> <span style="color: rgb(31,35,41); background-color: inherit">等，而这些需求，</span> <u><span style="color: rgb(31,35,41); background-color: inherit">如果都让用户像上面的代码那样自己去进行判断、处理，</span></u> <span style="color: rgb(31,35,41); background-color: inherit">那么它觉得自己的api不够强大！</span>

<span style="color: rgb(31,35,41); background-color: inherit">所以，flink想在api的层面，将两类时间定义的计算需求进行api层面的统一，它才搞出这么一种”事件时间语义“，有了这种语义，那么，处理时间 和  事件时间，都可以看成 ”时间”</span>

**<span style="color: rgb(216,57,49); background-color: inherit">用户在不同时间定义下，要进行一个定时动作时，就不需要再像上面的代码那种去进行各种判断，而是一个</span> <u><span style="color: rgb(216,57,49); background-color: inherit">统一的动作：</span></u> <span style="color: rgb(216,57,49); background-color: inherit">  到 xxx时间，给我做个什么事！</span>**

```java
process(EventLog eventlog，TimeStamp timestamp){
      // 不管需求是需要用哪种时间来计算，用户代码只需要看到一个timestamp了
}
```

<span style="color: rgb(216,57,49); background-color: inherit">代码中的timestamp到底是事件时间，还是处理时间，</span>**<span style="color: rgb(216,57,49); background-color: inherit">取决于环境中设置的“时间语义”根据业务需求设置不同的时间语义!</span>**

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span>**<span style="color: rgb(31,35,41); background-color: inherit">处理时间（processing time）语义</span>

<span style="color: rgb(31,35,41); background-color: inherit">Processing Time是指数据被Operator处理时所在机器的系统时间。</span>

**<span style="color: rgb(31,35,41); background-color: inherit">处理时间</span>**<span style="color: rgb(31,35,41); background-color: inherit">遵循客观世界中时间的特性：单调递增，恒定速度，永不停滞，永不回退；</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span>**<span style="color: rgb(31,35,41); background-color: inherit">事件时间（event time）语义</span>

<span style="color: rgb(31,35,41); background-color: inherit">Event Time是指在数据本身的业务时间（如用户行为日志中的用户行为时间戳）；</span>

**<span style="color: rgb(31,35,41); background-color: inherit">Event Time语义中，时间的推进完全由流入flink系统的数据来驱动 ,</span>**

<u><span style="color: rgb(31,35,41); background-color: inherit">数据中的</span></u>**<u><span style="color: rgb(31,35,41); background-color: inherit">事件时间</span></u>**<u><span style="color: rgb(31,35,41); background-color: inherit">推进到哪，flink就认为自己的时间推进到了哪；</span></u>

> <span style="color: rgb(31,35,41); background-color: inherit">它可能停滞，也可能速度不恒定，</span>**<span style="color: rgb(216,57,49); background-color: inherit">但也一定是单调递增不可回退</span>**<span style="color: rgb(31,35,41); background-color: inherit">！</span>

![](images/[多易教育]-Flink-1.16.1文档-image-19.png)



![](images/[多易教育]-Flink-1.16.1文档-image-13.png)



## 4.3 时间语义设置

* 使用到时间处理数据时都有相应的时间语义API&#x20;

* 比如 "时间窗口API"   XXEventTimeXX    XXProcessTimeXX

* 如果使用的是事件时间  抽取事件中时间戳的逻辑

![](images/[多易教育]-Flink-1.16.1文档-image-14.png)

<span style="color: rgb(31,35,41); background-color: inherit">如果需要禁用event time机制，则可以通过设置watermark生成频率间隔来实现：</span>

<span style="color: rgb(222,120,2); background-color: rgba(255,255,255,1)">// 如果设置为0，则禁用了watermark的生成；从而失去了event time语义</span>

```java
ExecutionConfig config = see.getConfig();
config.setAutoWatermarkInterval(0L) ;
```

*<span style="color: rgb(31,35,41); background-color: inherit">提示：如果需要使用已过期的 ingestion time，可以通过设置恰当的watermark来实现</span>*

## 4.4  水位线 Watermark

<span style="color: rgb(143,149,158); background-color: rgba(255,246,122,0.8)">假如使用事件时间作为处理数据的时间依据 :[时间标记]</span>

* <span style="color: rgb(216,57,49); background-color: inherit">可以将流入数据的最大时间点  , 作为&quot;当前时间&quot;  , 时间值就是水位线 [推进时间 触发时间窗口 /定时]</span>

* 由于流入的数据可能是无序的 , 为了避免小延迟数据的丢失 , 将当前时间缩小 ,延迟窗口的触发, 避免延迟数据的丢失 <span style="color: rgb(216,57,49); background-color: inherit"> 作为&quot;当前时间&quot;  - x秒  水位线</span>

<span style="color: inherit; background-color: rgba(183,237,177,0.8)">以数据时间为事件标准 , 数据是有序的 , 当前流入数据时间(水位线)就是当前数据的时间</span>

![](images/[多易教育]-Flink-1.16.1文档-image-12.png)



<span style="color: inherit; background-color: rgba(183,237,177,0.8)">数据流入到算子的时候  恰恰很多时候不是按照数据生成时间先后流入的(如果使用下面的方式生成时间标记)</span>

&#x20;      1\) 通过判断  维护一个单调递增的时间

&#x20;      2\) 但是 数据丢失频次太高

![](images/[多易教育]-Flink-1.16.1文档-image-11.png)



> 什么是水位线??&#x20;
>
> 在flink实时处理数据的过程中 ,如果以**数据时间**作为计算的时间标准 (比如时间窗口的触发,定时器等).需要唯一个单调递增的**时间值** !这个时间值就是**水位线** , 用来作为(事件时间语义处理数据时)推进时间的标准 !
>
> * 单调递增 和 数据有关
>
> * 周期性生成
>
>
>
> <span style="color: inherit; background-color: rgba(183,237,177,0.8)">1) max_value  =  Math.max(max_value , curent_data_ts) ;</span>
>
> <span style="color: inherit; background-color: rgba(183,237,177,0.8)">2) 每200ms  new   WaterMark(max_value)</span>
>
> 由于数据乱序的情况非常常见 , 此时出现延迟数据没有流入到指定的窗口前就触发了窗口计算 ,造成微小延迟数据的数据丢失
>
> **<span style="color: inherit; background-color: rgba(183,237,177,0.8)">new   WaterMark(max_value - 允许乱序时间)</span>**
>
>
>
> **源码:&#x20;**
>
> public class **BoundedOutOfOrdernessWatermarks**\<T> implements WatermarkGenerator\<T> {
>
> &#x20;public  BoundedOutOfOrdernessWatermarks(延迟时间){
>
> &#x20;    }
>
> maxTimestamp = Long.MIN\_VALUE  + 延迟时间 (0) + 1 ;&#x20;
>
> // 1  流入的数据   一直在流入
>
> public void onEvent(T event, long eventTimestamp, WatermarkOutput output) {
>
> // 2 获取数据时间  和  当前的最大时间值比较  将最大的时间 赋值给maxTimestamp
>
> &#x20;   maxTimestamp = Math.max(maxTimestamp, eventTimestamp);
>
> }
>
>
>
> // 3 周期性的生成水位线并 发送到下游 \[推进时间]  200ms
>
> public void onPeriodicEmit(WatermarkOutput output) {
>
> &#x20;   // 创建此刻的水位线
>
> &#x20;   output.emitWatermark(<span style="color: rgb(216,57,49); background-color: inherit">new Watermark(maxTimestamp - outOfOrdernessMillis - 1)</span>);
>
> }
>
> }

### 4.4.1  事件时间推进的困难

在Apache Flink中，事件时间（event time）是指事件实际发生的时间，与数据流本身携带的时间戳相关。事件时间处理对于流处理任务来说非常重要，因为它允许按照事件的实际发生时间进行窗口操作和处理。

然而，推进事件时间在某些情况下可能会带来困难。以下是一些常见的问题和挑战：

1. <span style="color: inherit; background-color: rgba(255,246,122,0.8)">延迟数据</span>：事件流中可能存在延迟到达的数据。这些延迟数据会导致事件时间推进的困难，因为在处理过程中需要等待延迟的事件到达才能正确触发窗口操作或处理。处理延迟数据需要考虑合理的水位线（watermark）策略和处理逻辑。

2. <span style="color: inherit; background-color: rgba(255,246,122,0.8)">乱序数据</span>：事件流中的事件可能以乱序的方式到达。这种乱序会导致事件时间推进的挑战，因为乱序事件的到达可能会违反按照事件时间进行处理的顺序性。Flink提供了乱序事件处理的机制，如水位线和窗口延迟触发等，但仍然需要开发人员根据实际场景进行合理的处理。

3. 完全无序数据：在某些情况下，事件流可能是完全无序的，即无法通过时间戳来进行事件时间推进。这种情况下，通常需要依赖其他的标记或特征来对事件进行排序或分组，以实现事件时间的推进和处理。

4. 事件时间和处理时间的转换：Flink支持在事件时间和处理时间之间进行转换，但在转换过程中可能会出现困难。例如，当从事件时间模式切换到处理时间模式时，可能需要考虑到事件时间推进的问题，以确保正确的处理顺序和结果。

针对这些困难，Flink提供了一些机制和功能来帮助解决，如水位线机制、事件时间窗口、延迟触发等。同时，开发人员也需要根据具体的应用场景和数据特点，设计合理的处理逻辑和策略，以应对事件时间推进的困难。

> 数据产生的时间 作为时间推进的依据 <span style="color: inherit; background-color: rgb(251,191,188)">(有难处)</span>

##### 数据乱序问题&#x20;

1\) 针对乱序的数据  维护一个单调递增的值

2\) 如果数据乱序   ,使用上面的水位线的计算逻辑 , 可能"**频繁**"出现数据丢失问题

(让时间的推进延迟 , 晚触发窗口的计算, 避免部分延迟数据的丢失)



**方案:&#x20;**

**人为的设置延迟时间(允许延迟时间)  ,用当前周期(200ms)内流入数据的最大时间戳创建水位线 :用当前周期(200ms)内流入(数据的最大时间戳-允许延迟时长)创建水位线 :**



### 4.4.2 Watermark来推进时间

* <span style="color: rgb(31,35,41); background-color: inherit">所谓watermark，就是在事件时间语义世界观中，用于单调递增向前推进时间的一种标记；它用于表示事件流中事件时间的进度，并帮助确定何时触发窗口操作或处理。</span>

* <span style="color: rgb(31,35,41); background-color: inherit">它的核心机制是在数据流中</span>**<span style="color: rgb(31,35,41); background-color: inherit">周期性地插入一种时间戳单调递增的特殊数据元素</span>**<span style="color: rgb(31,35,41); background-color: inherit">（Watermark），来不可逆转地在整个数据流中进行时间的推进；</span>

![](images/[多易教育]-Flink-1.16.1文档-diagram-5.png)

<u><span style="color: rgb(216,57,49); background-color: inherit">Watermark是从某一个算子实例（源头）开始，根据数据中的事件时间，来周期性地产生，并插入到数据流中，持续不断地往下游传递，以推进整个计算链条上各个算子实例的时间！</span></u>

```java
// watermark的生成周期（默认值即为200ms）
env.getConfig().setAutoWatermarkInterval(200);
```

代码片段

```java
public final class Watermark implements Serializable {
    private final long timestamp;
    public Watermark(long timestamp) {
        this.timestamp = timestamp;
    }
    public long getTimestamp() {
        return timestamp;
    }

    public String getFormattedTimestamp() {
        return TS_FORMATTER.get().format(new Date(timestamp));
    }
}
```

##### 水位线生成过程&#x20;

**<span style="color: rgb(46,161,33); background-color: inherit">在使用事件时间语义处理数据时才需要使用水位线</span>**

&#x20;在某个处理算子之后生成水位线也可以 !

<span style="color: inherit; background-color: rgba(183,237,177,0.8)">水位线生成过程详解</span>

![](images/[多易教育]-Flink-1.16.1文档-diagram-6.png)

##### 水位线向下游传递过程

<span style="color: inherit; background-color: rgba(254,212,164,0.8)">如果一个Subtask收到多个水位线 , 选择一个小的水位线作为当前水位线</span>

<span style="color: inherit; background-color: rgb(251,191,188)">// 解决上游水位线暂停 导致下游水位线暂停的问题</span> <span style="color: inherit; background-color: rgb(251,191,188)">.withIdleness(Duration.</span>*<span style="color: inherit; background-color: rgb(251,191,188)">ofSeconds</span>*<span style="color: inherit; background-color: rgb(251,191,188)">(2))</span>

水位线是广播的方式向下游传递

![](images/[多易教育]-Flink-1.16.1文档-image-8.png)

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">下游Sutask如果获得上游多个SubTask的水位线 , 选择小的水位线</span>

![](images/[多易教育]-Flink-1.16.1文档-image-10.png)



![](images/[多易教育]-Flink-1.16.1文档-image37.png)

##### **<span style="color: rgb(31,35,41); background-color: inherit">watermark推进时间与窗口计算</span>**

使用事件时间处理数据  且开启时间窗口  ,

* 窗口的触发取决于 当前的水位线  水位线>= 窗口触发时间触发

* 流入的数据到底分配到哪个计算窗口中  ,  取决于数据的事件时间

* 下游SubTask接收多个水位线   取最小的作为当前水位线



<span style="color: rgb(216,57,49); background-color: inherit">  如果</span>**<span style="color: rgb(216,57,49); background-color: inherit">水位线</span>**<span style="color: rgb(216,57,49); background-color: inherit">的值 &gt;=  窗口的结束边界  触发窗口执行</span>

### 4.4.3 <span style="color: rgb(31,35,41); background-color: inherit">内置watermark生成策略(原理)</span>



<span style="color: inherit; background-color: rgba(255,246,122,0.8)">生成策略 代码设置</span>

```java
WatermarkStrategy.<LogBean>forMonotonousTimestamps()  // 数据单单调递增
WatermarkStrategy.<LogBean>forBoundedOutOfOrderness(Duration.ofSeconds(1))  // 允许乱序
WatermarkStrategy.<LogBean>noWatermarks()  // 不使用水位线
```

### 4.4.4 Watermark源码模板

```java
// 水位线  类  
public final class Watermark implements Serializable{

private final long timestamp;

public Watermark(long timestamp) {
    this.timestamp = timestamp;  // 时间
}
// 返回当前水位线的值 (时间)
public long getTimestamp() {
    return timestamp;
}

}
```

```java
// 水位线的策略类 
public class BoundedOutOfOrdernessWatermarks<T> implements WatermarkGenerator<T> {
private long maxTimestamp;   // 最大时间  默认  
private final long outOfOrdernessMillis;// 允许的延迟毫秒  

/**
*    WatermarkStrategy
*   .<OrdersBean>forBoundedOutOfOrderness(Duration.ofSeconds(2))
* -->被默认调用   
/

// 被默认调用   
public BoundedOutOfOrdernessWatermarks(Duration maxOutOfOrderness) {
    checkNotNull(maxOutOfOrderness, "maxOutOfOrderness");
    checkArgument(!maxOutOfOrderness.isNegative(), "maxOutOfOrderness cannot be negative");

    this.outOfOrdernessMillis = maxOutOfOrderness.toMillis();

    // start so that our lowest watermark would be Long.MIN_VALUE.
    this.maxTimestamp = Long.MIN_VALUE + outOfOrdernessMillis + 1;
}
/**
* 每条数据执行一次  
eventTimestamp  当前数据的数据时间 
*/
@Override
public void onEvent(T event, long eventTimestamp, WatermarkOutput output) {
// 流入数据的最大时间
    maxTimestamp = Math.max(maxTimestamp, eventTimestamp);
}

/**
* 生成水位线   (标记时间的推进)
*    并向下游发送  
*  see.getConfig().getAutoWatermarkInterval() ;   默认200ms
*
*/
@Override
public void onPeriodicEmit(WatermarkOutput output) {
    output.emitWatermark(new Watermark(maxTimestamp - outOfOrdernessMillis - 1));
}

}
```

![](images/[多易教育]-Flink-1.16.1文档-image-9.png)

上图是 :&#x20;

<span style="color: inherit; background-color: rgba(254,212,164,0.8)">static &lt;T&gt; WatermarkStrategy&lt;T&gt; forMonotonousTimestamps() {</span> <span style="color: inherit; background-color: rgba(254,212,164,0.8)">    return (ctx) -&gt; new AscendingTimestampsWatermarks&lt;&gt;();</span> <span style="color: inherit; background-color: rgba(254,212,164,0.8)">}</span>

### 4.4.5 Watermark观察

* Task02 上调用分配水位线的代码 :  Task02的图上看不到水位线 , 在下游的Task的图上才能看到&#x20;

* 水位线向下游通过广播的形式发送  ,**&#x20;不管有没有数据 , 水位线都会广播**

* 下游水位线的大小  取决于接收到所有的水位线的最小值

```java
package com.doit.grammar;


import com.doit.beans.OrdersBean;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;

import java.time.Duration;

/**
 * @Date: 2023/9/7
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: 只有使用  事件时间  语义处理数据时  才会使用到水位线
 * ①  每10s统计一次  各个城市  订单总额
 * 事件时间
 *
 * 1,BJ,100,10000
 * 1,BJ,100,10000
 * 1,BJ,100,10000
 * 2,BJ,100,12000
 * 3,BJ,100,20000
 * 4,BJ,100,22000
 * 5,BJ,100,32000
 * 6,SH,100,33000
 * 7,SZ,100,42000
 * 8,SZ,100,50000
 * 9,SZ,100,49999
 * 10,SZ,100,52000
 */
public class F04TestWaterMark {
    public static void main(String[] args) throws Exception {
        // 1 获取环境
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);  // 设置默认并行度  1
        // 2 加载数据
        DataStreamSource<String> dataStreamSource = see.socketTextStream("doitedu01", 8899);
        // 3 解析数据
        SingleOutputStreamOperator<OrdersBean> ordersBeans = dataStreamSource.map(new MapFunction<String, OrdersBean>() {
            @Override
            public OrdersBean map(String value) throws Exception {
                try {
                    String[] arr = value.split(",");
                    String oid = arr[0];
                    String city = arr[1];
                    double money = Double.parseDouble(arr[2]);
                    long ts = Long.parseLong(arr[3]);
                    return new OrdersBean(oid, city, money, ts);
                } catch (Exception e) {
                    return new OrdersBean();
                }
            }
        });
        // 4 分配水位线 和 事件戳
        /**
         *      水位线的分配策略
         *      1   明确数据是按照生成时间的先后顺序依次流入的  有序的 forMonotonousTimestamps
         *      2   有乱序的可能性的数据 forBoundedOutOfOrderness
         *      3   不分配水位线
         */

        //  ordersBeans.assignTimestampsAndWatermarks(WatermarkStrategy.forMonotonousTimestamps()) ;
        // ordersBeans.assignTimestampsAndWatermarks(WatermarkStrategy.noWatermarks()) ;
        SingleOutputStreamOperator<OrdersBean> ordersBeanWithWaterMark = ordersBeans.assignTimestampsAndWatermarks(
                WatermarkStrategy
                        .<OrdersBean>forBoundedOutOfOrderness(Duration.ofSeconds(2))
                        .withTimestampAssigner(new SerializableTimestampAssigner<OrdersBean>() {
                            @Override  // 每流入一条数据会执行一次
                            public long extractTimestamp(OrdersBean element, long recordTimestamp) {
                                return element.getTs();
                            }
                        })
        );
        // 5 处理数据
     /*   ordersBeanWithWaterMark.keyBy(new KeySelector<OrdersBean, String>() {
            @Override
            public String getKey(OrdersBean value) throws Exception {
                return value.getCity();
            }
        }) ;*/

        /**
         * HASH  数据再分发   相同的城市一定分配到一个分区中  一个分区可能有多个城市数据
         * 分组  分区内部  , 按照城市的值分组
         */
        KeyedStream<OrdersBean, String> keyed = ordersBeanWithWaterMark.keyBy(bean -> bean.getCity());
        // 6  开窗计算  窗口触发时输出结果
        WindowedStream<OrdersBean, String, TimeWindow> windowed = keyed.window(TumblingEventTimeWindows.of(Time.seconds(10)));
        windowed.sum("money").print();
        // 8 执行
        see.execute() ;

    }
} 
```

# 5. 窗口函数

## 5.1  概述

<span style="color: rgb(31,35,41); background-color: inherit">窗口，就是把无界的数据流，依据一定规则划分成一段一段的有界数据流来计算；</span>

<span style="color: rgb(31,35,41); background-color: inherit">既然划分成有界数据段，通常都是为了&quot;</span>**<span style="color: rgb(31,35,41); background-color: inherit">聚合</span>**<span style="color: rgb(31,35,41); background-color: inherit">&quot;；</span>

Windows can be defined on already partitioned KeyedStreams. Windows group the data in each key according to some characteristic (e.g., the data that arrived within the last 5 seconds)

![](images/[多易教育]-Flink-1.16.1文档-image43.png)

<span style="color: rgb(31,35,41); background-color: inherit">Keyedwindow重要特性：任何一个窗口，都绑定在自己所属的key上；不同key的数据肯定不会划分到相同窗口中去！</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 滚动窗口</span>**

数据不会被重复处理

![](images/[多易教育]-Flink-1.16.1文档-image44.png)

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 滑动窗口</span>**

<span style="color: inherit; background-color: rgba(183,237,177,0.8)">每5秒统计一次最近10s的订单总数  窗口大小是  10s  滑动步进 5s</span>

窗口1:    \[11:00:00  11:00:10)

窗口2:   \[11:00:05  11:00:15)



![](images/[多易教育]-Flink-1.16.1文档-image45.png)

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 会话窗口</span>**

![](images/[多易教育]-Flink-1.16.1文档-image46.png)

<span style="color: rgb(31,35,41); background-color: inherit">没有固定的窗口长度，也没有固定的滑动步长，而是根据数据流中前后两个事件的时间间隔是否超出阈值（session gap）来划分；</span>

## 5.2 <span style="color: rgb(31,35,41); background-color: inherit">窗口计算API模板</span>

### **<span style="color: rgb(46,161,33); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(46,161,33); background-color: inherit"> KeyedWindows</span>**

```java
stream
       .keyBy(...)               <-  keyed versus non-keyed windows
       .window(...)              <-  required: "assigner"
      [.trigger(...)]            <-  optional: "trigger" (else default trigger)
      [.evictor(...)]            <-  optional: "evictor" (else no evictor)
      [.allowedLateness(...)]    <-  optional: "lateness" (else zero)
      [.sideOutputLateData(...)] <-  optional: "output tag" (else no side output for late data)
       .reduce/aggregate/apply()      <-  required: "function"
      [.getSideOutput(...)]      <-  optional: "output tag"
```

### **<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> NonKeyedWindows</span>**

在keyby之前调用窗口函数 ,是全局<span style="color: rgb(46,161,33); background-color: rgba(98,210,86,1)">窗口计算</span> , 一般建议窗口函数在keyby后执行

```java
stream
       .windowAll(...)           <-  required: "assigner"
      [.trigger(...)]            <-  optional: "trigger" (else default trigger)
      [.evictor(...)]            <-  optional: "evictor" (else no evictor)
      [.allowedLateness(...)]    <-  optional: "lateness" (else zero)
      [.sideOutputLateData(...)] <-  optional: "output tag" (else no side output for late data)
       .reduce/aggregate/apply()      <-  required: "function"
      [.getSideOutput(...)]      <-  optional: "output tag"
```

## 5.3  窗口类型指派API

#### key前 :   时间窗口  (如下图)

![](images/[多易教育]-Flink-1.16.1文档-image-26.png)

![](images/[多易教育]-Flink-1.16.1文档-image-28.png)

<span style="color: inherit; background-color: rgba(183,237,177,0.8)">keyBy前的代码模板  [单并行 , 全局]</span>

```java
/**
 * 所有的需求都是处理时间语义下进行的
 */
// 加载数据  
DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
SingleOutputStreamOperator<LogBean> logBeans = data.map(new MapFunction<String, LogBean>() {
    @Override
    public LogBean map(String value) throws Exception {
        String[] arr = value.split(",");
        LogBean logBean = LogBean.of(Long.parseLong(arr[0]), arr[1], arr[2], Long.parseLong(arr[3]));
        return logBean;
    }
});

AllWindowedStream<LogBean, TimeWindow> windowed01 = logBeans.windowAll(TumblingProcessingTimeWindows.of(Time.seconds(10)));
AllWindowedStream<LogBean, TimeWindow> windowed02 = logBeans.windowAll(SlidingProcessingTimeWindows.of(Time.seconds(10), Time.seconds(5)));
// 和时间没关系
AllWindowedStream<LogBean, GlobalWindow> windowed03 = logBeans.countWindowAll(10);
AllWindowedStream<LogBean, GlobalWindow> windowed04 = logBeans.countWindowAll(10, 5);
/**
 * keyBy之间前 的开窗  都是全局窗口  并行度为1
 * windowAll  时间
 * countWindowAll  计数
 */

/**
 * 所有的需求都是事件时间语义下进行的
 *  时间的推进依据是水位线  数据流中没有水位线  不会触发窗口执行
 */
   logBeans.windowAll(TumblingEventTimeWindows.of(Time.seconds(10))) ;
   logBeans.windowAll(SlidingEventTimeWindows.of(Time.seconds(10) , Time.seconds(5))) ;
```



```java
/**
 * NonKeyed窗口，全局窗口
 */
//  处理时间语义，滚动窗口
source.windowAll(TumblingProcessingTimeWindows.of(Time.seconds(5)));
// 处理时间语义，滑动窗口
source.windowAll(SlidingProcessingTimeWindows.of(Time.seconds(5),Time.seconds(1)));
// 事件时间语义，滚动窗口 先分配水位线
source.windowAll(TumblingEventTimeWindows.of(Time.seconds(5)));
// 事件时间语义，滑动窗口 先分配水位线
source.windowAll(SlidingEventTimeWindows.of(Time.seconds(5),Time.seconds(1)));
// 计数滚动窗口
source.countWindowAll(100);
// 计数滑动窗口
source.countWindowAll(100,20);

/**
 * Keyed窗口
 */
KeyedStream<String, String> keyedStream = source.keyBy(s -> s);
// 处理时间语义，滚动窗口
keyedStream.window(TumblingProcessingTimeWindows.of(Time.seconds(5)));
// 处理时间语义，滑动窗口
keyedStream.window(SlidingProcessingTimeWindows.of(Time.seconds(5),Time.seconds(1)));
// 事件时间语义，滚动窗口
keyedStream.window(TumblingEventTimeWindows.of(Time.seconds(5)));
// 事件时间语义，滑动窗口
keyedStream.window(SlidingEventTimeWindows.of(Time.seconds(5),Time.seconds(1)));
// 计数滚动窗口  组内计数  触发窗口
keyedStream.countWindow(1000);
// 计数滑动窗口 组内计数  触发窗口
keyedStream.countWindow(1000,100);
```

## 5.4  开窗后聚合函数

### 5.4.1  增量和全量聚合

##### **<span style="color: rgb(31,35,41); background-color: inherit"> 窗口聚合算子，整体上分为两类</span>**

* <u><span style="color: rgb(31,35,41); background-color: inherit">增量聚合</span></u> <span style="color: rgb(31,35,41); background-color: inherit">算子，如min、max、minBy、maxBy、sum、reduce、aggregate</span>

(每摄入一条数据就会触发聚合计算 ,更新中间结果)

* <u><span style="color: rgb(31,35,41); background-color: inherit">全量聚合</span></u> <span style="color: rgb(31,35,41); background-color: inherit">算子，如apply、process  [迭代器] </span>

(将所有的数据缓存起来 ,窗口触发时再使用迭代器迭代出所有数据聚合)

##### <span style="color: rgb(31,35,41); background-color: inherit"> </span>**<span style="color: rgb(31,35,41); background-color: inherit">       两类聚合算子的底层区别</span>**

* <span style="color: rgb(31,35,41); background-color: inherit">增量聚合：一次取一条数据，用聚合函数对中间累加器更新；窗口触发时，取累加器输出结果；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">全量聚合：数据“攒”在状态容器中，窗口触发时，把整个窗口的数据交给聚合函数；</span>

![](images/[多易教育]-Flink-1.16.1文档-diagram-7.png)

### 5.4.2  增量聚合函数代码示例

#### Max maxBy   sum  reduce  aggregate

<span style="color: inherit; background-color: rgba(98,210,86,1)">aggregate    :  定制化返回值类型 </span>

```java
package com.doit.day06;


import com.doit.beans.OrdersBean;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.time.Duration;

/**
 * @Date: 2023/6/30
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: 一般对数据进行分组   开窗统计
 * 聚合  最大  最小   求和   平均  topN
 * 需求 :
 * 使用事件时间    每10s  每个城市   (订单总额  ,  订单总个数)
 * aggregate  增量聚合函数实现
 */
public class E04WindowedAgg {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        // 加载数据
        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
        // 解析数据

        SingleOutputStreamOperator<OrdersBean> ordersBeans = data.map(new MapFunction<String, OrdersBean>() {
            @Override
            public OrdersBean map(String value) throws Exception {

                OrdersBean ordersBean = null;
                try {
                    String[] arr = value.split(",");
                    ordersBean = new OrdersBean(Integer.parseInt(arr[0]),
                            arr[1],
                            Double.parseDouble(arr[2]),
                            arr[3],
                            Long.parseLong(arr[4])
                    );
                } catch (NumberFormatException e) {
                    ordersBean = new OrdersBean();
                }
                return ordersBean;
            }
        });
        // 分配水位线
        SingleOutputStreamOperator<OrdersBean> orderBeanWithWm = ordersBeans.assignTimestampsAndWatermarks(
                WatermarkStrategy.<OrdersBean>forBoundedOutOfOrderness(Duration.ofSeconds(1))
                        .withTimestampAssigner(new SerializableTimestampAssigner<OrdersBean>() {
                            @Override
                            public long extractTimestamp(OrdersBean element, long recordTimestamp) {
                                return element.getTs();
                            }
                        })
        );

        // 分组  城市
        KeyedStream<OrdersBean, String> keyed = orderBeanWithWm.keyBy(new KeySelector<OrdersBean, String>() {
            @Override
            public String getKey(OrdersBean value) throws Exception {
                return value.getCity();
            }
        });
        // 开窗
        WindowedStream<OrdersBean, String, TimeWindow> windowed = keyed.window(TumblingEventTimeWindows.of(Time.seconds(10)));
        // 计算
        /**
         * min  max  reduce  sum  返回值类型和输入是一致的
         * aggregate灵活度更高  可以自定义返回值类型
         * 参数一  输入类型
         * 参数二  中间结果   [城市 ,总额 , 总个数]
         * 参数三  输出类型   [城市 ,总额 , 总个数 , 平均]
         */

        SingleOutputStreamOperator<Tuple4<String, Double, Integer, Double>> res = windowed.aggregate(new AggregateFunction<OrdersBean, Tuple3<String, Double, Integer>, Tuple4<String, Double, Integer, Double>>() {
            // 中间结果初始化
            @Override
            public Tuple3<String, Double, Integer> createAccumulator() {
                return Tuple3.of("", 0.0d, 0);
            }

            //每流入一条数据  , 计算  组内
            @Override
            public Tuple3<String, Double, Integer> add(OrdersBean value, Tuple3<String, Double, Integer> accumulator) {
                accumulator.f0 = value.getCity();
                accumulator.f1 = accumulator.f1 + value.getMoney();
                accumulator.f2 += 1;
                return accumulator;
            }

            // 最后的结果数据   , 窗口触发时调用一次
            @Override
            public Tuple4<String, Double, Integer, Double> getResult(Tuple3<String, Double, Integer> accumulator) {
                return Tuple4.of(accumulator.f0, accumulator.f1, accumulator.f2, accumulator.f1 / accumulator.f2);
            }

            /**
             * 不用实现
             * @param a An accumulator to merge
             * @param b Another accumulator to merge
             * @return
             */
            @Override
            public Tuple3<String, Double, Integer> merge(Tuple3<String, Double, Integer> a, Tuple3<String, Double, Integer> b) {
                return null;
            }
        });
        res.print() ;

        see.execute() ;


    }
}
```



### 5.4.3 全量聚合函数代码示例&#xA;

#### <span style="color: inherit; background-color: rgba(98,210,86,1)">apply函数   </span>

参数: Window  可以获取窗口信息  起始  结束  最大时间戳

```java
apply(new  WindowFunction<IN, OUT,KEY ,W>){
public void apply(String key, TimeWindow window, Iterable<OrdersBean> input, Collector<Tuple3<String, Double, Integer>> out)  
  {
    //  获取窗口信息 
   }
}
```

```java
package com.doit.day06;


import com.doit.beans.OrdersBean;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.time.Duration;

/**
 * @Date: 2023/6/30
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: 一般对数据进行分组   开窗统计
 * 聚合  最大  最小   求和   平均  topN
 * 需求 :
 * 使用事件时间    每10s  每个城市   (订单总额  ,  订单总个数)
 */
public class E03WindowedAgg {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        // 加载数据
        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
        // 解析数据

        SingleOutputStreamOperator<OrdersBean> ordersBeans = data.map(new MapFunction<String, OrdersBean>() {
            @Override
            public OrdersBean map(String value) throws Exception {

                OrdersBean ordersBean = null;
                try {
                    String[] arr = value.split(",");
                    ordersBean = new OrdersBean(Integer.parseInt(arr[0]),
                            arr[1],
                            Double.parseDouble(arr[2]),
                            arr[3],
                            Long.parseLong(arr[4])
                    );
                } catch (NumberFormatException e) {
                    ordersBean = new OrdersBean();
                }
                return ordersBean;
            }
        });

        // 分配水位线
        SingleOutputStreamOperator<OrdersBean> orderBeanWithWm = ordersBeans.assignTimestampsAndWatermarks(
                WatermarkStrategy.<OrdersBean>forBoundedOutOfOrderness(Duration.ofSeconds(1))
                        .withTimestampAssigner(new SerializableTimestampAssigner<OrdersBean>() {
                            @Override
                            public long extractTimestamp(OrdersBean element, long recordTimestamp) {
                                return element.getTs();
                            }
                        })
        );

        // 分组  城市
        KeyedStream<OrdersBean, String> keyed = orderBeanWithWm.keyBy(new KeySelector<OrdersBean, String>() {
            @Override
            public String getKey(OrdersBean value) throws Exception {
                return value.getCity();
            }
        });
        // 开窗
        WindowedStream<OrdersBean, String, TimeWindow> windowed = keyed.window(TumblingEventTimeWindows.of(Time.seconds(10)));

    
     

        // 计算 (聚合)   (城市 , 订单总额 , 总个数)返回值和输入不一致   apply  process   aggregate
        /**
         * apply是全局集合窗口 , 收集到窗口中的所有的数据后 一次性计算
         * 参数一  输入类型
         * 参数二  输出类型
         * 参数三  key的类型
         * 参数四  窗口对象
         */
        SingleOutputStreamOperator<Tuple3<String, Double, Integer>> res = windowed.apply(new WindowFunction<OrdersBean, Tuple3<String, Double, Integer>, String, TimeWindow>() {

            /**
             * 窗口内部  一组数据执行一次
             * @param key The key for which this window is evaluated.
             * @param window The window that is being evaluated.
             * @param input The elements in the window being evaluated.
             * @param out A collector for emitting elements.
             * @throws Exception
             */
            @Override
            public void apply(String key, TimeWindow window, Iterable<OrdersBean> input, Collector<Tuple3<String, Double, Integer>> out) throws Exception {
                String city = key;
                int cnt = 0;
                double money = 0D;
                ;

               /* window.getStart() ;
                window.getEnd() ;*/
                for (OrdersBean ordersBean : input) {
                    cnt++;
                    if (ordersBean != null) {
                        money += ordersBean.getMoney();
                    }
                }
                out.collect(Tuple3.of(city, money, cnt));
            }
        });

        // 输出
        res.print() ;
        see.execute() ;


    }
}
```



#### **<span style="color: inherit; background-color: rgba(183,237,177,0.8)">process函数  </span>**

<span style="color: inherit; background-color: rgb(251,191,188)">参数:  Context   获取窗口信息  获取水位线   窗口状态 </span>

* 可以实现  min  max   maxBy  sum   avg &#x20;**&#x20;topN**

```java
 windowed.process(new ProcessWindowFunction<OrdersBean, Tuple3<String,Double,Integer>, String, TimeWindow>() {
            @Override
            public void process(String key, ProcessWindowFunction<OrdersBean, Tuple3<String, Double, Integer>, String, TimeWindow>.Context context, Iterable<OrdersBean> elements, Collector<Tuple3<String, Double, Integer>> out) throws Exception {
            }
    }
```

```java
package com.doit.day06;


import com.doit.beans.OrdersBean;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.datastream.WindowedStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.SlidingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.time.Duration;

/**
 * @Date: 2023/6/30
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: 使用事件时间
 * 每5s  统计一下最近10s   每个城市的  订单的总额和平均金额
 */
public class E05WindowedProcess {
    public static void main(String[] args) {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        //加载数据
        // 处理数据
        // 分配水位线
        // 分组
        // 加载数据
        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
        // 解析数据

        SingleOutputStreamOperator<OrdersBean> ordersBeans = data.map(new MapFunction<String, OrdersBean>() {
            @Override
            public OrdersBean map(String value) throws Exception {

                OrdersBean ordersBean = null;
                try {
                    String[] arr = value.split(",");
                    ordersBean = new OrdersBean(Integer.parseInt(arr[0]),
                            arr[1],
                            Double.parseDouble(arr[2]),
                            arr[3],
                            Long.parseLong(arr[4])
                    );
                } catch (NumberFormatException e) {
                    ordersBean = new OrdersBean();
                }
                return ordersBean;
            }
        });
        // 分配水位线
        SingleOutputStreamOperator<OrdersBean> orderBeanWithWm = ordersBeans.assignTimestampsAndWatermarks(
                WatermarkStrategy.<OrdersBean>forBoundedOutOfOrderness(Duration.ofSeconds(1))
                        .withTimestampAssigner(new SerializableTimestampAssigner<OrdersBean>() {
                            @Override
                            public long extractTimestamp(OrdersBean element, long recordTimestamp) {
                                return element.getTs();
                            }
                        })
        );

        // 分组  城市
        KeyedStream<OrdersBean, String> keyed = orderBeanWithWm.keyBy(new KeySelector<OrdersBean, String>() {
            @Override
            public String getKey(OrdersBean value) throws Exception {
                return value.getCity();
            }
        });
        // 开窗
        WindowedStream<OrdersBean, String, TimeWindow> windowed = keyed.window(SlidingEventTimeWindows.of(Time.seconds(10), Time.seconds(5)));

        windowed.process(new ProcessWindowFunction<OrdersBean, Tuple3<String,Double,Integer>, String, TimeWindow>() {
            @Override
            public void process(String key, ProcessWindowFunction<OrdersBean, Tuple3<String, Double, Integer>, String, TimeWindow>.Context context, Iterable<OrdersBean> elements, Collector<Tuple3<String, Double, Integer>> out) throws Exception {
               // apply  中的参数2  Windows
                // process是一个context
                context.currentWatermark() ;
                context.globalState();

                TimeWindow window = context.window();
                window.getEnd() ;

                int  cnt = 0 ;
                double  money = 0.0d ;
                for (OrdersBean element : elements) {
                    cnt +=1 ;
                    money +=element.getMoney();
                }
                out.collect(Tuple3.of(key , money , cnt));


            }
        });
        // 聚合

        // 结果

        // 执行
    }
}
```

## 5.5 窗口触发

窗口触发时机  根据不同的窗口类型 ,满足指定的条件时就会触发&#x20;

keyBy前  全局窗口   &#x20;

* &#x20;    计数窗口  数据条数满足设置的大小 &#x20;

* &#x20;     时间窗口  根据时间&#x20;

keyby后 &#x20;

* &#x20;    计数窗口  根据条数&#x20;

* &#x20;     时间窗口  根据时间 推进



<span style="color: rgb(31,35,41); background-color: inherit">Flink中为各类内置的WindowsAssigner都设计了对应的默认Trigger；用来触发窗口的计算</span>

![](images/[多易教育]-Flink-1.16.1文档-image-22.png)

源代码 :

```java
public class EventTimeTrigger extends Trigger<Object, TimeWindow> {
    private static final long serialVersionUID = 1L;

    private EventTimeTrigger() {}
   // window.maxTimestamp()  窗口的结束时间   endTime
  // 窗口是否触发的逻辑 
    @Override
    public TriggerResult onElement(
            Object element, long timestamp, TimeWindow window, TriggerContext ctx)
            throws Exception {  // 事件ID = submit
        if ( ctx.getCurrentWatermark() >= window.maxTimestamp() || ) {
            // if the watermark is already past the window fire immediately
            return TriggerResult.FIRE;  // 执行  触发窗口 
        } else {
            ctx.registerEventTimeTimer(window.maxTimestamp());
            return TriggerResult.CONTINUE;  // 继续不触发
        }
    }

    @Override
    public TriggerResult onEventTime(long time, TimeWindow window, TriggerContext ctx) {
        return time == window.maxTimestamp() ? TriggerResult.FIRE : TriggerResult.CONTINUE;
    }

    @Override
    public TriggerResult onProcessingTime(long time, TimeWindow window, TriggerContext ctx)
            throws Exception {
        return TriggerResult.CONTINUE;
    }

    @Override
    public void clear(TimeWindow window, TriggerContext ctx) throws Exception {
        ctx.deleteEventTimeTimer(window.maxTimestamp());
    }

    @Override
    public boolean canMerge() {
        return true;
    }

    @Override
    public void onMerge(TimeWindow window, OnMergeContext ctx) {
        // only register a timer if the watermark is not yet past the end of the merged window
        // this is in line with the logic in onElement(). If the watermark is past the end of
        // the window onElement() will fire and setting a timer here would fire the window twice.
        long windowMaxTimestamp = window.maxTimestamp();
        if (windowMaxTimestamp > ctx.getCurrentWatermark()) {
            ctx.registerEventTimeTimer(windowMaxTimestamp);
        }
    }

    @Override
    public String toString() {
        return "EventTimeTrigger()";
    }

    /**
     * Creates an event-time trigger that fires once the watermark passes the end of the window.
     *
     * <p>Once the trigger fires all elements are discarded. Elements that arrive late immediately
     * trigger window evaluation with just this one element.
     */
    public static EventTimeTrigger create() {
        return new EventTimeTrigger();
    }
}
```

<span style="color: rgb(31,35,41); background-color: inherit">一般情况下不需要自己去重写Trigger；除非有特别的需求；</span>



自定义触发器: 触发器用来触发窗口执行计算 , 不会回收窗口  , 一个窗口可以被触发多次&#x20;

![](images/[多易教育]-Flink-1.16.1文档-diagram-8.png)

<span style="color: rgb(31,35,41); background-color: inherit">Evictor 是窗口触发前，或者触发后，对窗口中的数据移除的机制；</span>

1. <span style="color: rgb(31,35,41); background-color: inherit">当触发条件成立时，先调用Evictor的evictBefore( )方法 来进行元素移除；  </span>

2. <span style="color: rgb(31,35,41); background-color: inherit">然后，计算； </span>

3) <span style="color: rgb(31,35,41); background-color: inherit">计算完后，还会再调用Evictor的 evictAfter( )方法，来进行元素移除；</span>

&#x20;

![](images/[多易教育]-Flink-1.16.1文档-image48.png)

### 自定义触发器

**<span style="color: rgb(31,35,41); background-color: inherit">背景：不光要按照滚动时间窗口的时间条件触发，还要根据数据中的eventId=e0x来触发</span>**

```java


class MyEventTimeTrigger extends Trigger<Tuple2<EventBean2,Integer>, TimeWindow>{
​
    private MyEventTimeTrigger() {}
​
    /**
     * 来一条数据时，需要检查watermark是否已经越过窗口结束点需要触发
     */
    @Override
    public TriggerResult onElement(
            Tuple2<EventBean2,Integer> element, long timestamp, TimeWindow window, TriggerContext ctx)
            throws Exception {
        // 如果窗口结束点 <= 当前的watermark
        if (window.maxTimestamp() <= ctx.getCurrentWatermark()) {
            return TriggerResult.FIRE;
        } else {
            // 注册定时器，定时器的触发时间为： 窗口的结束点时间
            ctx.registerEventTimeTimer(window.maxTimestamp());
​
            // 判断，当前数据的用户行为事件id是否等于e0x，如是，则触发
            if("e0x".equals(element.f0.getEventId())) return TriggerResult.FIRE;
​
            return TriggerResult.CONTINUE;
        }
    }
​
    /**
     * 当事件时间定时器的触发时间（窗口的结束点时间）到达了，检查是否满足触发条件
     * 下面的方法，是定时器在调用
     */
    @Override
    public TriggerResult onEventTime(long time, TimeWindow window, TriggerContext ctx) {
        return time == window.maxTimestamp() ? TriggerResult.FIRE : TriggerResult.CONTINUE;
    }
​
    /**
     * 当处理时间定时器的触发时间（窗口的结束点时间）到达了，检查是否满足触发条件
     */
    @Override
    public TriggerResult onProcessingTime(long time, TimeWindow window, TriggerContext ctx)
            throws Exception {
        return TriggerResult.CONTINUE;
    }
​
    @Override
    public void clear(TimeWindow window, TriggerContext ctx) throws Exception {
        ctx.deleteEventTimeTimer(window.maxTimestamp());
    }
​
    @Override
    public boolean canMerge() {
        return true;
    }
​
    @Override
    public void onMerge(TimeWindow window, OnMergeContext ctx) {
        long windowMaxTimestamp = window.maxTimestamp();
        if (windowMaxTimestamp > ctx.getCurrentWatermark()) {
            ctx.registerEventTimeTimer(windowMaxTimestamp);
        }
    }
​
    public static MyEventTimeTrigger create() {
        return new MyEventTimeTrigger();
    }
}

  Evictor代码示例
背景：不光要按照滚动时间窗口的时间条件移除数据，还要将eventId=e0x的数据移除
class MyTimeEvictor implements Evictor<Object, TimeWindow> {
    private static final long serialVersionUID = 1L;
​
    private final long windowSize;
    private final boolean doEvictAfter;
​
    public MyTimeEvictor(long windowSize) {
        this.windowSize = windowSize;
        this.doEvictAfter = false;
    }
​
    public MyTimeEvictor(long windowSize, boolean doEvictAfter) {
        this.windowSize = windowSize;
        this.doEvictAfter = doEvictAfter;
    }
​
    /**
     * 窗口触发前，调用
     */
    @Override
    public void evictBefore(
            Iterable<TimestampedValue<Object>> elements, int size,TimeWindow window, EvictorContext ctx) {
        if (!doEvictAfter) {
            evict(elements, size, ctx);
        }
    }
​
    /**
     * 窗口触发后，调用
     */
    @Override
    public void evictAfter(
            Iterable<TimestampedValue<Object>> elements, int size, TimeWindow window, EvictorContext ctx) {
        if (doEvictAfter) {
            evict(elements, size, ctx);
        }
    }
​
    /**
     * 元素移除的核心逻辑
     */
    private void evict(Iterable<TimestampedValue<Object>> elements, int size, EvictorContext ctx) {
        if (!hasTimestamp(elements)) {
            return;
        }
​
        long currentTime = getMaxTimestamp(elements);
        long evictCutoff = currentTime - windowSize;
​
        for (Iterator<TimestampedValue<Object>> iterator = elements.iterator();
             iterator.hasNext(); ) {
            TimestampedValue<Object> record = iterator.next();
​
            Tuple2<EventBean2,Integer> tuple = (Tuple2<EventBean2, Integer>) record.getValue();
​
            // 加了一个条件： 数据的eventId=e0x，也移除
            if (record.getTimestamp() <= evictCutoff  || tuple.f0.getEventId().equals("e0x")) {
                iterator.remove();
            }
        }
    }
​
    private boolean hasTimestamp(Iterable<TimestampedValue<Object>> elements) {
        Iterator<TimestampedValue<Object>> it = elements.iterator();
        if (it.hasNext()) {
            return it.next().hasTimestamp();
        }
        return false;
    }
​
    /**
     * 用于计算移除的时间截止点
     */
    private long getMaxTimestamp(Iterable<TimestampedValue<Object>> elements) {
        long currentTime = Long.MIN_VALUE;
        for (Iterator<TimestampedValue<Object>> iterator = elements.iterator();
             iterator.hasNext(); ) {
            TimestampedValue<Object> record = iterator.next();
            currentTime = Math.max(currentTime, record.getTimestamp());
        }
        return currentTime;
    }
​
​
    public static   MyTimeEvictor  of(Time windowSize) {
        return new MyTimeEvictor(windowSize.toMilliseconds());
    }
}
```

## 5.6  清理器

窗口触发有触发器 ,. 当窗口触发后要清理掉窗口(数据) :

&#x20;windowed.evictor();



## 5.7 处理迟到数据

针对延迟数据的处理

1 . 使用水位线的延迟策略 , 水位线的推进放缓 , 解决部分延迟问题  &#x20;

2 . <span style="color: inherit; background-color: rgb(251,191,188)">使用allowLateNess(2s) ,</span> 在窗口触发2s内有迟到的数据流入 , 再次触发窗口重新计算

3 . 在允许的延迟时间内没有到达的数据  放在测流中&#x20;

![](images/[多易教育]-Flink-1.16.1文档-image-24.png)

```java
OutputTag late_tag = new OutputTag("late order", TypeInformation.of(OrdersBean.class));
SingleOutputStreamOperator res = windowed
        /**
         * 窗口中的数据
         *   在  windw.end <  WM <  窗口结束 +  2s内流入   窗口再次计算
         *   在 WM  >  窗口结束 +  2s   进入到测流中
         */
        .allowedLateness(Time.seconds(2))
        /**
         * 如果窗口的结束时20000  水位线 >= 20000的时候窗口正常触发执行
         *    22000  -->  WM: 20000   触发窗口  不回收窗口
         *    24000   -->   WM  >   :22000(窗口结束+ lateness)   回收窗口
         *       后面的数据  流入到测流中
         * 设置了allowedLateness(Time.seconds(2)) 触发窗口计算  不一定回收窗口
         */
        .sideOutputLateData(late_tag)
        .sum("money");
    //    res.print() ;
        // 获取测流数据
        res.getSideOutput(late_tag).print() ;
```

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 延迟处理的方案</span>**

* <span style="color: rgb(31,35,41); background-color: inherit">小延迟（乱序），用watermark容错 （减慢时间的推进，让本已迟到的数据被认为没有迟到）</span>

* <span style="color: rgb(31,35,41); background-color: inherit">中延迟（乱序），用allowedLateness （允许一定限度内的迟到，并对迟到数据重新触发窗口计算）</span>

* <span style="color: rgb(31,35,41); background-color: inherit">大延迟（乱序），用sideOutputLateData （将超出allowedLateness的迟到数据输出到一个侧流中）</span>

```java
package com.doit.day06;


import com.doit.beans.LogBean;
import com.doit.beans.OrdersBean;
import com.sun.xml.internal.ws.api.pipe.Tube;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.*;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.evictors.TimeEvictor;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;

import java.time.Duration;

/**
 * @Date: 2023/6/30
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: 使用事件时间
 * 每5s  统计一下最近10s   每个城市的  订单的总额和平均金额
 */
public class E07WindowedLateness {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
        // 解析数据
        SingleOutputStreamOperator<OrdersBean> ordersBeans = data.map(new MapFunction<String, OrdersBean>() {
            @Override
            public OrdersBean map(String value) throws Exception {

                OrdersBean ordersBean = null;
                try {
                    String[] arr = value.split(",");
                    ordersBean = new OrdersBean(Integer.parseInt(arr[0]),
                            arr[1],
                            Double.parseDouble(arr[2]),
                            arr[3],
                            Long.parseLong(arr[4])
                    );
                } catch (NumberFormatException e) {
                    ordersBean = new OrdersBean();
                }
                return ordersBean;
            }
        });
        // 分配水位线
        SingleOutputStreamOperator<OrdersBean> orderBeanWithWm = ordersBeans.assignTimestampsAndWatermarks(
                WatermarkStrategy.<OrdersBean>forBoundedOutOfOrderness(Duration.ofSeconds(1))
                        .withTimestampAssigner(new SerializableTimestampAssigner<OrdersBean>() {
                            @Override
                            public long extractTimestamp(OrdersBean element, long recordTimestamp) {
                                return element.getTs();
                            }
                        })
        );

        // 分组  城市
        KeyedStream<OrdersBean, String> keyed = orderBeanWithWm.keyBy(new KeySelector<OrdersBean, String>() {
            @Override
            public String getKey(OrdersBean value) throws Exception {
                return value.getCity();
            }
        });

        OutputTag<OrdersBean> lateDataTag = new OutputTag<>("lateData", TypeInformation.of(new TypeHint<OrdersBean>() {}));
        SingleOutputStreamOperator<OrdersBean> processData = keyed.window(TumblingEventTimeWindows.of(Time.seconds(10)))
                .allowedLateness(Time.seconds(2))
                .sideOutputLateData(lateDataTag)
                // 正常的数据
                .process(new ProcessWindowFunction<OrdersBean, OrdersBean, String, TimeWindow>() {
                    @Override
                    public void process(String s, ProcessWindowFunction<OrdersBean, OrdersBean, String, TimeWindow>.Context context, Iterable<OrdersBean> elements, Collector<OrdersBean> out) throws Exception {
                        for (OrdersBean element : elements) {
                            out.collect(element);
                        }
                    }
                });
        // 获取迟到数据 9
     SideOutputDataStream<OrdersBean> lateData = processData.getSideOutput(lateDataTag);
     lateData.print() ;

      //  lateData.print() ;
        see.execute() ;

    }
}
```

**<span style="color: rgb(31,35,41); background-color: rgba(247,105,100,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span>**<span style="color: rgb(31,35,41); background-color: inherit">注意正确理解延迟时间！</span>

<span style="color: rgb(31,35,41); background-color: inherit">如：allowedLateness（2s），表示：</span>

<span style="color: rgb(31,35,41); background-color: inherit">如果watermark（此刻的事件时间）推进到了 A窗口结束点后2s，如果还来A窗口的数据，就算迟到，就不会再去触发A窗口的计算，而是输出到迟到测流了</span>

# 6. Flink高级编程

## 6.1  RichFunction

Map  flatMap  filter 等都有对应的RichXX



```java
/*
c * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements.  See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership.  The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License.  You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.flink.api.common.functions;

import org.apache.flink.annotation.Public;
import org.apache.flink.configuration.Configuration;

import java.io.Serializable;

/**
 * An abstract stub implementation for rich user-defined functions. Rich functions have additional
 * methods for initialization ({@link #open(Configuration)}) and teardown ({@link #close()}), as
 * well as access to their runtime execution context via {@link #getRuntimeContext()}.
 */
@Public
public abstract class AbstractRichFunction implements RichFunction, Serializable {

    @Override
    public void setRuntimeContext(RuntimeContext t) {
        this.runtimeContext = t;
    }

    @Override
    public RuntimeContext getRuntimeContext() {
        if (this.runtimeContext != null) {
            return this.runtimeContext;
        } else {
            throw new IllegalStateException("The runtime context has not been initialized.");
        }
    }

    @Override
    public IterationRuntimeContext getIterationRuntimeContext() {
        if (this.runtimeContext == null) {
            throw new IllegalStateException("The runtime context has not been initialized.");
        } else if (this.runtimeContext instanceof IterationRuntimeContext) {
            return (IterationRuntimeContext) this.runtimeContext;
        } else {
            throw new IllegalStateException("This stub is not part of an iteration step function.");
        }
    }

    // --------------------------------------------------------------------------------------------
    //  Default life cycle methods
    // --------------------------------------------------------------------------------------------

    @Override
    public void open(Configuration parameters) throws Exception {}

    @Override
    public void close() throws Exception {}
}

RuntimeContext  . 
1) 获取状态
2) 获取计数器
3) 获取作业信息

```

![](images/[多易教育]-Flink-1.16.1文档-image-23.png)

## 6.2  多流函数

### 6.2.1 **<span style="color: rgb(31,35,41); background-color: inherit">connect连接</span>**

**<span style="color: rgb(31,35,41); background-color: inherit">（DataStream,DataStream→ConnectedStreams）</span>**

<span style="color: rgb(31,35,41); background-color: inherit">connect翻译成中文意为连接，可以将两个数据类型一样也可以类型不一样DataStream连接成一个新的ConnectedStreams。需要注意的是，connect方法与union方法不同，虽然调用connect方法将两个流连接成一个新的ConnectedStreams，</span>**<span style="color: rgb(31,35,41); background-color: inherit">但是里面的两个流依然是相互独立的</span>**<span style="color: rgb(31,35,41); background-color: inherit">，</span>**<u><span style="color: rgb(31,35,41); background-color: inherit">这个方法最大的好处是可以让两个流共享State状态</span></u>**<span style="color: rgb(31,35,41); background-color: inherit">，状态相关的内容在后面章节讲解</span>

![](images/[多易教育]-Flink-1.16.1文档-image-20.png)

![](images/[多易教育]-Flink-1.16.1文档-diagram-9.png)

> 将两个相同或者不同类型的流合并在一起  形成一个ConnectStream
>
> 保留了原来流的界线, 两个流还是分别处理的 :&#x20;
>
> 1\) 返回值类型是统一的
>
> 2\) 两个流之间可以 公用状态数据  (可以容错的变量)

```java
package com.doe.high;


import com.doe.beans.HeroBean;
import com.doe.beans.OrdersBean;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.ConnectedStreams;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.co.CoMapFunction;
import org.apache.flink.streaming.api.functions.co.RichCoMapFunction;

/**
 * @Date: 2024/1/3
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 */
public class Function01Connect02 {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);

        DataStreamSource<OrdersBean> ds1 = see.fromElements(
                new OrdersBean(1, "zss", "bj", 100, 1000L),
                new OrdersBean(2, "zss", "bj", 100, 1000L),
                new OrdersBean(3, "zss", "bj", 100, 1000L),
                new OrdersBean(4, "zss", "bj", 100, 1000L)
        );

        DataStreamSource<HeroBean> ds2 = see.fromElements(
                new HeroBean(1, "zs", 99),
                new HeroBean(1, "zs", 99),
                new HeroBean(1, "zs", 99),
                new HeroBean(1, "zs", 99)
        );

        ds1.connect(ds2)
                .keyBy("city" , "name")
                .map(new RichCoMapFunction<OrdersBean, HeroBean, String>() {
            ValueState<String> state ;
            @Override
            public void open(Configuration parameters) throws Exception {

               state = getRuntimeContext().getState(new ValueStateDescriptor<String>("v", String.class, "doe"));

            }

            @Override
            public String map1(OrdersBean value) throws Exception {
                return value.toString() + state.value();
            }

            @Override
            public String map2(HeroBean value) throws Exception {
                return value.toString()+state.value() ;
            }
        }).print() ;

        see.execute() ;


    }


}
```

### 6.2.2 union

**<span style="color: rgb(31,35,41); background-color: inherit"> union 合并（DataStream * → DataStream）</span>**

<span style="color: rgb(31,35,41); background-color: inherit">该方法可以将两个或者多个数据类型一致的DataStream合并成一个DataStream。DataStream&lt;T&gt; union(DataStream&lt;T&gt;… streams)可以看出DataStream的union方法的参数为可变参数，即可以合并两个或多个</span> <u><span style="color: rgb(31,35,41); background-color: inherit">数据类型一致</span></u> <span style="color: rgb(31,35,41); background-color: inherit">的DataStream。</span>

```java
DataStreamSource<Integer> ds1 = see.fromElements(1, 2, 3, 4, 5, 6, 7);
DataStreamSource<Integer> ds2 = see.fromElements(1, 2, 3, 4, 5, 6, 7);
DataStream<Integer> union = ds1.union(ds2);
union.map(e->e).print() ;
```

### 6.2.3 join

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">Window Join是利用Flink的窗口的机制，</span>**<span style="color: inherit; background-color: rgba(255,246,122,0.8)">先将数据缓存在Window State中</span>**<span style="color: inherit; background-color: rgba(255,246,122,0.8)">，当窗口触发计算时，再执行join操作，所以只有两个流中的数据在同一个</span>**<span style="color: inherit; background-color: rgba(255,246,122,0.8)">时间窗口</span>**<span style="color: inherit; background-color: rgba(255,246,122,0.8)">内并且关联条件</span>**<span style="color: inherit; background-color: rgba(255,246,122,0.8)">相等</span>**<span style="color: inherit; background-color: rgba(255,246,122,0.8)">的数据才能被连接在一起。</span>在使用Window Join时，需要指定两个流中的join条件，即KeySelector，**两个流的KeySelector必须是同一种类型且相等才可以**。然后再传入指定Window Assinger划分对应的时间窗口。最后在apply方法中使用JoinFunction或FlatJoinFunction对数据流中的数据进行关联，并输出最终的结果。在Flink中，Window Join支持TumblingWindow Join、SlidingWindow Join和SessionWidnow Join这三种，并且支持Processing Time和Event Time的类型窗口。下面是Window Join各个方法的使用规范：

只能做到等值内连接&#x20;

<span style="color: rgb(216,57,49); background-color: inherit">事件时间语义代码</span>

```java
package com.doe.high;


import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.JoinFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;

/**
 * @Date: 2024/1/3
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 */
public class FunctionJoin {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        // uid,name ,ts
        DataStreamSource<String> userStream = see.socketTextStream("doe01", 6666);
        // oid , money, uid, ts
        DataStreamSource<String> orderStream = see.socketTextStream("doe01", 7777);

        SingleOutputStreamOperator<UserBean> userBeans = userStream.map(new MapFunction<String, UserBean>() {
            @Override
            public UserBean map(String value) throws Exception {
                String[] arr = value.split(",");
                return new UserBean(Integer.parseInt(arr[0]), arr[1], Long.parseLong(arr[2]));
            }
        });

        SingleOutputStreamOperator<OrderBean> orderBeans = orderStream.map(new MapFunction<String, OrderBean>() {
            @Override
            public OrderBean map(String value) throws Exception {
                String[] arr = value.split(",");
                return new OrderBean(Integer.parseInt(arr[0]), Double.parseDouble(arr[1]), Integer.parseInt(arr[2]), Long.parseLong(arr[3]));
            }
        });

        SingleOutputStreamOperator<UserBean> userBeanWm = userBeans.assignTimestampsAndWatermarks(WatermarkStrategy.<UserBean>forMonotonousTimestamps().withTimestampAssigner(new SerializableTimestampAssigner<UserBean>() {
            @Override
            public long extractTimestamp(UserBean element, long recordTimestamp) {
                return element.getTs();
            }
        }));

        SingleOutputStreamOperator<OrderBean> orderBeanWm = orderBeans.assignTimestampsAndWatermarks(WatermarkStrategy.<OrderBean>forMonotonousTimestamps().withTimestampAssigner(new SerializableTimestampAssigner<OrderBean>() {
            @Override
            public long extractTimestamp(OrderBean element, long recordTimestamp) {
                return element.getTs();
            }
        }));

        /**
         * 两个关联的数据流分别分配水位线 
         * 只有两个数据流对应的窗口 比如 流1 [10  20]  和流2  [10  20] 都触发了窗口计算 :
         *    两个流中的数据才会按照对应的关联条件进行等值关联 然后进行输出
         */

        DataStream<String> res = userBeanWm.join(orderBeanWm)
                .where(user -> user.getUid())
                .equalTo(orders -> orders.getUid())
                .window(TumblingEventTimeWindows.of(Time.seconds(10)))
                .apply(new JoinFunction<UserBean, OrderBean, String>() {
                    @Override
                    public String join(UserBean first, OrderBean second) throws Exception {
                        return second.getOid() + "," + second.getMoney() + "," + second.getTs() +","+first.getName();
                    }
                });

        res.print() ;

        see.execute() ;


    }
}
```





处理时间语义

```java
package com.doit.day07;


import org.apache.flink.api.common.functions.FlatJoinFunction;
import org.apache.flink.api.common.functions.JoinFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.JoinedStreams;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;

/**
 * @Date: 2023/7/1
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 */
public class E04JoinFunction {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
         //用户    <uid,name>
        DataStreamSource<String> data1 = see.socketTextStream("doitedu01", 8899);
        SingleOutputStreamOperator<Tuple2<String, String>> uidName = data1.map(new MapFunction<String, Tuple2<String, String>>() {
            @Override
            public Tuple2<String, String> map(String value) throws Exception {
                String[] arr = value.split(",");
                return Tuple2.of(arr[0], arr[1]);
            }
        });

        // 订单  <oid,money,uid>

        DataStreamSource<String> data2 = see.socketTextStream("doitedu01", 9988);
        SingleOutputStreamOperator<Tuple3<String, String, String>> oidMoneyUid = data2.map(line -> {
            String[] arr = line.split(",");
            return Tuple3.of(arr[0], arr[1], arr[2]);
        }).returns(TypeInformation.of(new TypeHint<Tuple3<String, String, String>>() {
        }));
   // 用户和订单关联   只能 等值关联
        // ds1  join  ds2    ds1主流  后续的时间推进  窗口标准
        DataStream<Tuple4<String, String, String, String>> res = uidName.join(oidMoneyUid)
                .where(tp2 -> tp2.f0)  // 主流关联字段  用户信息
                .equalTo(tp3 -> tp3.f2)   //被关联流的关联字段   订单
                .window(TumblingProcessingTimeWindows.of(Time.seconds(60)))
                // oid , money , uid , name
                .apply(new JoinFunction<Tuple2<String, String>, Tuple3<String, String, String>, Tuple4<String, String, String, String>>() {
                    @Override
                    public Tuple4<String, String, String, String> join(Tuple2<String, String> first, Tuple3<String, String, String> second) throws Exception {
                            return Tuple4.of(second.f0, second.f1, second.f2, first.f1);
                    }
                });

/*
      uidName.join(oidMoneyUid)
                .where(tp2 -> tp2.f0)  // 主流关联字段  用户信息
                .equalTo(tp3 -> tp3.f2)   //被关联流的关联字段   订单
                .window(TumblingProcessingTimeWindows.of(Time.seconds(60)))
                        .apply(new FlatJoinFunction<Tuple2<String, String>, Tuple3<String, String, String>,  Tuple4<String, String, String, String>>() {
                            @Override
                            public void join(Tuple2<String, String> first, Tuple3<String, String, String> second, Collector<Tuple4<String, String, String, String>> out) throws Exception {

                            }
                        });
*/


        res.print() ;
        see.execute() ;


    }
}
```

***<span style="color: inherit; background-color: rgb(251,191,188)">只有两个流的数据在同一个窗口中  且符合关联条件才会关联上</span>***

滚动

![](images/[多易教育]-Flink-1.16.1文档-image-25.png)

滑动&#x20;

![](images/[多易教育]-Flink-1.16.1文档-image-27.png)

会话

![](images/[多易教育]-Flink-1.16.1文档-image-21.png)

&#x20;  .window(EventTimeSessionWindows.withGap(Time.milliseconds(1)))

```java
//  .window(EventTimeSessionWindows.withGap(Time.seconds(10))) // 10s没有数据流入  触发会话窗口
//  .window(EventTimeSessionWindows.withDynamicGap(sessionWindowTimeGapExtractor)) // 动态时间   触发会话窗口

SessionWindowTimeGapExtractor sessionWindowTimeGapExtractor = new SessionWindowTimeGapExtractor() {
    
    @Override
    public long extract(Object element) {
        return 0;
    }
};


```

### 6.2.4 coGroup

<span style="color: rgb(31,35,41); background-color: inherit">coGroup本质上是上述join算子的底层算子；功能类似；</span>

&#x20;uidName.coGroup(oidMoneyUid)
&#x20;          .where(tp2 -> tp2.f0)  // 前流  用于关联的属性

.equalTo(tp3 -> tp3.f2)// 后流  用于关联的属性
&#x20;  .window(TumblingProcessingTimeWindows.of(Time.seconds(30)))

.apply(new CoGroupFunction({}))  // 能实现  join&#x20;

![](images/[多易教育]-Flink-1.16.1文档-diagram-10.png)

<span style="color: inherit; background-color: rgba(183,237,177,0.8)">coGropup(Iterable s1 , Iterable s2 , out)  对数据按照  制定的关联字段分组 , 一组key执行一次coGroup</span>

```java
package com.doit.day07;


import org.apache.flink.api.common.functions.CoGroupFunction;
import org.apache.flink.api.common.functions.JoinFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.windowing.assigners.EventTimeSessionWindows;
import org.apache.flink.streaming.api.windowing.assigners.SessionWindowTimeGapExtractor;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;

/**
 * @Date: 2023/7/1
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 */
public class E05CoGroupFunction {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
         //用户    <uid,name>
        DataStreamSource<String> data1 = see.socketTextStream("doitedu01", 8899);
        SingleOutputStreamOperator<Tuple2<String, String>> uidName = data1.map(new MapFunction<String, Tuple2<String, String>>() {
            @Override
            public Tuple2<String, String> map(String value) throws Exception {
                String[] arr = value.split(",");
                return Tuple2.of(arr[0], arr[1]);
            }
        });


        // 订单  <oid,money,uid>

        DataStreamSource<String> data2 = see.socketTextStream("doitedu01", 9988);
        SingleOutputStreamOperator<Tuple3<String, String, String>> oidMoneyUid = data2.map(line -> {
            String[] arr = line.split(",");
            return Tuple3.of(arr[0], arr[1], arr[2]);
        }).returns(TypeInformation.of(new TypeHint<Tuple3<String, String, String>>() {
        }));
        // 使用cogroup实现join

        DataStream<Tuple4<String, String, String, String>> res = uidName.coGroup(oidMoneyUid)
                .where(tp2 -> tp2.f0)  // 前流  用于关联的属性
                .equalTo(tp3 -> tp3.f2)// 后流  用于关联的属性
                .window(TumblingProcessingTimeWindows.of(Time.seconds(30)))
                .apply(new CoGroupFunction<Tuple2<String, String>, Tuple3<String, String, String>, Tuple4<String, String, String, String>>() {
                    /**
                     * ds1    join    ds2
                     * uid01 , zss     oid01, 100,uid01
                     *                 oid02, 100,uid01
                     *                 oid03, 100,uid01
                     * uid02 , lss
                     * 对数据按照  制定的关联字段分组 , 一组key执行一次coGroup
                     * @param first The records from the first input.  当前key左流的所有数据
                     * @param second The records from the second.       当前key右流的所有数据
                     * @param out A collector to return elements.
                     * @throws Exception
                     */
                    @Override
                    public void coGroup(Iterable<Tuple2<String, String>> first, Iterable<Tuple3<String, String, String>> second, Collector<Tuple4<String, String, String, String>> out) throws Exception {
                        // join   left  join  right  join  full join
                    /*    System.out.println(first);   // 1,zss     oid01   oid01
                        System.out.println(second);*/

                     /*     join
                     for (Tuple2<String, String> stringStringTuple2 : first) {
                            for (Tuple3<String, String, String> stringStringStringTuple3 : second) {
                                out.collect(Tuple4.of(stringStringStringTuple3.f0  ,stringStringStringTuple3.f1,stringStringStringTuple3.f2,stringStringTuple2.f1));
                            }
                        }*/
                        // left  join
                       //  1,zss    oid01   oid02
                        // 3 , ww
                        for (Tuple2<String, String> stringStringTuple2 : first) {
                            boolean  flag = false ;
                            for (Tuple3<String, String, String> stringStringStringTuple3 : second) {
                                //uid , name , oid , money
                                out.collect(Tuple4.of(stringStringTuple2.f0  ,stringStringTuple2.f1,stringStringStringTuple3.f0,stringStringStringTuple3.f1));
                                flag = true ;
                            }
                            if(!flag){
                                out.collect(Tuple4.of(stringStringTuple2.f0  ,stringStringTuple2.f1,null , null));
                            }
                        }

                        // left  join
                        
                  
                        
                    }
                });

        res.print() ;


        see.execute() ;


    }
}
```

### 6.2.5 广播流

<span style="color: rgb(31,35,41); background-color: inherit">在开发过程中，如果遇到需要下发/广播配置、规则等</span>**<span style="color: rgb(31,35,41); background-color: inherit">低吞吐事件流</span>**<span style="color: rgb(31,35,41); background-color: inherit">到下游所有task 时，就可以使用 Broadcast State 特性。下游的 task 接收这些配置、规则并保存为 BroadcastState, 将这些配置应用到另一个数据流的计算中 。 </span>

使用广播流的常见场景是在任务执行期间共享静态数据，例如在每个任务中使用相同的配置信息或数据集。广播流可以有效地将这些数据发送给所有任务，以避免在任务之间进行网络通信。这在一些需要在本地访问共享数据的情况下非常有用。

Flink中的广播流（Broadcast Stream）是一种特殊类型的流，用于将数据广播给所有并行任务。它可以用于将静态数据或配置信息发送到所有任务，以便任务能够在本地访问这些数据，而无需通过网络进行通信。

![](images/[多易教育]-Flink-1.16.1文档-diagram-11.png)



![](images/[多易教育]-Flink-1.16.1文档-image22.png)

**<span style="color: rgb(216,57,49); background-color: inherit">广播流及广播状态基础逻辑示意图</span>**



<span style="color: inherit; background-color: rgb(251,191,188)">1  将一个流  转换成广播流 , 后续的才会广播数据</span>

<span style="color: inherit; background-color: rgb(251,191,188)">2  主流和广播流 connect </span>

3 将广播流的数据  存储在状态中  , 主流就可以获取数据

```java
package com.doit.day07;


import org.apache.flink.api.common.state.BroadcastState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.api.java.tuple.Tuple4;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.BroadcastStream;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.co.BroadcastProcessFunction;
import org.apache.flink.util.Collector;

/**
 * @Date: 2023/7/1
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 */
public class E06BroadCast {

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        // 会员等级信息 [维度表 / 规则]   广播流
        DataStreamSource<Tuple2<Integer, String>> ds1 = see.fromElements(
                Tuple2.of(1, "普通会员"),
                Tuple2.of(2, "白银会员"),
                Tuple2.of(3, "铂金会员"),
                Tuple2.of(4, "钻石会员")
        );
        数据在状态后端中的存储结构 , 广播流只支持Map类型
        MapStateDescriptor<Integer, Tuple2<Integer, String>> mapStateDescriptor = new MapStateDescriptor<>("level", TypeInformation.of(new TypeHint<Integer>() {
        }), TypeInformation.of(new TypeHint<Tuple2<Integer, String>>() {
        }));
        //-------------------广播流
        // 将个规则 流转换成广播流
        BroadcastStream<Tuple2<Integer, String>> broadcastStream = ds1.broadcast(mapStateDescriptor);

       //------------------主流
        //获取主流数据   <uid,event,levelid>
        DataStreamSource<String> ds2 = see.socketTextStream("doitedu01", 8899);
        SingleOutputStreamOperator<Tuple3<String, String, String>> mainData = ds2.map(line -> {
            String[] arr = line.split(",");
            return Tuple3.of(arr[0], arr[1], arr[2]);
        }).returns(TypeInformation.of(new TypeHint<Tuple3<String, String, String>>() {
        }));

        //
        mainData.connect(broadcastStream).process(new BroadcastProcessFunction<Tuple3<String, String, String>, Tuple2<Integer, String>, Tuple4<String, String, String, String>>() {

            BroadcastState<Integer, Tuple2<Integer, String>> broadcastState ;
           // 3 处理每个主流的数据
            // 获取状态中的  会员等级信息  关联上  输出
            @Override
            public void processElement(Tuple3<String, String, String> value, BroadcastProcessFunction<Tuple3<String, String, String>, Tuple2<Integer, String>, Tuple4<String, String, String, String>>.ReadOnlyContext ctx, Collector<Tuple4<String, String, String, String>> out) throws Exception {
                Tuple2<Integer, String> tp = broadcastState.get(Integer.parseInt(value.f2));
                if(tp!=null){
                    out.collect(Tuple4.of(value.f0 , value.f1,value.f2 , tp.f1));
                }else{
                    out.collect(Tuple4.of(value.f0 , value.f1,value.f2 , null));
                }
            }
           // 1 处理广播流
            // 2 获取广播流中的所有数据 将数据存储在状态中
            @Override
            public void processBroadcastElement(Tuple2<Integer, String> value, BroadcastProcessFunction<Tuple3<String, String, String>, Tuple2<Integer, String>, Tuple4<String, String, String, String>>.Context ctx, Collector<Tuple4<String, String, String, String>> out) throws Exception {
                broadcastState = ctx.getBroadcastState(mapStateDescriptor);
                broadcastState.put(value.f0 , value);
            }
        }).print() ;

        see.execute() ;



    }
}
```



**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> API 介绍  ， 核心要点</span>**

* <span style="color: rgb(31,35,41); background-color: inherit">将需要广播出去的流，调用broadcast方法进行广播转换，得到广播流BroadCastStream</span>

* <span style="color: rgb(31,35,41); background-color: inherit">然后在主流上调用connect算子，来连接广播流（以实现广播状态的共享处理）</span>

* <span style="color: rgb(31,35,41); background-color: inherit">在连接流上调用process算子，就会在同一个ProcessFunciton中提供两个方法分别对两个流进行处理，并在这个ProcessFunction内实现“广播状态”的共享</span>

## 6.3  Process函数

```java
package com.doit.day07;


import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.TimerService;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;

/**
 * @Date: 2023/7/1
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: process方法
 *    可以处理每个元素   非常灵活  可实现  map  flatMap  filter
 *    获取定时服务  操作定时器  获取时间
 *    操作测流
 *
 */
public class E01ProcessFunction {
    public static void main(String[] args) {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);

        DataStreamSource<Integer> ds = see.fromElements(1, 2, 3, 4, 5, 6, 7, 8);
        DataStreamSource<String> ds2 = see.fromElements("hello  jim  cat  jerry ", "hello java  sql  scala") ;
 
        
        //   map
        /**
         * 泛型1   输入
         * 泛型2  输出
         */
        ds.process(new ProcessFunction<Integer, Integer>() {
            // 接收每条数据  处理每条数据   返回结果
            // 每个元素调用一次
            @Override
            public void processElement(Integer value, ProcessFunction<Integer, Integer>.Context ctx, Collector<Integer> out) throws Exception {
                out.collect(value*10) ;
            }
        });
       //flatMap
        ds2.process(new ProcessFunction<String, Tuple2<String,Integer>>() {
            @Override
            public void processElement(String value, ProcessFunction<String, Tuple2<String, Integer>>.Context ctx, Collector<Tuple2<String, Integer>> out) throws Exception {
                String[] words = value.split("\\s+");
                for (String word : words) {
                    out.collect(Tuple2.of(word ,1));
                }
            }
        }) ;
      // filter
        ds.process(new ProcessFunction<Integer, Integer>() {
            @Override
            public void processElement(Integer value, ProcessFunction<Integer, Integer>.Context ctx, Collector<Integer> out) throws Exception {
                // 判断  返回指定的数据
                if(value>3 && value%2==0){
                    out.collect(value);
                }
            }
        }) ;

      //  操作时间服务 
        ds.process(new ProcessFunction<Integer, Integer>() {
            @Override
            public void processElement(Integer value, ProcessFunction<Integer, Integer>.Context ctx, Collector<Integer> out) throws Exception {
                // 获取时间服务   定时器  窗口的触发 , 定时逻辑
                TimerService timerService = ctx.timerService();
                 // 注册/删除  处理时间事件时间的定时器
                 //获取    水位线/处理时间
                // 判断  返回指定的数据
                if(value>3 && value%2==0){
                    out.collect(value);
                }
            }
        }) ;
    }
}
```

测流示例&#x20;

```java
package com.doit.day07;


import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.TimerService;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.flink.util.OutputTag;

/**
 * @Date: 2023/7/1
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: process方法
 *    可以处理每个元素   非常灵活  可实现  map  flatMap  filter
 *    获取定时服务  操作定时器  获取时间
 *    操作测流 :
 *        将指定的数据输出到测流中  后续的可以再次处理
 *        测流可以定义很多 ,  本质就是给不同规则的数据  分类管理
 */
public class E01ProcessFunction02 {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        // 定义流标签
        //1
        OutputTag<String> 奶哥流 = new OutputTag<>("奶哥流", TypeInformation.of(new TypeHint<String>() {
        }));
        //2
        OutputTag<String> 屌丝流 = new OutputTag<>("屌丝流", TypeInformation.of(new TypeHint<String>() {
        }));
        //3
        OutputTag<String> 病人流 = new OutputTag<>("病人流", TypeInformation.of(new TypeHint<String>() {
        }));

        DataStreamSource<String> ds = see.fromElements("lny-java", "hgy-mysql", "hgy-linux", "hgy-hadoop", "hgy-hive", "hgy-hbase", "jyj-doris", "jyj-redis", "jyj-kafka", "spark");

        SingleOutputStreamOperator<String> res = ds.process(new ProcessFunction<String, String>() {
            @Override
            public void processElement(String value, ProcessFunction<String, String>.Context ctx, Collector<String> out) throws Exception {
                if (value.startsWith("l")) {  // 奶哥流
                    // 将数据输出到测流中
                    ctx.output(奶哥流, value);
                } else if (value.startsWith("h")) {  //屌丝流
                    // 将数据输出到测流中
                    ctx.output(屌丝流, value);
                } else if (value.startsWith("j")) {  // 病人流
                    // 将数据输出到测流中
                    ctx.output(病人流, value);
                } else {
                    //主流
                    out.collect(value.toUpperCase());
                }
            }
        });
        res.print("主流:  ");
        // 从主流中获取数据
        res.getSideOutput(屌丝流).print("屌丝流") ;
        see.execute() ;
    }
}
```

# 7. 状态和容错

在实时流处理中, 不像离线数据处理那样, 如果任务出现故障, 只要重启任务,重新计算批数据就会获取正确的结果 ;实时流的数据是源源不断流入的, 源源不断的输出结果 , 如果在计算时出现故障, 恢复后从故障点接着计算 ;\[数据处理到哪? 中间的结果保存]

## 7.1  什么是状态

在分布式实时计算领域，其中最复杂的一个问题就是**任务的容错(任务由于故障而重启,处理的最终结果不能因为故障重启而发生错误)**，即任务在任何情况下出现错误时，都可以保证最终的结果是正确的。Flink为了保&#x8BC1;**<span style="color: rgb(216,57,49); background-color: inherit">计算任务可以容错</span>**，使用了&#x6709;**<span style="color: rgb(216,57,49); background-color: inherit">状态计算</span>**&#x8FD9;种机制，这也是Flink中最为重要的一个特征。所谓的有状态计算就是指程序在计算过程中，会产生一&#x4E9B;**<span style="color: rgb(216,57,49); background-color: inherit">中间结果</span>**，并提供给后续的计算使用。这些中间结果可以保存在内存中，也可以保存到外部的存储系统中。如果将中间结果仅保存到内存中，任务失败内存中的数据就可能会丢失，任务重启后需要从头开始读取数据，并重新计算，这种方式可能会造成大量的重复计算，浪费大量的计算资源，任务的延迟会变得很高；另外一种方式就是将程序在计算过程中产生的中间结果不但在内存中维护，同时定期将内存中的中间结果保存的一个高可用的存储系统中做检查点（checkpoint），如果程序在出现错误，任务重启并可以从最近一次成功的检查点恢复中间结果并重新加载到内存，然后继续进行计算，这样就可以保证计算结果是完全正确。这种方式虽然需要额外花费一些时间和资源做检查点，但综合比较后，后者更高效，延迟更低。

<span style="color: rgb(46,161,33); background-color: inherit">总结:  flink中为了保证程序的容错 ,设计了&quot;状态计算&quot;机制 !  就是将中间结果保存在状态中  ,故障恢复后可以从状态中恢复数据 ,继续计算保证数据的正确性 ! 为了提升计算性能状态存储在内存中 , 但是不安全 ;周期性的将内存中的数据持久化到磁盘/HDFS/外部数据库等文件系统中 !</span>

> <span style="color: rgb(31,35,41); background-color: inherit">在稍复杂的流式计算逻辑中，基本都需要记录和利用一些历史累积信息；</span>
>
> <span style="color: rgb(31,35,41); background-color: inherit">例如:  对整数流进行全局累计求和的逻辑：</span>
>
> 1. <span style="color: rgb(31,35,41); background-color: inherit">我们在算子中定义一个变量来记录累计到当前的总和；</span>
>
> 2. <span style="color: rgb(31,35,41); background-color: inherit">在一条新数据到达时，就将新数据累加到总和变量中；</span>
>
> 3) <span style="color: rgb(31,35,41); background-color: inherit">然后输出结果；</span>
>
> <span style="color: rgb(31,35,41); background-color: inherit">由上可知：</span>**<u><span style="color: rgb(31,35,41); background-color: inherit">状态就是用户在程序逻辑中用于记录信息的变量</span></u>**

<span style="color: rgb(31,35,41); background-color: inherit">（当然，依据不同的需求，状态数据可多可少，可简单可复杂）！</span>

Flink实时程序在计算过程中，为了保证任务出现异常可以容错，要将计算的中间结果在内存中维护并定期存储到相应的存储系统里，这些中间数据就叫做state（状态）。

State可以是多种类型的，默认是保存在JobManager的内存中，也可以保存到TaskManager本地文件系统或HDFS这样的分布式文件系统。



![](images/[多易教育]-Flink-1.16.1文档-image-34.png)

**<span style="color: inherit; background-color: rgba(98,210,86,1)">  flink托管状态</span>**

<span style="color: rgb(216,57,49); background-color: inherit">我们关注的只是将程序的中间数据(重要的数据) ,存储在状态中! 故障时组件自动的加载中间数据保证数据的计算结果的正确性 !</span>

<span style="color: rgb(31,35,41); background-color: inherit">flink提供了内置的状态数据管理机制（简称状态机制）；</span>

<span style="color: rgb(31,35,41); background-color: inherit">flink会进行状态数据管理：包括故障发生后的状态一致性维护、以及状态数据的高效存储和访问，</span>

<span style="color: rgb(31,35,41); background-color: inherit">用户借由flink所提供的的状态管理机制来托管自己的状态数据，则不用担心状态数据在程序失败及恢复时所引入的一系列问题；从而使得开发人员可以专注于应用程序的逻辑开发；</span>

## 7.2 状态种类

Flink中有两种基本的状态：<span style="color: inherit; background-color: rgba(183,237,177,0.8)">Keyed State</span> <span style="color: inherit; background-color: rgba(255,246,122,0.8)"> 和 Operator State。</span>例如Flink实时WordCount程序中，数据源源不断的被写入到Kafka消息中间件中，FlinkKafkaConsumer（Source）会从Kafka中消费数据，经过计算将结果输出。为了可以容错，就必须将该程序运行中的状态保存起来。那么这个WordCount程序中都记录哪些状态呢？我们可以很容易的想到，调用keyBy算子将数据按照单词分组后，再调用了sum算子进行聚合计算，在这个sum算子中就保存了各个单词累加的中间结果，一种key对应一个中间结果，这些中间结果，即各个单词对应的次数就是状态，其实这就是Keyed State。除此之外，为了任务出现错误重启后，不重复读取Kafka中的数据，还需要记录Kafka的偏移量。假设从Kafka读取数据的那个topic分区数量为4，运行WordCount程序时指定的并行度也是4，那么FlinkKafkaConsumer（Source）会有4个subtask，一个subtask消费一个Kafka分区，那么一个subtask会记录一个Kafka分区的偏移量，这些偏移量也是状态，其实这就是OperatorState。Flink会定期将这些状态保存到对应的状态存储系统中做检查点，如果任务出现异常重启，可以从状态存储系统中恢复上一次成功做检测点的各个单词的次数了和Kafka各个分区的偏移量。每个有状态的subtask都会从State Backend的快照中读取属于自己的状态数据并重新加载到内存，继续计算就可以了。

### 7.2.1 算子状态

<span style="color: rgb(31,35,41); background-color: inherit"> 算子状态:以SubTask为单位管理数据 , 互不影响</span>

* <span style="color: rgb(31,35,41); background-color: inherit">算子状态，是每个subtask自己持有一份独立的状态数据</span> <span style="color: rgb(216,57,49); background-color: inherit">（但如果在失败恢复后，算子并行度发生变化，则状态将在新的subtask之间均匀分配）</span> <span style="color: rgb(31,35,41); background-color: inherit">；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">算子函数实现</span>**<span style="color: rgb(31,35,41); background-color: inherit">CheckpointedFunction</span>**<span style="color: rgb(31,35,41); background-color: inherit">后，即可使用算子状态；在</span>**<span style="color: rgb(31,35,41); background-color: inherit">RichFunction</span>**<span style="color: rgb(31,35,41); background-color: inherit">中获取Context对象 , 也可以使用到算子状态!</span>

* <span style="color: rgb(216,57,49); background-color: inherit">算子状态，</span>**<span style="color: rgb(216,57,49); background-color: inherit">通常用于source算子中；</span>**<span style="color: rgb(31,35,41); background-color: inherit">其他场景下建议使用KeyedState（键控状态）；</span>

![](images/[多易教育]-Flink-1.16.1文档-image-29.png)



算子状态，在逻辑上，由算子task下所有subtask共享；

如何理解：正常运行时，subtask自己读写自己的状态数据；而一旦job重启且带状态算子发生了并行度的变化，则之前的状态数据将在新的一批subtask间均匀分配

### 7.2.2 键控状态&#x20;

* <span style="color: rgb(31,35,41); background-color: inherit">键控状态，只能应用于</span>**<span style="color: rgb(216,57,49); background-color: inherit">KeyedStream</span>**<span style="color: rgb(31,35,41); background-color: inherit">的算子中（keyby后的处理算子中）；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">算子为每一个</span>**<span style="color: rgb(31,35,41); background-color: inherit">key</span>**<span style="color: rgb(31,35,41); background-color: inherit">绑定一份独立的状态数据；</span>

![](images/[多易教育]-Flink-1.16.1文档-diagram-12.png)





### 7.2.3 <span style="color: rgb(31,35,41); background-color: inherit">状态数据结构介绍</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span>**<span style="color: rgb(31,35,41); background-color: inherit">算子状态提供的数据结构</span>

* **<span style="color: rgb(31,35,41); background-color: inherit">ListState</span>**

* <span style="color: rgb(31,35,41); background-color: inherit">UnionListState</span>

<span style="color: rgb(31,35,41); background-color: inherit">UnionListState 和普通 ListState的区别：</span>

1. <span style="color: rgb(31,35,41); background-color: inherit">UnionListState的快照存储数据，在系统重启后，list数据的重分配模式为： </span>**<span style="color: rgb(31,35,41); background-color: inherit">广播模式</span>**<span style="color: rgb(31,35,41); background-color: inherit">； 在每个subtask上都拥有一份完整的数据；</span>

2. <span style="color: rgb(31,35,41); background-color: inherit">ListState的快照存储数据，系统重启后，list数据的重分配模式为： round-robin 轮询平均分配；</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span>**<span style="color: rgb(31,35,41); background-color: inherit">键控状态提供的数据结构</span>

* <span style="color: rgb(31,35,41); background-color: inherit">ValueState </span>**<span style="color: rgb(31,35,41); background-color: inherit">单值 </span>**

* <span style="color: rgb(31,35,41); background-color: inherit">ListState  </span>**<span style="color: rgb(31,35,41); background-color: inherit">多值</span>**

* <span style="color: rgb(31,35,41); background-color: inherit">MapState</span>**<span style="color: rgb(31,35,41); background-color: inherit">  Map集合</span>**

* **<span style="color: rgb(216,57,49); background-color: inherit">ReducingState   聚合逻辑</span>**

* **<span style="color: rgb(216,57,49); background-color: inherit">AggregateState  聚合逻辑</span>**

## 7.3  状态后端&#x20;

> <span style="color: rgb(31,35,41); background-color: inherit">Flink是一个stateful（带状态）的数据处理系统；系统在处理数据的过程中，各算子所记录的状态会随着数据的处理而不断变化；</span>
>
> <span style="color: rgb(31,35,41); background-color: inherit">一旦系统崩溃，需要重启后能够恢复出崩溃前的状态才能进行数据的接续处理；因此，必须要一种机制能对系统内的各种状态进行持久化容错；[checkpoint是实现状态数据的持久化触发 , 状态后端负责数据的维护存储]</span>

用来保存State的数据的系统(内存, 文件系统 , 数据库)  就叫做StateBackEnd，默认是保存在JobManager的<span style="color: inherit; background-color: rgba(255,246,122,0.8)">内存</span>中，也可以保存的本地文件系统或HDFS这样的分布式文件系统、或RocksDB数据库中

**<span style="color: rgb(31,35,41); background-color: inherit">状态后端的基本概念</span>**

* <span style="color: rgb(31,35,41); background-color: rgba(186,206,253,0.7)">所谓状态后端，就是状态数据的存储管理实现，包含状态数据的本地读写、</span> <span style="color: rgb(31,35,41); background-color: rgb(251,191,188)">快照远</span> <span style="color: rgb(31,35,41); background-color: rgba(186,206,253,0.7)">端存储功能；</span>

* <span style="color: rgb(31,35,41); background-color: rgba(186,206,253,0.7)">状态后端是可插拔替换的，它对上层屏蔽了底层的差异，因为在更换状态后端时，用户的代码不需要做任何更改；</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 可用的状态后端类型（flink-1.13版以后）</span>**

![](images/[多易教育]-Flink-1.16.1文档-image-33.png)

* <span style="color: rgb(31,35,41); background-color: inherit">HashMapStateBackend   (内存)默认状态数据存储在此</span>

* <span style="color: rgb(31,35,41); background-color: inherit">EmbeddedRocksDBStateBackend  [数据库]</span>

~~<span style="color: rgb(31,35,41); background-color: inherit">老版本（flink-1.12版及以前） Fsstatebackend  MemoryStatebackend  RocksdbStateBackend</span>~~

*<span style="color: rgb(31,35,41); background-color: inherit">新版本中，</span>**<span style="color: rgb(31,35,41); background-color: inherit">Fsstatebackend和MemoryStatebackend整合成了HashMapStateBackend</span>***

*<span style="color: rgb(31,35,41); background-color: inherit">而且HashMapStateBackend和EmBeddedRocksDBStateBackend所生成的</span>**<span style="color: rgb(31,35,41); background-color: inherit">快照文件也统一了格式</span>**<span style="color: rgb(31,35,41); background-color: inherit">，因而在job重新部署或者版本升级时，可以任意替换statebackend</span>*

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> </span>**<span style="color: rgb(31,35,41); background-color: inherit">如需使用rocksdb-backend，需要引入依赖</span>

```java
<dependency>
    <groupId>org.apache.flink</groupId>
    <artifactId>flink-statebackend-rocksdb_2.12</artifactId>
    <version>${flink.version}</version>
</dependency>
```

***

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 状态后端的配置代码</span>**

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
env.setStateBackend(...);
# The backend that will be used to store operator state checkpoints
state.backend: hashmap
# Directory for storing checkpoints
state.checkpoints.dir: hdfs://doitedu:8020/flink/checkpoints
```

### 7.3.1 <span style="color: rgb(31,35,41); background-color: inherit">HashMapStateBackend状态后端</span>

<span style="color: rgb(31,35,41); background-color: inherit">HashMapStateBackend：</span>

* <span style="color: rgb(31,35,41); background-color: inherit">状态数据是以java对象形式存储在heap内存中；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">内存空间不够时，也会溢出一部分数据到本地磁盘文件；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">可以支撑大规模的状态数据；（只不过在状态数据规模超出内存空间时，读写效率就会明显降低）</span>

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 对于KeyedState来说：</span>**

<span style="color: rgb(31,35,41); background-color: inherit">HashMapStateBackend在内存中是使用</span>**<span style="color: rgb(31,35,41); background-color: inherit"> CopyOnWriteStateMap结构</span>**<span style="color: rgb(31,35,41); background-color: inherit">来存储用户的状态数据；</span>

<u><span style="color: rgb(31,35,41); background-color: inherit">注意，此数据结构类，</span></u>**<u><span style="color: rgb(31,35,41); background-color: inherit">名为Map，实非Map，它其实是一个单向链表的数据结构</span></u>**

**<span style="color: rgb(31,35,41); background-color: rgba(98,210,86,1)"> </span> <span style="color: rgb(31,35,41); background-color: inherit"> 对于OperatorState来说：</span>**

![](images/[多易教育]-Flink-1.16.1文档-image52.png)

<span style="color: rgb(31,35,41); background-color: inherit">可以清楚看出，它底层直接用一个</span>**<span style="color: rgb(31,35,41); background-color: inherit">Map集合</span>**<span style="color: rgb(31,35,41); background-color: inherit">来存储用户的状态数据：状态名称 --&gt; 状态List</span>

### 7.3.2 <span style="color: rgb(31,35,41); background-color: inherit">EmBeddedRocksDbStateBackend状态后端</span>

* <span style="color: rgb(31,35,41); background-color: inherit">状态数据是交给rocksdb来管理；(内置)</span>

* <span style="color: rgb(31,35,41); background-color: inherit">Rocksdb中的数据是以序列化的kv字节进行存储；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">Rockdb中的数据，有内存缓存的部分，也有磁盘文件的部分；</span>

* <span style="color: rgb(31,35,41); background-color: inherit">Rockdb的磁盘文件数据读写速度相对还是比较快的，所以在支持超大规模状态数据时，数据的读写效率不会有太大的降低</span>

**<span style="color: rgb(31,35,41); background-color: inherit">注意：上述2种状态后端，在生成checkpoint快照文件时，生成的文件格式是完全一致的；</span>**

**<span style="color: rgb(31,35,41); background-color: inherit">所以，用户的flink程序在更改状态后端后，重启时依然可以加载和恢复此前的快照文件数据；</span>**

## 7.4  状态编程

**<span style="color: rgb(216,57,49); background-color: inherit">状态和checkpoint配合使用</span>**

### 7.4.1 算子状态编程

![](images/[多易教育]-Flink-1.16.1文档-diagram-13.png)

<span style="color: rgb(31,35,41); background-color: inherit">要使用算子状态（operator state），需要让算子函数实现</span> <span style="color: rgb(46,161,33); background-color: inherit">CheckpointedFunction</span> <span style="color: rgb(31,35,41); background-color: inherit">接口；</span>

```java
package com.doit.day07;


import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.state.OperatorStateStore;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

/**
 * @Date: 2023/7/1
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 */
public class E08OperatorStateDemo {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);

        see.enableCheckpointing(1000) ;
        see.setRestartStrategy(RestartStrategies.fixedDelayRestart(3 , Time.seconds(1)));
        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8888);
        SingleOutputStreamOperator<Tuple2<String, Integer>> wordOne = data.flatMap(new FlatMapFunction<String, Tuple2<String, Integer>>() {
            @Override
            public void flatMap(String value, Collector<Tuple2<String, Integer>> out) throws Exception {
                String[] words = value.split("\\s+");
                for (String word : words) {
                    out.collect(Tuple2.of(word, 1));
                }
            }
        });

        // 使用算子状态
        wordOne.map(new MapFunctionWithState()).print() ;
        see.execute() ;




    }
   static  class  MapFunctionWithState  extends RichMapFunction<Tuple2<String, Integer> ,Tuple2<String, Integer>> implements CheckpointedFunction{

       ListState<String> listState ;
       @Override
       public Tuple2<String, Integer> map(Tuple2<String, Integer> value) throws Exception {
           if(value.f0.equals("h")){
               throw new RuntimeException("" );
           } 

           // 将当前SubTask处理的数据存储在算子状态中
           RuntimeContext runtimeContext = getRuntimeContext();
           int indexOfThisSubtask = runtimeContext.getIndexOfThisSubtask();
           listState.add(value.f0 +"----subtaskId: "+indexOfThisSubtask);
           return value;
       }

       @Override
       public void snapshotState(FunctionSnapshotContext context) throws Exception {

       }
       /**
        * subtask初次启动  /   故障重启时调用
        * @param context the context for initializing the operator
        * @throws Exception
        */
       @Override
       public void initializeState(FunctionInitializationContext context) throws Exception {
           //  创建  或者是加载
           OperatorStateStore operatorStateStore = context.getOperatorStateStore();
           ListStateDescriptor<String> listStateDescriptor = new ListStateDescriptor<>("ops", String.class);
            listState = operatorStateStore.getListState(listStateDescriptor);
       }
   }

}
```

```java
package com.doit.high;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.state.*;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.runtime.state.FunctionInitializationContext;
import org.apache.flink.runtime.state.FunctionSnapshotContext;
import org.apache.flink.streaming.api.checkpoint.CheckpointedFunction;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @Date: 2023/6/29
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: 算子状态   一般是在source的时候使用
 */
public class OperaterState {
    public static void main(String[] args) throws Exception {

        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        see.enableCheckpointing(5000);
        see.getCheckpointConfig().setCheckpointStorage("file:///d:/data/chk01");

        ValueStateDescriptor<String> words = new ValueStateDescriptor<>("words", String.class);
        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
        SingleOutputStreamOperator<String> res = data.map(new StateMapFunction());
        res.print();
        see.execute();
    }
}

class StateMapFunction extends RichMapFunction<String, String> implements CheckpointedFunction {
    ArrayList<String> list = new ArrayList<String>();
    ListStateDescriptor<String> listStateDescriptor = new ListStateDescriptor<String>("ls", String.class);
    int x = 0;
    ListState<String> listState;

    @Override
    public String map(String value) throws Exception {
        x++;
        if (x % 5 == 0) {
            throw new RuntimeException("哇呜...");
        }
        list.add(value);
        StringBuffer sb = new StringBuffer();
        for (String s : list) {
            sb.append(s);
        }
        return sb.toString();
    }

    @Override
    public void snapshotState(FunctionSnapshotContext context) throws Exception {

    }

    @Override
    public void initializeState(FunctionInitializationContext context) throws Exception {
        OperatorStateStore operatorStateStore = context.getOperatorStateStore();
        listState = operatorStateStore.getListState(listStateDescriptor);
        System.out.println("加载或者是创建算子状态......");
        RuntimeContext runtimeContext = getRuntimeContext();
        int indexOfThisSubtask = runtimeContext.getIndexOfThisSubtask();

        System.out.println("-----------------------------------------" + indexOfThisSubtask);
        Iterable<String> strings = listState.get();
        //  Iterator<String> iterator = strings.iterator();
        for (String string : strings) {
            System.out.println(string);
        }
        System.out.println("-----------------------------------------" + indexOfThisSubtask);
    }
}
```

### 7.4.2 键控状态编程

![](images/[多易教育]-Flink-1.16.1文档-diagram-14.png)



#### 7.4.2.1  <span style="color: rgb(31,35,41); background-color: inherit">ValueState</span>

![](images/[多易教育]-Flink-1.16.1文档-image-30.png)



![](images/[多易教育]-Flink-1.16.1文档-diagram-15.png)



```java
package com.doit.day08;


import org.apache.calcite.avatica.org.apache.http.client.RedirectStrategy;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.common.time.Time;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;

/**
 * @Date: 2023/7/3
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: 单词统计
 * 使用状态  实现容错的wordcount
 */
public class E01StateDemo01 {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
       see.enableCheckpointing(3000) ;
        see.getCheckpointConfig().setCheckpointStorage("file:///D:/data/doit38-chks");

        // 参数一  最大重启次数
        // 参数二  两次重启之间的时间间隔
        see.setRestartStrategy(RestartStrategies.fixedDelayRestart(3, 2000));
        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);

        SingleOutputStreamOperator<String> words = data.flatMap(new FlatMapFunction<String, String>() {
            @Override
            public void flatMap(String value, Collector<String> out) throws Exception {
                String[] words = value.split("\\s+");
                for (String word : words) {
                    out.collect(word);
                }
            }
        });

        KeyedStream<String, String> keyed = words.keyBy(e -> e);


        SingleOutputStreamOperator<Tuple2<String, Integer>> res = keyed.map(new RichMapFunction<String, Tuple2<String, Integer>>() {
           
            ValueState<Integer> state;
            @Override
            public void open(Configuration parameters) throws Exception {
                System.out.println("初始化... ..");
                RuntimeContext context = getRuntimeContext();
                ValueStateDescriptor<Integer> cng = new ValueStateDescriptor<>("cng", Integer.class);
                state = context.getState(cng);
            }

            @Override
            public Tuple2<String, Integer> map(String value) throws Exception {

                if ("h".equals(value)) {
                    throw new RuntimeException();
                }
                Integer value1 = state.value();
                // 注意
                if (value1 != null) {
                    value1 += 1;
                    state.update(value1);
                } else {
                    state.update(1);
                }
                return Tuple2.of(value, state.value());
            }
        });


        res.print() ;
        see.execute();
    }


}
```

#### 7.4.2.2 ListState

![](images/[多易教育]-Flink-1.16.1文档-diagram-16.png)

```java
package com.doit.day08;


import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.util.Collector;

/**
 * @Date: 2023/7/3
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description: 单词统计
 * 使用状态  实现容错的wordcount
 */
public class E01StateDemo02LIstState {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
       see.enableCheckpointing(3000) ;
        see.getCheckpointConfig().setCheckpointStorage("file:///D:/data/doit38-chks");

        // 参数一  最大重启次数
        // 参数二  两次重启之间的时间间隔
        see.setRestartStrategy(RestartStrategies.fixedDelayRestart(3, 2000));
        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);

        SingleOutputStreamOperator<String> words = data.flatMap(new FlatMapFunction<String, String>() {
            @Override
            public void flatMap(String value, Collector<String> out) throws Exception {
                String[] words = value.split("\\s+");
                for (String word : words) {
                    out.collect(word);
                }
            }
        });

        KeyedStream<String, String> keyed = words.keyBy(e -> e);

        SingleOutputStreamOperator<Tuple2<String, Integer>> res = keyed.map(new RichMapFunction<String, Tuple2<String, Integer>>() {
            ListState<String> listState ;
            // 使用状态编程
            @Override
            public void open(Configuration parameters) throws Exception {
                RuntimeContext runtimeContext = getRuntimeContext();
                ListStateDescriptor<String> words1 = new ListStateDescriptor<>("words", String.class);
                listState = runtimeContext.getListState(words1);

            }

            @Override
            public Tuple2<String, Integer> map(String value) throws Exception {
                // 将数据添加到状态中
                listState.add(value);
                // 获取所有的数据
                int  cnt = 0 ;
                for (String s : listState.get()) {
                    cnt +=1 ;
                }
                return Tuple2.of(value , cnt) ;
            }

        });


        res.print() ;
        see.execute();
    }


}
```

#### 7.4.2.3 <span style="color: rgb(31,35,41); background-color: inherit">MapState</span>

![](images/[多易教育]-Flink-1.16.1文档-diagram-17.png)

每个城市  每种商品类别的订单总金额 &#x20;

```prolog
oid01,C1,100,BJ
oid02,C1,100,SH
oid03,C1,100,BJ
oid04,C2,100,BJ
oid05,C2,100,SH
oid06,C2,100,SZ
oid07,C2,100,BJ
oid08,C1,100,BJ

BJ , C1 
BJ,  C2
SH,  C1
SH , C2
SZ , C2
```

```java
package com.doit.day08;


import com.doit.beans.Orders;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * @Date: 2023/7/3
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 */
public class E02MapStateDemo {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        see.enableCheckpointing(3000) ;
        see.getCheckpointConfig().setCheckpointStorage("file:///D:/data/doit38-chks");

        // 参数一  最大重启次数
        // 参数二  两次重启之间的时间间隔
        see.setRestartStrategy(RestartStrategies.fixedDelayRestart(3, 2000));
        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
        SingleOutputStreamOperator<Orders> orders = data.map(new MapFunction<String, Orders>() {
            @Override
            public Orders map(String value) throws Exception {
                String[] arr = value.split(",");
                Orders orders = new Orders(arr[0], arr[1], arr[2], Double.parseDouble(arr[3]));
                return orders;
            }
        });
        // 按照城市分组
        KeyedStream<Orders, String> ordersStringKeyedStream = orders.keyBy(new KeySelector<Orders, String>() {
            @Override
            public String getKey(Orders value) throws Exception {
                return value.getCity();
            }
        });

// map内部的计算逻辑都是按照key划分的
        ordersStringKeyedStream.map(new RichMapFunction<Orders, Tuple3<String,String,Double>>() {
            MapState<String, Double> mapStat ;
            @Override
            public void open(Configuration parameters) throws Exception {
                RuntimeContext runtimeContext = getRuntimeContext();
                //类别  总金额
                MapStateDescriptor<String, Double> category_money = new MapStateDescriptor<>("category_money", String.class, Double.class);
                mapStat = runtimeContext.getMapState(category_money);
            }

            @Override
            public Tuple3<String, String, Double> map(Orders value) throws Exception {
                if (value.getCity().equals("DG")){
                    throw new RuntimeException() ;
                }
                String category = value.getCategory();   // C1       -->  [C1 , 200]
                double money = value.getMoney();    // 100
                if(mapStat.isEmpty()){
                    mapStat.put(category , money);
                }else{
                    Double aDouble = mapStat.get(category);
                    if(aDouble != null){
                        mapStat.put(category , aDouble + money);
                    }else{
                        mapStat.put(category , money);
                    }
                }
                Double nowMoney = mapStat.get(category);
                return Tuple3.of(value.getCity() , category ,nowMoney);
            }
        }) .print();

        see.execute() ;
    }

}
```

#### 7.4.2.4 ReducingState

![](images/[多易教育]-Flink-1.16.1文档-diagram-18.png)

```java
package com.doit.day08;

import com.doit.beans.Orders;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.common.functions.RichMapFunction;
import org.apache.flink.api.common.functions.RuntimeContext;
import org.apache.flink.api.common.restartstrategy.RestartStrategies;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.common.state.ReducingState;
import org.apache.flink.api.common.state.ReducingStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.functions.KeySelector;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStreamSource;
import org.apache.flink.streaming.api.datastream.KeyedStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;

/**
 * @Date: 2023/7/3
 * @Author: Hang.Nian.YY
 * @WX: 17710299606
 * @Tips: 学大数据 ,到多易教育
 * @DOC: https://blog.csdn.net/qq_37933018?spm=1000.2115.3001.5343
 * @Description:
 */
public class E03AggStateDemo {
    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        conf.setInteger("rest.port", 8888);
        StreamExecutionEnvironment see = StreamExecutionEnvironment.createLocalEnvironmentWithWebUI(conf);
        see.setParallelism(1);
        see.enableCheckpointing(3000);
        see.getCheckpointConfig().setCheckpointStorage("file:///D:/data/doit38-chks");

        // 参数一  最大重启次数
        // 参数二  两次重启之间的时间间隔
        see.setRestartStrategy(RestartStrategies.fixedDelayRestart(3, 2000));
        DataStreamSource<String> data = see.socketTextStream("doitedu01", 8899);
        SingleOutputStreamOperator<Orders> orders = data.map(new MapFunction<String, Orders>() {
            @Override
            public Orders map(String value) throws Exception {
                String[] arr = value.split(",");
                Orders orders = new Orders(arr[0], arr[1], arr[2], Double.parseDouble(arr[3]));
                return orders;
            }
        });
        // 按照城市分组
        KeyedStream<Orders, String> ordersStringKeyedStream = orders.keyBy(new KeySelector<Orders, String>() {
            @Override
            public String getKey(Orders value) throws Exception {
                return value.getCity();
            }
        });

        // 城市  订单总金额
        ordersStringKeyedStream.map(new RichMapFunction<Orders, Tuple2<String, Double>>() {
            ReducingState<Double> reducingState ;
            @Override
            public void open(Configuration parameters) throws Exception {
                RuntimeContext context = getRuntimeContext();
                ReducingStateDescriptor<Double> reducingStateDescriptor = new ReducingStateDescriptor<>(
                        "reduce"
                        , new ReduceFunction<Double>() {
                    @Override
                    public Double reduce(Double value1, Double value2) throws Exception {
                        value1 += value2;
                        return value1;
                    }
                }
                        , TypeInformation.of(new TypeHint<Double>() {
                }));

            reducingState = context.getReducingState(reducingStateDescriptor);

            }

            @Override
            public Tuple2<String, Double> map(Orders value) throws Exception {
               reducingState.add(value.getMoney());
                Double allMoney = reducingState.get();
                return Tuple2.of(value.getCity(),allMoney);
            }


        }).print();


        see.execute();
    }
}
```

#### 7.4.2.5 AggregateState



<span style="color: rgb(31,35,41); background-color: inherit">要使用键控状态（Keyed State）,需要在实现RichFunction的函数中；必须在keyBy后使用状态</span>

算子中使用状态数据的流程

## 7.5  状态TTL

状态中的数据有过期时间 ,会定期的清理释放出内存

状态的过期时间设置 , 记录中间结果数据,&#x20;

```java
StateTtlConfig ttlConfig = StateTtlConfig.newBuilder(Time.milliseconds(1000)) 
    // 配置数据的存活时长为4s（覆盖builder构造传入的1s）
    //.setTtl(Time.milliseconds(4000))  
    // 当插入和更新的时候，导致该条数据的ttl计时重置
    //.updateTtlOnCreateAndWrite()  
    // 读、写，都导致该条数据的ttl计时重置
    .updateTtlOnReadAndWrite()  
    // 不允许返回已过期但尚未被清理的数据
    .setStateVisibility(StateTtlConfig.StateVisibility.NeverReturnExpired)  
    // 允许返回已过期但尚未被清理的数据
   // .setStateVisibility(StateTtlConfig.StateVisibility.ReturnExpiredIfNotCleanedUp) 
    // ttl计时的时间语义:设置为处理时间
   // .setTtlTimeCharacteristic(StateTtlConfig.TtlTimeCharacteristic.ProcessingTime) 
    // ttl计时的时间语义:设置为处理时间 默认 
   .useProcessingTime()  
    // 增量清理（每当一条状态数据被访问，则会驱动过期检查及清除）
    .cleanupIncrementally(1000,true)  
    // 全量快照清理策略（在checkpoint的时候，保存到快照文件中的只包含未过期的状态数据，但是它并不会清理算子本地的状态数据）
   // .cleanupFullSnapshot()  
    // 在rockdb的compact机制中添加过期数据过滤器，以在compact过程中清理掉过期状态数据
    .cleanupInRocksdbCompactFilter(1000) 
    // 禁用默认后台清理策略
    //.disableCleanupInBackground()
    
    

    
    xxStateDescriptor.enableTimeToLive(ttlConfig);
```

## 7.6  重启策略



### 7.6.1  为什么要有重启策略

当一个实时计算任务运行发生故障时，如果程序抛出异常不做任何处，那么程序就停止了，这样就不能实现实时计算了；如果忽略错误，让其继续运行，那么会导致中间计算的数据丢失或数据的准确性无法保证。为了保证最终计算的结果要准确无误，必须让程序可以重启，并且可以恢复出现错误之前对应的数据。\[自动重启 , 恢复状态数据]

当一个Flink任务运行时发生故障时，Flink可以根据配置的重启策略重启该job对应的全部Task。Task重启后，可以从State Backend中恢复上一次成功checkpoint的状态，然后继续运行，所以重启策略和故障恢复策略对于Flink的容错有着非常重要的作用(重启策略必须与checkpointing结合使用)。

### 7.6.2  重启策略种类

重启策略是指在job出现异常时决定是否可以重启、重启的次数以及重启的延时时间。将一个job提交到Flink集群中运行时，如果没有在job中配置重启策略，则会遵循集群启动时加载的默认重启策略。如果提交Job时设置了重启策略，该策略将覆盖掉集群的默认策略。

集群默认的重启策略可以通过**flink-conf.yaml**配置文件进行配置。配置参数**restart-strategy**定义了采取何种策略。如果job中没有开启 checkpoint功能，就采用“不重启”的策略。如果开启了checkpoint功能且没有配置重启策略，那么就采用固定延时重启策略， 此时最大尝试重启次数为Integer.MAX\_VALUE，相当于无限重启。

除了配置默认的重启策略以外，还可以为每个job单独配置重启策略。这个重启策略通过在程序中调用 StreamExecutionEnvironment的**setRestartStrategy**方法来设置（对于批处理的ExecutionEnvironment也同样适用）。

#### 7.6.2.1  固定延时重启策略

固定延时重启策略按照指定的次数重启job。如果重启的次数超过了指定的最大<span style="color: inherit; background-color: rgba(183,237,177,0.8)">次数</span>，job将最终失败。 并且还可以在连续的两次重启尝试之间配置一段固定延迟时间(间隔)。

* **在代码中配置单个job的固定延时重启策略：**

* *fixedDelayRestart*(3, Time.*seconds*(10)));

&#x20;     参数一  最大重启次数&#x20;

&#x20;     参数二  故障检查周期  \[10s内最大允许重启3次]

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//设置重启策略：最大重启次数为3，在指定时间内重启次数不能超过设置的值  停止JOB
env.setRestartStrategy(RestartStrategies.fixedDelayRestart(3, Time.seconds(10)));
```

* **在flink-conf.yaml中配置集群默认的固定延时重启策略：**

```yaml
# 设置重启策略为固定延时重启策略（注意冒号后面有一个空格符）
restart-strategy: fixed-delay
# 最大重启次数为3
restart-strategy.fixed-delay.attemp    ts: 3
# 连续的两次重启之间延迟时间为10秒。单元也可以是分钟，例如1 min（注意时间单位前有一个空格符）
restart-strategy.fixed-delay.delay: 10 s
```

#### 7.6.2.2  故障率重启策略

故障率重启策略在故障发生之后重启job，每个时间间隔发生故障的次数超过指定的最大次数，job将最终失败。并且还可以在连续的两次重启尝试之间配置一段固定延迟时间。

在flink-conf.yaml中配置集群默认的故障率重启策略：

* 在代码中配置单个job的故障率重启策略：

failureRateRestart(3, Time.seconds(10),Time.seconds(2))&#x20;

&#x20;       参数一  最大重启次数&#x20;

&#x20;       参数二  故障检查周期  \[10s内最大允许重启3次] &#x20;

&#x20;       参数三  任务再次重启的**惩罚时长**

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//设置重启策略：30秒内重启超过3次，程序停止, 每一次延迟2秒
env.setRestartStrategy(RestartStrategies.failureRateRestart(3, Time.seconds(30),Time.seconds(2)));
```

* 在flink-conf.yaml中配置集群默认的固定延时重启策略：

```yaml
# 设置重启策略为故障率重启策略
restart-strategy: failure-rate
restart-strategy.failure-rate.max-failures-per-interval: 3
restart-strategy.failure-rate.failure-rate-interval: 5 min
restart-strategy.failure-rate.delay: 10 s
```

#### 7.6.2.3  **Exponential Delay Restart Strategy(指数延迟重启策略)**

本策略：故障越频繁，两次重启间的惩罚间隔就越长

initialBackoff 重启间隔惩罚时长的初始值 ： 1s

maxBackoff 重启间隔最大惩罚时长 : 60s

backoffMultiplier 重启间隔时长的惩罚倍数: 2（ 每多故障一次，重启延迟惩罚就在 上一次的惩罚时长上 \* 倍数）

resetBackoffThreshold 重置惩罚时长的平稳运行时长阈值（平稳运行达到这个阈值后，如果再故障，则故障重启延迟时间重置为了初始值：1s）

jitterFactor 取一个随机数，来加在重启时间点上，已让每次重启的时间点呈现一定随机性

&#x20;  job1: 9.51   9.53+2\*0.1    9.57   ......

&#x20;  job2: 9.51   9.53+2\*0.15   9.57   ......

&#x20;  job3: 9.51   9.53+2\*0.8    9.57   ......

#### 7.6.2.4 无限重启策略

<span style="color: inherit; background-color: rgb(251,191,188)">flink开启checkpoint后 , 出现故障的重启策略  一直重启</span>

#### 7.6.2.5 不重启策略

不尝试重启，job直接失败。

* 在代码中配置单个job的故障率重启策略：

```java
StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
//设置重启策略：不重启
env.setRestartStrategy(RestartStrategies.noRestart());
```

* 在flink-conf.yaml中配置集群默认的故障率重启策略：

```java
# 设置重启策略为不重启
restart-strategy: none
```

![](images/[多易教育]-Flink-1.16.1文档-diagram-19.png)

# 8. checkpoint机制

在使用flink编程时, 为了容错使用状态编程 ! 如果程序真的重启了 ! 在状态中的数据会不会丢失???&#x20;

将状态数据持久化到指定的位置(本地/HDFS) ,任务重启 , 就有能力恢复状态数据 !

<span style="color: inherit; background-color: rgba(183,237,177,0.8)">将最新的状态数据 持久化到HDFS  , 多久持久化一次 ??   1分钟 , checkpoint  , 1分钟 </span>

![](images/[多易教育]-Flink-1.16.1文档-diagram-20.png)

<span style="color: inherit; background-color: rgb(251,191,188)">问题1 : 在两次checkpoint之间流入的数据  如果第二次checkpoint没执行 , 丢失数据! </span>

![](images/[多易教育]-Flink-1.16.1文档-image-31.png)



![](images/[多易教育]-Flink-1.16.1文档-diagram-21.png)

![](images/[多易教育]-Flink-1.16.1文档-diagram-22.png)

## 8.1  checkpoint机制简介

Flink实时计算为了容错，可以将中间数据定期保存到起来，这种定期触发保存中间结果的机制叫CheckPointing。CheckPointing是周期执行的。具体的过程是JobManager定期的向TaskManager中的SubTask发送RPC消息，SubTask将其计算的State由<span style="color: rgb(216,57,49); background-color: inherit">StateBackEnd</span>保存管理，并且向JobManager响应Checkpoint是否成功。如果程序出现异常或重启，TaskManager中的SubTask可以从上一次成功的CheckPointing的State恢复 。

![](images/[多易教育]-Flink-1.16.1文档-diagram-23.png)





![](images/[多易教育]-Flink-1.16.1文档-output.png)

主要的步骤：

1.jobManager中的<span style="color: inherit; background-color: rgb(251,191,188)">CheckpointCoordinator</span>定期会向对应的TaskManager发送RPC请求，即通知TaskManager中的subtask要保存状态了，这个过程叫做TriggerCheckpoint  !(保存状态)

2.TaskManager中的subtask将接收到JobManager发送过来的情况后，会将当前自己的状态由StateBackend持久化到指定的目录，这个过程叫snapshot state !

3.TaskManager中的subtask将状态成功持久化后，会向JobManager发送RPC请求，通知JobManger，当前这个subtask状态保存成功了 !

4.JobManager接收到当前job所有subtask成功完成快照的应答后，这次Checkpoint就成功了，并且会向实现了CheckpointListener接口的subtask发送notifyCheckpointCompleted消息，从而让每一个subtask知道整个checkpoint完成了，并且可以在该方法中完成一些逻辑 !

## 8.2 **分布式Checkpoint的难题**

由于flink是一个分布式的系统，数据在流经系统中各个算子时，是有先后顺序的；换个角度来说就是：整个系统对一条数据的处理过程，并不是一个原子性的过程；

这样一来，对系统中各算子的状态进行持久化（快照），就成了一件棘手的事情；

来看如下数据处理场景：

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">算子1： 从kafka中读取数据，并在状态中记录消费位移</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">算子2： 对流入的整数进行累加，并输出累加结果</span>

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">算子3： 对流入是整数进行累加，并输出累加结果</span>

&#x20;

<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 先注意观察正常情况下，整个系统的各算子状态变化及最终输出结果</span>

![](images/[多易教育]-Flink-1.16.1文档-NwURbSsFioEnAgxnA5scXlNynZ7.png)

&#x20;

<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 出于容错考虑，需要在某个时机对整个系统各个算子的状态数据进行快照持久化，如下</span>

![](images/[多易教育]-Flink-1.16.1文档-Ja3kb6CuDosKq7x8zCZciK5CnFe.png)

<span style="color: inherit; background-color: rgb(247,105,100)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 系统重启后加载快照数据，恢复各算子崩溃前的状态，但是会发现，处理结果相对正常时完全错误</span>

![](images/[多易教育]-Flink-1.16.1文档-XlMlb2wbnoJXyyx0toCcVgxsnOB.png)

&#x20;

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">从最终结果来看，整个计算</span>

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">丢失了数据2的结果</span>

* <span style="color: inherit; background-color: rgba(222,224,227,0.8)">数据3则因为内部状态的紊乱而产生了错误的结果</span>

## 8.3 **Checkpoint的核心要点**



checkpoint是flink内部对状态数据的快照机制；

flink的checkpoint机制是源于 Chandy-Lamport 算法（分布式快照算法）；

<u>底层逻辑：通过周期性插入序号  单调递增的barrier，把无界数据流划分成逻辑上的数据批（段），并通过段落标记（barrier）来为这段数据的处理，加持&quot;事务（transaction）&quot; 特性：</u>

* <u>每一段数据流要么被完整成功处理；sink后</u>

* <u>要么回滚到数据原先的的位置； source前  回到上次checkpoint的位置</u>

&#x20;

![](images/[多易教育]-Flink-1.16.1文档-P32ebzziCok68nxWJFycc0WInCf.png)

## 8.4 **Checkpoint的整体流程**

1. JobMaster 即 CheckpointCoordinator 会定期向每个 source task发送命令 start checkpoint（trigger checkpoint）；&#x20;

2. 当 source task 收到 trigger checkpoint 指令后，产生 barrier 并通过广播的方式发送到下游。source task 及所有其他task，收到barrier-n，会执行本地 checkpoint-n，当 checkpoint-n 完成后，向 JobMaster 发送 ack；&#x20;

3. 当流图的所有节点都完成 checkpoint-n，JobMaster会收到所有节点的 ack，那么就表示完成 checkpoint-n，随即就会向所有task广播一条checkpoint-n全部完成的通知消息；

![](images/[多易教育]-Flink-1.16.1文档-SQ7SbooaWoXmCfxxUOMcC91uncc.png)

&#x20;

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">说明：checkpoint 机制的调用流程实质是 2PC。JobMaster 是协调者，所有operator task 是执行者。start checkpoint 是 pre-commit 的开始信号，而每个 operator task 的 checkpoint 是 pre-commit 过程，ack 是执行者 operator task 反馈给协调者 JobMaster ，最后 callback 是 commit。</span>



&#x20;

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 1）Barrier 会在数据流源头被注入并行数据流中</span>**

Barrier-n 所在的位置就是恢复时数据重新处理的起始位置。 例如，在 Kafka 中，这个位置就是最后一个记录在分区内的消费位移 ( offset) ，作业恢复时，会根据这个位置从这个偏移量向kafka 请求数据，这个偏移量就是 State 中保存的内容之一。

&#x20;

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 2）Barrier 接着向下游传递</span>**

当一个非数据源算子从所有的输入流中收到Barrier-n时，该算子就会对自己的 State 保存快照，并向自己的下游<span style="color: inherit; background-color: rgb(251,191,188)"> 广播</span> 发送Barrier-n ;

&#x20;

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> </span> <span style="color: rgb(216,57,49); background-color: rgba(222,224,227,0.8)">3）一旦 Sink 算子接收到 </span> <span style="color: rgb(216,57,49); background-color: rgba(255,246,122,0.8)">Barrier</span> <span style="color: rgb(216,57,49); background-color: rgba(222,224,227,0.8)"> ，有两种情况：</span>**

**<span style="color: rgb(216,57,49); background-color: inherit">（1）如果是引擎内严格一次处理保证，当 Sink 算子已经收到了所有上游的Barrie-n 时， Sink 算子对自己的 State 进行快照，然后通知检查点协调器( CheckpointCoordinator) 。当所有的算子都向检查点协调器汇报成功之后，检查点协调器向所有的算子确认本次快照完成。</span>**

**<span style="color: rgb(216,57,49); background-color: inherit">（2）</span> <span style="color: rgb(216,57,49); background-color: rgba(255,246,122,0.8)">如果是端到端严格一次处理保证</span> <span style="color: rgb(216,57,49); background-color: inherit">，当 Sink 算子已经收到了所有上游的Barrie-n 时， Sink算子对自己的 State 进行快照，并预提交事务（两阶段提交的第一阶段），再通知检查点协调器( CheckpointCoordinator) ，检查点协调器向所有的算子确认本次快照完成，Sink 算子提交事务（两阶段提交的第二阶段），本次事务完成；</span>**

![](images/[多易教育]-Flink-1.16.1文档-image-32.png)

&#x20;

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> snapshotting operator算子</span>**

![](images/[多易教育]-Flink-1.16.1文档-CHmkbOkPFolOlUxgkokccEFdnjd.png)

* For each parallel stream data source, the offset/position in the stream when the snapshot was started

* For each operator, a pointer to the state that was stored as part of the snapshot

## 8.5 **对齐与非对齐checkpoint**



**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 对齐的checkpoint</span>**

![](images/[多易教育]-Flink-1.16.1文档-A61bbzdGnokYHGxNhiLcs1l4njd.png)

* 算子收到数字流 Barrier,字母流对应barrier 尚未到达 ；

* 算子收到数字流 Barrier,会继续从数字流中接收数据，但这些流只能被搁置，记录不能被处理，而是放入缓存中，等待字母流 Barrier 到达。在字母流到达前， 1，2，3 数据已经被缓存。&#x20;

* 字母流到达，算子开始对齐 State 进行异步快照，并将 Barrier 向下游广播，并不等待快照完毕。&#x20;

* 算子做异步快照，首先处理缓存中积压数据，然后再从输入通道中获取数据。&#x20;

Barrier 对齐不仅保证了状态的准确性，解决的分布式checkpoint中数据一致性问题

问题  :&#x20;

1   占用系统资源 ,缓存先到大barrier流的数据

2   增加背压的可能性(数据阻塞)

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 非对齐的checkpoint</span>**

但是，Barrier 对齐是阻塞式的，在作业出现反压时可能会成为不定时炸弹。我们知道，检查点Barrier是从Source端产生并源源不断地向下游流动的。如果作业出现反压（哪怕整个DAG中的一条链路反压），数据流动的速度减慢，Barrier到达下游算子的延迟就会变大，进而影响到检查点完成的延时（变大甚至超时失败）。如果反压长久不能得到解决，快照数据与实际数据之间的差距就越来越明显，一旦作业failover，势必丢失较多的处理进度。另一方面，作业恢复后需要重新处理的数据又会积压，加重反压，造成恶性循环。

为了规避风险，Flink 1.11版本中通过[FLIP-76](https://links.jianshu.com/go?to=https%3A%2F%2Fcwiki.apache.org%2Fconfluence%2Fdisplay%2FFLINK%2FFLIP-76%253A%2BUnaligned%2BCheckpoints)引入了非对齐检查点（unaligned checkpoint）的feature，下面简要介绍之。



![](images/[多易教育]-Flink-1.16.1文档-UWufbe3MRo5BhnxL7sHccCwEnxf.png)

barrier 不对齐：只要有上游数据的barrier到达后就会做checkpoint  ,

同时接收barrier之后的数据继续处理数据 ,只是为了保证checkpoint数据的正确性, 在checkpoint时不仅仅要持久化状态数据 , 还会持久化输入和输出缓存的数据 !

既然不同检查点的数据都混在一起了，非对齐检查点还能保证exactly once语义吗？答案是肯定的。当任务从非对齐检查点恢复时，除了对齐检查点也会涉及到的Source端重放和算子的计算状态恢复之外，未对齐的流数据也会被恢复到各个链路，三者合并起来就是能够保证exactly once的完整现场了。

## 8.6 **checkpoint相关参数和API**

```java

System.setProperty("HADOOP_USER_NAME" , "root") ;
env.enableCheckpointing(3000); // 传入的参数是checkpoint的间隔时间
// 指定checkpoint数据的存储位置
env.getCheckpointConfig().setCheckpointStorage(new Path("hdfs://doit01:8020/flink-jobs-checkpoints/")); 
 
// 容许checkpoint失败的最大次数
env.getCheckpointConfig().setTolerableCheckpointFailureNumber(10); 
 
// checkpoint保证数据的一致性的精度  精确处理一次  至少处理一次
env.getCheckpointConfig().setCheckpointingMode(CheckpointingMode.EXACTLY_ONCE);  //AT_LEAST_ONCE
 
// job取消时是否保留checkpoint数据  cancel(指令)  kill(强制杀死) 

env.getCheckpointConfig().setExternalizedCheckpointCleanup(CheckpointConfig.ExternalizedCheckpointCleanup.     ION); 
 
// 设置checkpoint对齐的超时时间 
env.getCheckpointConfig().setAlignedCheckpointTimeout(Duration.ofMillis(2000));  
 
// 两次checkpoint的最小间隔时间，为了防止两次checkpoint的间隔时间太短
env.getCheckpointConfig().setCheckpointInterval(2000); 
 
// 最大并行的checkpoint数
env.getCheckpointConfig().setMaxConcurrentCheckpoints(3);  
 
// 要用状态，最好还要指定状态后端(默认是HashMapStateBackend)
env.setStateBackend(new EmbeddedRocksDBStateBackend());
```

# 9. 集群部署

官网:    https://flink.apache.org/

下载地址:  https://archive.apache.org/dist/flink/flink-1.17.1/

## 9.1  StandAlone模式



### 9.1.1 集群部署&#x20;

* 上传解压

* 修改配置

\[root@doitedu01 conf]# vi masters&#x20;

\[root@doitedu01 conf]# vi workers&#x20;

Vi  flink-conf.taml

```java
jobmanager.rpc.address: doitedu01
jobmanager.rpc.port: 6123
jobmanager.bind-host: 0.0.0.0
rest.bind-address: 0.0.0.0
taskmanager.bind-host: 0.0.0.0
taskmanager.host: doitedu01
taskmanager.numberOfTaskSlots: 4
parallelism.default: 4
#rest.port: 8081
rest.address: doitedu01
rest.bind-address: 0.0.0.0

state.savepoints.dir: file:///tmp/savepoint   可以stop程序,  自动的将数据savepoint到指定的目录中
```

* 分发 &#x20;

Scp  -r &#x20;

修改  doitedu02  03 的配置文件

```java
taskmanager.host: doitedu02
taskmanager.host: doitedu03
```

* <span style="color: inherit; background-color: rgba(255,246,122,0.8)">配置系统环境变量  </span>

Vi  /etc/profile

```java
export  FLINK_HOME=/opt/apps/flink-1.16.1
export  HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
export  PATH=$PATh...

export  HADOOP_CLASSPATH=`hadoop classpath`

source  /etc/profile
```

* 启动&#x20;

start-cluster.sh&#x20;

* 提交任务 &#x20;

http://doitedu01:8081

![](images/[多易教育]-Flink-1.16.1文档-image-38.png)

### 9.1.2 提交任务

可以在页面提交  也可以在页面上取消&#x20;

使用命令提交程序&#x20;

```bash
flink  run  --help  提交任务时参数 

flink  run  -m  doitedu01:8081 -d  -p 4  -c com.doit.day01.StreamWordCount  ./elite-39-flink-1.0-SNAPSHOT.jar 

-m  jobmanage的地址 doitedu01:8081
-d  沉默提交  程序提交后  提交客户端退出   1>/dev/null  2>&1  &
-p  并行度   代码中的优先
-c  运行的全类名
-s  可以指定保存点的位置 , 从保存点处继续处理数据 
最后执行jar的位置
```

```bash
flink  cancel  -m  doitedu01:8081  70013efd21c0635b0c9a24c88758144b    -s  hdfs://doitedu01:8020/flink/save-p01

-s,--withSavepoint <targetDirectory> 

flink  run  -m  doitedu01:8081 -d  -p 4  -c com.doit.day01.StreamWordCount  ./elite-39-flink-1.0-SNAPSHOT.jar 
-s  hdfs://doitedu01:8020/flink/save-p01
-s,--fromSavepoint <savepointPath>
```

`停止任务  flink  stop  -m   jobId`

`必须配置 state.savepoints.dir:  hdfs://doitedu01:8020/tmp/sp/  才能stop任务`

## 9.2 OnYarn模式

YARN是一个通用的资源调度框架，特点是：

* 可以运行多种编程模型，例如MR、Storm、Spark、Flink等

* 性能稳定，运维经验丰富

* 灵活的资源分配和资源隔离 \[自动配置资源]

* 每提交一个application都会有一个专门的ApplicationMater（JobManager）

![](images/[多易教育]-Flink-1.16.1文档-image-37.png)



Flink程序可以运行为以下3种模式:



* Application Mode【生产中建议使用的模式】  \[cluster]

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">每个job独享一个集群，job退出集群则退出(回收)，用户类的main方法在集群上运行</span>

* ~~Per-Job Mode~~

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">每个job独享一个集群，job退出集群则退出，用户类的main方法在client端运行；</span>（大job，运行时长很长，比较合适；因为每起一个job，都要去向yarn申请容器启动jm,tm，比较耗时）

* Yarn Session Mode.

<span style="color: inherit; background-color: rgba(222,224,227,0.8)">多个job共享同一个集群&lt;jobmanager/taskmanager&gt;、job退出集群也不会退出，用户类的main方法在client端运行；</span>（需要频繁提交大量小job的场景比较适用；因为每次提交一个新job的时候，不需要去向yarn注册应用）

> 上述3种模式的区别点在:
>
> 集群的生命周期和资源的隔离保证
>
> 用户类的main方法是运行在client端，还是在集群端

![](images/[多易教育]-Flink-1.16.1文档-image-42.png)

### 9.2.1&#x20;**&#x20;yarn application模式提交**

```shell
flink  run-application -t yarn-application  -c com.doit.foundation.Demo01WordCount   /tea01-1.0-SNAPSHOT.jar 
```

```java
 -- 查看当前运行的JOB  只有一个
  flink  list -t  yarn-application -Dyarn.application.id=application_1688482480797_0001
 
 -- 取消任务  集群资源被回收 
flink  cancel  -t  yarn-application -
 Dyarn.application.id=application_1688482480797_0001  ed896a2741659f6d9434ff28b1707f78
```

通过页面也能查看运行的JOB  , 在yarn的页面上(8088)  running  , 通过代理模式进入到Job监控界面

![](images/[多易教育]-Flink-1.16.1文档-image-36.png)

```java
flink   run-application -t yarn-application -Dyarn.provided.lib.dirs=""  -c   com.doitedu.demos.StreamWordCount  hdfs://
```



### 9.2.2&#x20;**&#x20;yarn perJob模式提交**

**Yarn-Per-Job 模式：<span style="color: rgb(216,57,49); background-color: inherit">每个作业单独启动集群</span>**，隔离性好，JM(JobManager) 负载均衡，main 方法在客户端执行。在 per-job 模式下，每个 Job 都有一个 JobManager，每个TaskManager 只有单个 Job。 **<span style="color: rgb(216,57,49); background-color: inherit"> </span>**

**<span style="color: rgb(216,57,49); background-color: inherit">特点： </span> <span style="color: rgb(36,91,219); background-color: inherit">一个任务会对应一个 Job</span>**，**每提交一个作业**会根据自身的情况，**<span style="color: rgb(216,57,49); background-color: inherit">都会单独向 yarn申请资源</span>**，直到作业执行完成，一个作业的失败与否并不会影响下一个作业的正常提交和运行。独享 Dispatcher 和 ResourceManager，按需接受资源申请；**<span style="color: rgb(216,57,49); background-color: inherit">适合规模大长时间运行的作业。</span>**



![](images/[多易教育]-Flink-1.16.1文档-QQ20221202-110728@2x.png)



**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 提交命令 (</span>**<span style="color: inherit; background-color: rgba(222,224,227,0.8)">申请容器启动flink集群以及提交job，是合二为一的)</span>

```shell
bin/flink run -d   -t  yarn-per-job -c com.doit.foundation.Demo01WordCount   /tea01-1.0-SNAPSHOT.jar 
```

查看app下运行的job&#x20;

```java
flink list -t yarn-per-job -Dyarn.application.id=application_1688314261146_0005
```

![](images/[多易教育]-Flink-1.16.1文档-image-40.png)

![](images/[多易教育]-Flink-1.16.1文档-image-41.png)

取消JOB

```java
flink  cancel  -t  yarn-per-job -Dyarn.application.id=application_1688314261146_0005  43afbc605a4d3967ce7cbeb3d51c7e9c
```

![](images/[多易教育]-Flink-1.16.1文档-image-39.png)

### 9.2.3&#x20;**&#x20;yarn session模式提交**

**Yarn-Session 模式：**&#x6240;&#x6709;**<span style="color: rgb(216,57,49); background-color: inherit">作业共享集群资源</span>**，隔离性差，JM 负载瓶颈，main 方法在客户端执行。适合执行时间短，频繁执行的短任务(比如对秒杀活动数据的实时分析)，集群中的所有作业 **<span style="color: rgb(100,37,208); background-color: inherit">只有一个 JobManager</span>**，另外，**<span style="color: rgb(36,91,219); background-color: inherit">Job 被随机分配给 TaskManager </span> <span style="color: rgb(216,57,49); background-color: inherit"> </span>**

**<span style="color: rgb(216,57,49); background-color: inherit">特点： </span> <span style="color: rgb(100,37,208); background-color: inherit">Session-Cluster 模式需要先启动集群</span>**，**<span style="color: rgb(36,91,219); background-color: inherit">然后再提交作业</span>**，接着会向 yarn 申请一块空间后，资源永远保持不变。如果资源满了，下一个作业就无法提交，只能等到 yarn 中的其中一个作业执行完成后，释放了资源，下个作业才会正常提交。所有作业共享 Dispatcher 和 ResourceManager；共享资源；适合规模小执行时间短的作业。

![](images/[多易教育]-Flink-1.16.1文档-QQ20221202-110743@2x.png)



**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 基本操作命令</span>**

```shell
# 提交命令：
#  第一步,执行flink-bin中的指令 , 开启一个会话连接 
bin/yarn-session.sh  

# 停止命令：
yarn  app  -list   -status
yarn application -kill application_1550836652097_0002
```

**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 具体操作步骤</span>**

1. 先开辟资源启动session模式集群

```shell
# 老版本： 
bin/yarn-session.sh -n 3 -jm 1024 -tm 1024
# -n --> 指定需要启动多少个Taskmanager

# 新版本： 
bin/yarn-session.sh   --help
-- 执行会话资源
bin/yarn-session.sh -jm 1024  -tm 2048  -s 4 -nm FLINK-WC -qu default 
```

-jm --> jobmanager memory &#x20;
-tm --> taskmanager memory
-s --> 规定每个taskmanager上的taskSlot数（槽位数）
-nm  --> 自定义appliction名称
-qu --> 指定要提交到的yarn队列

![](images/[多易教育]-Flink-1.16.1文档-image-35.png)



**<span style="color: inherit; background-color: rgb(98,210,86)"> </span> <span style="color: inherit; background-color: rgba(222,224,227,0.8)"> 启动的服务进程</span>**

YarnSessionClusterEntrypoint（AppMaster，即JobManager）

*<span style="color: inherit; background-color: rgba(222,224,227,0.8)">注意：此刻并没有taskmanager，也就是说，taskmanager是在后续提交job时根据资源需求动态申请容器启动的；</span>*

1. 向已运行的session模式集群提交job

```shell

bin/flink run -d -yid application_1550579025929_62420 -p 4 -c cn.doitedu.flink.java.demos._28_ToleranceSideToSideTest /root/flink_course-1.0.jar
```

## 9.3  Savepoint

<span style="color: inherit; background-color: rgba(255,246,122,0.8)">SavePoint是人为停止job时指的保存最新状态的检查点，而 Checkpoint是程序周期性自动将做的检查点</span>。

* 停止job时，指定保存最新状态的到指定的SavePoint目录中的命令

```shell
${FLINK-HOME}/bin/flink stop -p \ 
hdfs://node-1.51doit.cn:9000/save-point-33-1 \
50f707d81a5d2cf8d65e78f8ad6be799
```

&#x20;     -p参数为指定savepoint的路径

* 启动job从指定的savepoint恢复

```shell
${FLINK-HOME}/bin/flink run -c cn.doitedu.StateBackendDemo -p 4 \
-s hdfs://node-1.51doit.cn:9000/save-point-33-1/savepoint-50f707-e3100cb9302e
```

-s参数指定的是程序启动后从指定的savepoint或checkpoint恢复的路径
